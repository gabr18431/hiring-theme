import React, { useState } from 'react';
import { Search, MapPin, Filter } from 'lucide-react';
import { JobCard } from '../components/JobCard';
import { ApplicationModal } from '../components/ApplicationModal';

interface Job {
  id: string;
  title: string;
  company: string;
  location: string;
  type: string;
  salary: string;
  description: string;
  logo?: string;
}

const sampleJobs: Job[] = [
  {
    id: '1',
    title: 'Senior Frontend Developer',
    company: 'TechCorp',
    location: 'San Francisco, CA',
    type: 'Full-time',
    salary: '$120K - $160K',
    description: 'We are looking for an experienced Frontend Developer to join our dynamic team. You will be responsible for developing user-friendly web applications using modern technologies.',
  },
  {
    id: '2',
    title: 'Product Manager',
    company: 'InnovateLabs',
    location: 'New York, NY',
    type: 'Full-time',
    salary: '$140K - $180K',
    description: 'Join our product team to drive the development of cutting-edge solutions. You will work closely with engineering, design, and business teams.',
  },
  {
    id: '3',
    title: 'UX Designer',
    company: 'DesignStudio',
    location: 'Austin, TX',
    type: 'Full-time',
    salary: '$90K - $120K',
    description: 'Create exceptional user experiences for our digital products. You will conduct user research, create wireframes, and design intuitive interfaces.',
  },
  {
    id: '4',
    title: 'Data Scientist',
    company: 'DataFlow',
    location: 'Seattle, WA',
    type: 'Full-time',
    salary: '$130K - $170K',
    description: 'Analyze large datasets to extract meaningful insights and build predictive models. Experience with machine learning and statistical analysis required.',
  },
  {
    id: '5',
    title: 'Backend Engineer',
    company: 'CloudTech',
    location: 'Remote',
    type: 'Full-time',
    salary: '$110K - $150K',
    description: 'Build scalable backend systems and APIs. Experience with cloud technologies, microservices, and database design is essential.',
  },
  {
    id: '6',
    title: 'DevOps Engineer',
    company: 'ScaleUp',
    location: 'Denver, CO',
    type: 'Full-time',
    salary: '$125K - $165K',
    description: 'Manage and optimize our infrastructure and deployment pipelines. Experience with Kubernetes, Docker, and CI/CD tools required.',
  },
];

export default function Index() {
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [selectedJob, setSelectedJob] = useState<Job | null>(null);
  const [searchTerm, setSearchTerm] = useState('');
  const [locationFilter, setLocationFilter] = useState('');

  const handleApply = (jobId: string) => {
    const job = sampleJobs.find(j => j.id === jobId);
    if (job) {
      setSelectedJob(job);
      setIsModalOpen(true);
    }
  };

  const filteredJobs = sampleJobs.filter(job => {
    const matchesSearch = job.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         job.company.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesLocation = locationFilter === '' || 
                           job.location.toLowerCase().includes(locationFilter.toLowerCase());
    return matchesSearch && matchesLocation;
  });

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white border-b border-gray-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <div className="flex items-center">
              <h1 className="text-2xl font-bold text-teal-600">JobBoard</h1>
            </div>
            <nav className="hidden lg:flex space-x-8">
              <a href="#" className="text-gray-600 hover:text-gray-900 font-medium">Jobs</a>
              <a href="#" className="text-gray-600 hover:text-gray-900 font-medium">Companies</a>
              <a href="#" className="text-gray-600 hover:text-gray-900 font-medium">About</a>
              <a href="#" className="text-gray-600 hover:text-gray-900 font-medium">Contact</a>
            </nav>
            <div className="flex items-center space-x-2 sm:space-x-4">
              <button className="text-gray-600 hover:text-gray-900 font-medium hidden sm:block">Sign In</button>
              <button className="bg-teal-600 hover:bg-teal-700 text-white px-2 sm:px-4 py-2 rounded-lg font-medium transition-colors text-sm sm:text-base">
                Post a Job
              </button>
            </div>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section className="bg-white py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-2xl sm:text-3xl lg:text-4xl font-bold text-gray-900 mb-4">
            Find Your Dream Job
          </h2>
          <p className="text-lg sm:text-xl text-gray-600 mb-8 max-w-2xl mx-auto px-4 sm:px-0">
            Discover thousands of job opportunities from top companies around the world.
            Start your career journey today.
          </p>

          {/* Search Bar */}
          <div className="max-w-4xl mx-auto">
            <div className="flex flex-col md:flex-row gap-4 bg-white p-6 rounded-lg shadow-lg border border-gray-200">
              <div className="flex-1 relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
                <input
                  type="text"
                  placeholder="Job title, keywords..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="w-full pl-10 pr-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-teal-500 focus:border-teal-500"
                />
              </div>
              <div className="flex-1 relative">
                <MapPin className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
                <input
                  type="text"
                  placeholder="Location"
                  value={locationFilter}
                  onChange={(e) => setLocationFilter(e.target.value)}
                  className="w-full pl-10 pr-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-teal-500 focus:border-teal-500"
                />
              </div>
              <button className="bg-teal-600 hover:bg-teal-700 text-white px-4 sm:px-8 py-3 rounded-lg font-medium transition-colors whitespace-nowrap w-full md:w-auto">
                Search Jobs
              </button>
            </div>
          </div>
        </div>
      </section>

      {/* Jobs Section */}
      <section className="py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between mb-8">
            <div>
              <h3 className="text-2xl font-bold text-gray-900">
                Latest Job Opportunities
              </h3>
              <p className="text-gray-600 mt-1">
                Showing {filteredJobs.length} of {sampleJobs.length} jobs
              </p>
            </div>
            <button className="flex items-center gap-2 text-gray-600 hover:text-gray-900 font-medium">
              <Filter className="w-5 h-5" />
              Filters
            </button>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 sm:gap-6">
            {filteredJobs.map((job) => (
              <JobCard
                key={job.id}
                id={job.id}
                title={job.title}
                company={job.company}
                location={job.location}
                type={job.type}
                salary={job.salary}
                description={job.description}
                logo={job.logo}
                onApply={handleApply}
              />
            ))}
          </div>

          {filteredJobs.length === 0 && (
            <div className="text-center py-16">
              <div className="text-gray-400 mb-4">
                <Search className="w-16 h-16 mx-auto" />
              </div>
              <h4 className="text-xl font-semibold text-gray-900 mb-2">No jobs found</h4>
              <p className="text-gray-600">
                Try adjusting your search criteria or browse all available positions.
              </p>
            </div>
          )}
        </div>
      </section>

      {/* Application Modal */}
      {selectedJob && (
        <ApplicationModal
          isOpen={isModalOpen}
          onClose={() => {
            setIsModalOpen(false);
            setSelectedJob(null);
          }}
          jobTitle={selectedJob.title}
          companyName={selectedJob.company}
        />
      )}
    </div>
  );
}
