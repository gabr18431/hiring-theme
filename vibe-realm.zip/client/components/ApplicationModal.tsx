import React, { useState } from 'react';
import { X, Upload, Check, User, Mail, Phone, Briefcase, Linkedin, Globe, FileText, Sparkles } from 'lucide-react';

interface ApplicationModalProps {
  isOpen: boolean;
  onClose: () => void;
  jobTitle: string;
  companyName: string;
}

interface FormData {
  firstName: string;
  lastName: string;
  email: string;
  phone: string;
  experience: string;
  linkedin: string;
  website: string;
  coverLetter: string;
  resume: File | null;
  agreeToTerms: boolean;
}

export function ApplicationModal({ isOpen, onClose, jobTitle, companyName }: ApplicationModalProps) {
  const [step, setStep] = useState(1);
  const [formData, setFormData] = useState<FormData>({
    firstName: '',
    lastName: '',
    email: '',
    phone: '',
    experience: '',
    linkedin: '',
    website: '',
    coverLetter: '',
    resume: null,
    agreeToTerms: false
  });

  if (!isOpen) return null;

  const handleInputChange = (field: keyof FormData, value: string | File | null | boolean) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  const handleNext = () => {
    if (step < 4) {
      setStep(step + 1);
    }
  };

  const handleBack = () => {
    if (step > 1) {
      setStep(step - 1);
    }
  };

  const handleSubmit = () => {
    console.log('Form submitted:', formData);
    setStep(4);
  };

  const generateCoverLetter = () => {
    const sampleCoverLetter = `Lorem ipsum mi nibh dui egestas hac vitae duis commodo nisl Lorem ipsum mi nibh dui egestas hac vitae duis commodo nisl interdum velit interdum velit.`;
    handleInputChange('coverLetter', sampleCoverLetter);
  };

  const getStepTitle = () => {
    switch (step) {
      case 1: return 'Personal info';
      case 2: return 'Resume info';
      case 3: return 'Summary';
      default: return '';
    }
  };

  const renderStep = () => {
    switch (step) {
      case 1:
        return (
          <div className="space-y-6">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Your name <span className="text-red-500">*</span>
                </label>
                <div className="relative">
                  <User className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
                  <input
                    type="text"
                    value={formData.firstName}
                    onChange={(e) => handleInputChange('firstName', e.target.value)}
                    className="w-full pl-10 pr-3 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-green-500"
                    placeholder="Ahmed Moktaar"
                  />
                </div>
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Your Email <span className="text-red-500">*</span>
                </label>
                <div className="relative">
                  <Mail className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
                  <input
                    type="email"
                    value={formData.email}
                    onChange={(e) => handleInputChange('email', e.target.value)}
                    className="w-full pl-10 pr-3 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-green-500"
                    placeholder="ahmed7868@gmail.com"
                  />
                </div>
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Phone number <span className="text-red-500">*</span>
                </label>
                <div className="relative">
                  <Phone className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
                  <input
                    type="tel"
                    value={formData.phone}
                    onChange={(e) => handleInputChange('phone', e.target.value)}
                    className="w-full pl-10 pr-3 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-green-500"
                    placeholder="(654) 786 8907"
                  />
                </div>
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Years of experience <span className="text-red-500">*</span>
                </label>
                <div className="relative">
                  <Briefcase className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
                  <input
                    type="text"
                    value={formData.experience}
                    onChange={(e) => handleInputChange('experience', e.target.value)}
                    className="w-full pl-10 pr-3 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-green-500"
                    placeholder="4 years"
                  />
                </div>
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  LinkedIn profile <span className="text-red-500">*</span>
                </label>
                <div className="relative">
                  <Linkedin className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
                  <input
                    type="url"
                    value={formData.linkedin}
                    onChange={(e) => handleInputChange('linkedin', e.target.value)}
                    className="w-full pl-10 pr-3 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-green-500"
                    placeholder="Ahmedmoktaar/linkedin"
                  />
                </div>
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Personal website
                </label>
                <div className="relative">
                  <Globe className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
                  <input
                    type="url"
                    value={formData.website}
                    onChange={(e) => handleInputChange('website', e.target.value)}
                    className="w-full pl-10 pr-3 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-green-500"
                    placeholder="Ahmedmoktaar.com"
                  />
                </div>
              </div>
            </div>
          </div>
        );

      case 2:
        return (
          <div className="space-y-6">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Your resume <span className="text-red-500">*</span>
              </label>
              <div className="border-2 border-dashed border-gray-300 rounded-lg p-8 text-center bg-gray-50 hover:border-green-400 transition-colors">
                <Upload className="w-8 h-8 text-gray-400 mx-auto mb-3" />
                <p className="text-gray-600 mb-1">
                  <span className="text-green-600 font-medium">Click here to upload</span>, or drag and drop
                </p>
                <input
                  type="file"
                  accept=".pdf,.doc,.docx"
                  onChange={(e) => handleInputChange('resume', e.target.files?.[0] || null)}
                  className="hidden"
                  id="resume-upload"
                />
                <label
                  htmlFor="resume-upload"
                  className="cursor-pointer"
                >
                </label>
                {formData.resume && (
                  <p className="mt-3 text-sm text-green-600 font-medium">
                    ✓ {formData.resume.name}
                  </p>
                )}
              </div>
            </div>

            <div>
              <div className="flex items-center justify-between mb-2">
                <label className="block text-sm font-medium text-gray-700">
                  Cover letter <span className="text-orange-500">*</span>
                </label>
                <button
                  onClick={generateCoverLetter}
                  className="flex items-center gap-1 text-sm text-green-600 hover:text-green-700 font-medium"
                >
                  <Sparkles className="w-4 h-4" />
                  Generate by AI
                </button>
              </div>
              <textarea
                value={formData.coverLetter}
                onChange={(e) => handleInputChange('coverLetter', e.target.value)}
                rows={5}
                className="w-full px-3 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-green-500 resize-none"
                placeholder="Lorem ipsum mi nibh dui egestas hac vitae duis commodo nisl Lorem ipsum mi nibh dui egestas hac vitae duis commodo nisl interdum velit interdum velit."
              />
            </div>

            <div className="flex items-center">
              <input
                type="checkbox"
                id="terms"
                checked={formData.agreeToTerms}
                onChange={(e) => handleInputChange('agreeToTerms', e.target.checked)}
                className="w-4 h-4 text-green-600 bg-gray-100 border-gray-300 rounded focus:ring-green-500 focus:ring-2"
              />
              <label htmlFor="terms" className="ml-2 text-sm text-gray-600">
                I agree with the <span className="text-gray-900 underline cursor-pointer">terms and conditions</span>
              </label>
            </div>
          </div>
        );

      case 3:
        return (
          <div className="space-y-6">
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 bg-gray-100 rounded-full flex items-center justify-center">
                  <User className="w-5 h-5 text-gray-600" />
                </div>
                <div>
                  <p className="text-xs text-gray-500">Name</p>
                  <p className="text-sm font-medium text-gray-900">Ahmed Moktaar</p>
                </div>
              </div>
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 bg-gray-100 rounded-full flex items-center justify-center">
                  <Mail className="w-5 h-5 text-gray-600" />
                </div>
                <div>
                  <p className="text-xs text-gray-500">Email</p>
                  <p className="text-sm font-medium text-gray-900">ahmed7868@gmail.com</p>
                </div>
              </div>
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 bg-gray-100 rounded-full flex items-center justify-center">
                  <Phone className="w-5 h-5 text-gray-600" />
                </div>
                <div>
                  <p className="text-xs text-gray-500">Phone number</p>
                  <p className="text-sm font-medium text-gray-900">(654) 786 8907</p>
                </div>
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 bg-gray-100 rounded-full flex items-center justify-center">
                  <Briefcase className="w-5 h-5 text-gray-600" />
                </div>
                <div>
                  <p className="text-xs text-gray-500">Years of experience</p>
                  <p className="text-sm font-medium text-gray-900">4 years</p>
                </div>
              </div>
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 bg-gray-100 rounded-full flex items-center justify-center">
                  <Linkedin className="w-5 h-5 text-gray-600" />
                </div>
                <div>
                  <p className="text-xs text-gray-500">LinkedIn</p>
                  <p className="text-sm font-medium text-gray-900">Ahmedmoktaar/linkedin</p>
                </div>
              </div>
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 bg-gray-100 rounded-full flex items-center justify-center">
                  <Globe className="w-5 h-5 text-gray-600" />
                </div>
                <div>
                  <p className="text-xs text-gray-500">Personal website</p>
                  <p className="text-sm font-medium text-gray-900">Ahmedmoktaar.com</p>
                </div>
              </div>
            </div>

            <div className="pt-4 border-t border-gray-200">
              <p className="text-sm font-medium text-gray-700 mb-3">Your resume</p>
              <div className="flex items-center gap-3 p-3 bg-gray-50 rounded-lg border">
                <div className="w-8 h-8 bg-red-100 rounded flex items-center justify-center">
                  <FileText className="w-4 h-4 text-red-600" />
                </div>
                <div className="flex-1">
                  <p className="text-sm font-medium text-gray-900">Ahmedmoktaar.cv2025.pdf</p>
                  <p className="text-xs text-gray-500">(200KB)</p>
                </div>
              </div>
            </div>

            <div className="pt-4 border-t border-gray-200">
              <p className="text-sm font-medium text-gray-700 mb-3">Cover letter</p>
              <p className="text-sm text-gray-600 leading-relaxed">
                Lorem ipsum mi nibh dui egestas hac vitae duis commodo nisl Lorem ipsum mi nibh dui egestas hac vitae duis commodo nisl interdum velit interdum velit.
              </p>
            </div>
          </div>
        );

      case 4:
        return (
          <div className="text-center py-8">
            <div className="w-24 h-24 mx-auto mb-6 relative">
              <svg viewBox="0 0 100 100" className="w-full h-full">
                <circle cx="30" cy="40" r="8" fill="#fbbf24" />
                <circle cx="70" cy="30" r="6" fill="#fbbf24" />
                <rect x="40" y="50" width="20" height="25" rx="4" fill="#10b981" />
                <rect x="35" y="45" width="30" height="20" rx="6" fill="#f87171" />
                <circle cx="25" cy="75" r="4" fill="#fbbf24" />
                <circle cx="75" cy="70" r="3" fill="#fbbf24" />
              </svg>
            </div>
            <h3 className="text-xl font-semibold text-gray-900 mb-3">
              Your application is submitted successfully
            </h3>
            <button
              onClick={onClose}
              className="bg-slate-800 hover:bg-slate-900 text-white px-8 py-3 rounded-lg font-medium transition-colors"
            >
              Back to jobs
            </button>
          </div>
        );

      default:
        return null;
    }
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-xl max-w-3xl w-full max-h-[90vh] overflow-y-auto">
        <div className="flex items-center justify-between p-6 border-b border-gray-200">
          <div>
            <h2 className="text-xl font-semibold text-gray-900">Apply to job</h2>
            <p className="text-sm text-red-500 mt-1">
              <span className="text-red-500">*</span> Required
            </p>
          </div>
          <button
            onClick={onClose}
            className="text-gray-400 hover:text-gray-600 transition-colors"
          >
            <X className="w-6 h-6" />
          </button>
        </div>

        {step < 4 && (
          <div className="px-6 py-4 border-b border-gray-200">
            <div className="flex items-center justify-between mb-2">
              {[1, 2, 3].map((stepNumber, index) => (
                <React.Fragment key={stepNumber}>
                  <div className="flex flex-col items-center">
                    <div
                      className={`text-sm font-medium mb-2 ${
                        step >= stepNumber ? 'text-gray-900' : 'text-gray-400'
                      }`}
                    >
                      {stepNumber === 1 ? 'Personal info' : 
                       stepNumber === 2 ? 'Resume info' : 'Summary'}
                    </div>
                    <div
                      className={`w-full h-1 rounded ${
                        step >= stepNumber ? 'bg-green-500' : 'bg-gray-200'
                      }`}
                      style={{ width: index === 0 ? '120px' : index === 1 ? '120px' : '80px' }}
                    />
                  </div>
                  {index < 2 && <div className="flex-1" />}
                </React.Fragment>
              ))}
            </div>
          </div>
        )}

        <div className="p-6">
          {renderStep()}
        </div>

        {step < 4 && (
          <div className="flex items-center justify-between p-6 border-t border-gray-200">
            {step > 1 ? (
              <button
                onClick={handleBack}
                className="text-gray-600 hover:text-gray-800 font-medium px-6 py-2 rounded-lg border border-gray-300 transition-colors"
              >
                Back
              </button>
            ) : <div />}
            <button
              onClick={step === 3 ? handleSubmit : handleNext}
              className="bg-slate-800 hover:bg-slate-900 text-white px-8 py-3 rounded-lg font-medium transition-colors"
            >
              {step === 3 ? 'Submit' : 'Next'}
            </button>
          </div>
        )}
      </div>
    </div>
  );
}
