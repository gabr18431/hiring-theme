'use client'
import React from 'react'
import Link from "next/link"
import Layout from "@/components/layout/Layout"

export default function Service_page_one() {
    return (
        <div className="page-wrapper boxed_wrapper">
            <Layout headerStyle={1} footerStyle={6} breadcrumbTitle="Solutions 01">
                <section className="service-style1 instyle--2">
                    <div className="container">
                        <div className="sec-title withtext text-center">
                            <div className="sub-title">
                                <h4>Solutions we provide</h4>
                            </div>
                            <h2>Innovative Solutions for Talents</h2>
                            <div className="text">
                                <p>
                                    Long established fact that a reader will be distracted by the<br/>readable content of a page.
                                </p>
                            </div>
                        </div>
                        <div className="row">


                            <div className="col-xl-4 col-lg-4 col-md-6">
                                <div className="service-style1__single instyle--2">
                                    <div className="title-box">
                                        <h3><Link href="/solution01-temporary-stafing">Temporary Staffing</Link></h3>
                                    </div>
                                    <div className="service-style1__single-img">
                                        <div className="overlay-icon">
                                            <img src="assets/images/icon/services/service-icon-1-1.png" alt="icon"/>
                                        </div>
                                        <div className="img-box">
                                            <img src="assets/images/services/service-v1-1.jpg" alt="images"/>
                                        </div>
                                    </div>
                                    <div className="overlay-text">
                                        <p>The wise man therefore always holds in these matters to this...</p>
                                    </div>
                                    <div className="btn-box">
                                        <Link href="/solution01-temporary-stafing">
                                            Explore More
                                            <span className="icon-arrow-angle-pointing-to-right"></span>
                                            <span className="icon-right-arrow-1 arrow-hover"></span>
                                        </Link>
                                    </div>
                                </div>
                            </div>
                            
                            <div className="col-xl-4 col-lg-4 col-md-6">
                                <div className="service-style1__single instyle--2">
                                    <div className="title-box">
                                        <h3><Link href="/solution02-contract-stafing">Contract Staffing</Link></h3>
                                    </div>
                                    <div className="service-style1__single-img">
                                        <div className="overlay-icon">
                                            <img src="assets/images/icon/services/service-icon-1-2.png" alt="icon"/>
                                        </div>
                                        <div className="img-box">
                                            <img src="assets/images/services/service-v1-2.jpg" alt="images"/>
                                        </div>
                                    </div>
                                    <div className="overlay-text">
                                        <p>Right to find fault with a man chooses annoying consequences...</p>
                                    </div>
                                    <div className="btn-box">
                                        <Link href="/solution02-contract-stafing">
                                            Explore More
                                            <span className="icon-arrow-angle-pointing-to-right"></span>
                                            <span className="icon-right-arrow-1 arrow-hover"></span>
                                        </Link>
                                    </div>
                                </div>
                            </div>
                            
                            <div className="col-xl-4 col-lg-4 col-md-6">
                                <div className="service-style1__single instyle--2">
                                    <div className="title-box">
                                        <h3><Link href="/solution03-project-based">Project-Based Hiring</Link></h3>
                                    </div>
                                    <div className="service-style1__single-img">
                                        <div className="overlay-icon">
                                            <img src="assets/images/icon/services/service-icon-1-3.png" alt="icon"/>
                                        </div>
                                        <div className="img-box">
                                            <img src="assets/images/services/service-v1-3.jpg" alt="images"/>
                                        </div>
                                    </div>
                                    <div className="overlay-text">
                                        <p>Occasionally circumstances occur in pain can procure some great...</p>
                                    </div>
                                    <div className="btn-box">
                                        <Link href="/solution03-project-based">
                                            Explore More
                                            <span className="icon-arrow-angle-pointing-to-right"></span>
                                            <span className="icon-right-arrow-1 arrow-hover"></span>
                                        </Link>
                                    </div>
                                </div>
                            </div>
                            
                            <div className="col-xl-4 col-lg-4 col-md-6">
                                <div className="service-style1__single instyle--2">
                                    <div className="title-box">
                                        <h3><Link href="/solution04-permanent-stafing">Permanent Staffing</Link></h3>
                                    </div>
                                    <div className="service-style1__single-img">
                                        <div className="overlay-icon">
                                            <img src="assets/images/icon/services/service-icon-1-4.png" alt="icon"/>
                                        </div>
                                        <div className="img-box">
                                            <img src="assets/images/services/service-v1-4.jpg" alt="images"/>
                                        </div>
                                    </div>
                                    <div className="overlay-text">
                                        <p>Occasionally circumstances occur in pain can procure some great...</p>
                                    </div>
                                    <div className="btn-box">
                                        <Link href="/solution04-permanent-stafing">
                                            Explore More
                                            <span className="icon-arrow-angle-pointing-to-right"></span>
                                            <span className="icon-right-arrow-1 arrow-hover"></span>
                                        </Link>
                                    </div>
                                </div>
                            </div>
                            
                            <div className="col-xl-4 col-lg-4 col-md-6">
                                <div className="service-style1__single instyle--2">
                                    <div className="title-box">
                                        <h3><Link href="/solution05-payrolling">Payrolling</Link></h3>
                                    </div>
                                    <div className="service-style1__single-img">
                                        <div className="overlay-icon">
                                            <img src="assets/images/icon/services/service-icon-1-5.png" alt="icon"/>
                                        </div>
                                        <div className="img-box">
                                            <img src="assets/images/services/service-v1-5.jpg" alt="images"/>
                                        </div>
                                    </div>
                                    <div className="overlay-text">
                                        <p>The wise man therefore always holds in these matters to this...</p>
                                    </div>
                                    <div className="btn-box">
                                        <Link href="/solution05-payrolling">
                                            Explore More
                                            <span className="icon-arrow-angle-pointing-to-right"></span>
                                            <span className="icon-right-arrow-1 arrow-hover"></span>
                                        </Link>
                                    </div>
                                </div>
                            </div>
                            
                            <div className="col-xl-4 col-lg-4 col-md-6">
                                <div className="service-style1__single instyle--2">
                                    <div className="title-box">
                                        <h3><Link href="/solution06-outsourcing">Outsourcing</Link></h3>
                                    </div>
                                    <div className="service-style1__single-img">
                                        <div className="overlay-icon">
                                            <img src="assets/images/icon/services/service-icon-1-6.png" alt="icon"/>
                                        </div>
                                        <div className="img-box">
                                            <img src="assets/images/services/service-v1-6.jpg" alt="images"/>
                                        </div>
                                    </div>
                                    <div className="overlay-text">
                                        <p>Right to find fault with a man chooses annoying consequences...</p>
                                    </div>
                                    <div className="btn-box">
                                        <Link href="/solution06-outsourcing">
                                            Explore More
                                            <span className="icon-arrow-angle-pointing-to-right"></span>
                                            <span className="icon-right-arrow-1 arrow-hover"></span>
                                        </Link>
                                    </div>
                                </div>
                            </div>

                        </div>
                    </div>
                </section>
            </Layout>
        </div>
    )
}