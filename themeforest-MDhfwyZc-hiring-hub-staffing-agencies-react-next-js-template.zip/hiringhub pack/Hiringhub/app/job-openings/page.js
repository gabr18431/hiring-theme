'use client'
import React from 'react'
import Link from "next/link"
import Layout from "@/components/layout/Layout"

export default function Job_page_two() {
    return (
        <div className="page-wrapper boxed_wrapper">
            <Layout headerStyle={1} footerStyle={1} breadcrumbTitle="Job Openings">
                <section className="job-opening-style1">
                    <div className="container">
                        <div className="sec-title withtext text-center">
                            <div className="sub-title">
                                <h4>Recently Posted Jobs</h4>
                            </div>
                            <h2>Find Your Job You Deserve It</h2>
                            <div className="text">
                                <p>
                                    Long established fact that a reader will be distracted by the<br/>readable content of a page.
                                </p>
                            </div>
                        </div>

                        <div className="job-opening-style1__form">
                            <form id="job-opening-form-box" name="search-job" action="#" method="post">
                                <div className="row">
                                    <div className="col-xl-4 col-lg-4">
                                        <div className="form-group">
                                            <div className="input-box">
                                                <input type="text" name="form_company" id="fcompany"
                                                    placeholder="Keyword (Title or Company)" required=""/>
                                                <div className="icon">
                                                    <i className="icon-search-1"></i>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div className="col-xl-4 col-lg-4">
                                        <div className="form-group">
                                            <div className="input-box">
                                                <input type="text" name="form_location" id="flocation"
                                                    placeholder="Location (City or State)" required=""/>
                                                <div className="icon">
                                                    <i className="icon-place"></i>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div className="col-xl-4 col-lg-4">
                                        <div className="form-group">
                                            <div className="input-box">
                                                <div className="select-box clearfix">
                                                    <select className="wide">
                                                        <option data-display="Desire Work Status">Desire Work Status
                                                        </option>
                                                        <option value="1">Desire Work Status 01</option>
                                                        <option value="2">Desire Work Status 02</option>
                                                        <option value="3">Desire Work Status 03</option>
                                                        <option value="3">Desire Work Status 04</option>
                                                    </select>
                                                    <div className="icon">
                                                        <i className="icon-folder"></i>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                    <div className="col-xl-12">
                                        <div className="btn-box">
                                            <button className="submit btn-one">
                                                <span className="txt">Search Jobs</span>
                                            </button>
                                        </div>
                                    </div>

                                </div>
                            </form>
                        </div>

                        <div className="row">
                            <div className="col-xl-12">
                                <div className="job-opening-style1-info_inner">
                                    <div className="left-box">
                                        <p>Showing 8 results</p>
                                    </div>
                                    <div className="right-box">
                                        <div className="text">
                                            <p>Sort by:</p>
                                        </div>
                                        <div className="select-box">
                                            <select className="wide">
                                                <option data-display="Post Date">Post Date</option>
                                                <option value="1">Post Date 01</option>
                                                <option value="2">Post Date 02</option>
                                                <option value="3">Post Date 03</option>
                                            </select>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div className="row">
                            
                            <div className="col-xl-3 col-lg-4 col-md-6">
                                <div className="single-job-post">
                                    <div className="category-box">
                                        <p>Full time</p>
                                    </div>
                                    <div className="top-box text-center">
                                        <div className="icon">
                                            <img src="assets/images/icon/job-openings/job-post-1-icon-1.png" alt="icon"/>
                                        </div>
                                        <div className="title-box">
                                            <h3><Link href="/apply-now">Senior<br/>Graphic Designer</Link></h3>
                                            <p>Newyork</p>
                                        </div>
                                        <div className="btn-box">
                                            <Link className="btn-one" href="/apply-now">
                                                <span className="txt">Apply Now</span>
                                            </Link>
                                        </div>
                                    </div>
                                    <div className="bottom-box">
                                        <ul className="clearfix">
                                            <li>
                                                <div className="icon">
                                                    <img src="assets/images/icon/job-openings/icon-bag.png" alt="icon"/>
                                                </div>
                                                <div className="text">
                                                    <p>3 Open Position</p>
                                                </div>
                                            </li>
                                            <li>
                                                <div className="icon">
                                                    <img src="assets/images/icon/job-openings/icon-clock.png" alt="icon"/>
                                                </div>
                                                <div className="text">
                                                    <p>Apply until Feb 14, 2025</p>
                                                </div>
                                            </li>
                                            <li>
                                                <div className="icon">
                                                    <img src="assets/images/icon/job-openings/icon-dollar.png" alt="icon"/>
                                                </div>
                                                <div className="text">
                                                    <p>Package: $25k / yr</p>
                                                </div>
                                            </li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                            
                            <div className="col-xl-3 col-lg-4 col-md-6">
                                <div className="single-job-post">
                                    <div className="category-box">
                                        <p>Part time</p>
                                    </div>
                                    <div className="top-box text-center">
                                        <div className="icon">
                                            <img src="assets/images/icon/job-openings/job-post-1-icon-2.png" alt="icon"/>
                                        </div>
                                        <div className="title-box">
                                            <h3><Link href="/apply-now">PPC Marketing<br/>Executive</Link></h3>
                                            <p>Houston</p>
                                        </div>
                                        <div className="btn-box">
                                            <Link className="btn-one" href="/apply-now">
                                                <span className="txt">Apply Now</span>
                                            </Link>
                                        </div>
                                    </div>
                                    <div className="bottom-box">
                                        <ul className="clearfix">
                                            <li>
                                                <div className="icon">
                                                    <img src="assets/images/icon/job-openings/icon-bag.png" alt="icon"/>
                                                </div>
                                                <div className="text">
                                                    <p>1 Open Position</p>
                                                </div>
                                            </li>
                                            <li>
                                                <div className="icon">
                                                    <img src="assets/images/icon/job-openings/icon-clock.png" alt="icon"/>
                                                </div>
                                                <div className="text">
                                                    <p>Apply until Feb 10, 2025</p>
                                                </div>
                                            </li>
                                            <li>
                                                <div className="icon">
                                                    <img src="assets/images/icon/job-openings/icon-dollar.png" alt="icon"/>
                                                </div>
                                                <div className="text">
                                                    <p>Package: $15k / yr</p>
                                                </div>
                                            </li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                            
                            <div className="col-xl-3 col-lg-4 col-md-6">
                                <div className="single-job-post">
                                    <div className="category-box">
                                        <p>Full time</p>
                                    </div>
                                    <div className="top-box text-center">
                                        <div className="icon">
                                            <img src="assets/images/icon/job-openings/job-post-1-icon-3.png" alt="icon"/>
                                        </div>
                                        <div className="title-box">
                                            <h3><Link href="/apply-now">Senior<br/>Staff Engineer</Link></h3>
                                            <p>San Fransisco</p>
                                        </div>
                                        <div className="btn-box">
                                            <Link className="btn-one" href="/apply-now">
                                                <span className="txt">Apply Now</span>
                                            </Link>
                                        </div>
                                    </div>
                                    <div className="bottom-box">
                                        <ul className="clearfix">
                                            <li>
                                                <div className="icon">
                                                    <img src="assets/images/icon/job-openings/icon-bag.png" alt="icon"/>
                                                </div>
                                                <div className="text">
                                                    <p>1 Open Position</p>
                                                </div>
                                            </li>
                                            <li>
                                                <div className="icon">
                                                    <img src="assets/images/icon/job-openings/icon-clock.png" alt="icon"/>
                                                </div>
                                                <div className="text">
                                                    <p>Apply until Jan 30, 2025</p>
                                                </div>
                                            </li>
                                            <li>
                                                <div className="icon">
                                                    <img src="assets/images/icon/job-openings/icon-dollar.png" alt="icon"/>
                                                </div>
                                                <div className="text">
                                                    <p>Package: $42k / yr</p>
                                                </div>
                                            </li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                            
                            <div className="col-xl-3 col-lg-4 col-md-6">
                                <div className="single-job-post">
                                    <div className="category-box">
                                        <p>Full time</p>
                                    </div>
                                    <div className="top-box text-center">
                                        <div className="icon">
                                            <img src="assets/images/icon/job-openings/job-post-1-icon-4.png" alt="icon"/>
                                        </div>
                                        <div className="title-box">
                                            <h3><Link href="/apply-now">Staff<br/>Backend Engineer</Link></h3>
                                            <p>Houston</p>
                                        </div>
                                        <div className="btn-box">
                                            <Link className="btn-one" href="/apply-now">
                                                <span className="txt">Apply Now</span>
                                            </Link>
                                        </div>
                                    </div>
                                    <div className="bottom-box">
                                        <ul className="clearfix">
                                            <li>
                                                <div className="icon">
                                                    <img src="assets/images/icon/job-openings/icon-bag.png" alt="icon"/>
                                                </div>
                                                <div className="text">
                                                    <p>3 Open Position</p>
                                                </div>
                                            </li>
                                            <li>
                                                <div className="icon">
                                                    <img src="assets/images/icon/job-openings/icon-clock.png" alt="icon"/>
                                                </div>
                                                <div className="text">
                                                    <p>Apply until Sep 14, 2025</p>
                                                </div>
                                            </li>
                                            <li>
                                                <div className="icon">
                                                    <img src="assets/images/icon/job-openings/icon-dollar.png" alt="icon"/>
                                                </div>
                                                <div className="text">
                                                    <p>Package: $35k / yr</p>
                                                </div>
                                            </li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                            
                            <div className="col-xl-3 col-lg-4 col-md-6">
                                <div className="single-job-post">
                                    <div className="category-box">
                                        <p>Full time</p>
                                    </div>
                                    <div className="top-box text-center">
                                        <div className="icon">
                                            <img src="assets/images/icon/job-openings/job-post-1-icon-3.png" alt="icon"/>
                                        </div>
                                        <div className="title-box">
                                            <h3><Link href="/apply-now">Senior<br/>Staff Engineer</Link></h3>
                                            <p>San Fransisco</p>
                                        </div>
                                        <div className="btn-box">
                                            <Link className="btn-one" href="/apply-now">
                                                <span className="txt">Apply Now</span>
                                            </Link>
                                        </div>
                                    </div>
                                    <div className="bottom-box">
                                        <ul className="clearfix">
                                            <li>
                                                <div className="icon">
                                                    <img src="assets/images/icon/job-openings/icon-bag.png" alt="icon"/>
                                                </div>
                                                <div className="text">
                                                    <p>1 Open Position</p>
                                                </div>
                                            </li>
                                            <li>
                                                <div className="icon">
                                                    <img src="assets/images/icon/job-openings/icon-clock.png" alt="icon"/>
                                                </div>
                                                <div className="text">
                                                    <p>Apply until Jan 30, 2025</p>
                                                </div>
                                            </li>
                                            <li>
                                                <div className="icon">
                                                    <img src="assets/images/icon/job-openings/icon-dollar.png" alt="icon"/>
                                                </div>
                                                <div className="text">
                                                    <p>Package: $42k / yr</p>
                                                </div>
                                            </li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                            
                            <div className="col-xl-3 col-lg-4 col-md-6">
                                <div className="single-job-post">
                                    <div className="category-box">
                                        <p>Full time</p>
                                    </div>
                                    <div className="top-box text-center">
                                        <div className="icon">
                                            <img src="assets/images/icon/job-openings/job-post-1-icon-4.png" alt="icon"/>
                                        </div>
                                        <div className="title-box">
                                            <h3><Link href="/apply-now">Staff<br/>Backend Engineer</Link></h3>
                                            <p>Houston</p>
                                        </div>
                                        <div className="btn-box">
                                            <Link className="btn-one" href="/apply-now">
                                                <span className="txt">Apply Now</span>
                                            </Link>
                                        </div>
                                    </div>
                                    <div className="bottom-box">
                                        <ul className="clearfix">
                                            <li>
                                                <div className="icon">
                                                    <img src="assets/images/icon/job-openings/icon-bag.png" alt="icon"/>
                                                </div>
                                                <div className="text">
                                                    <p>3 Open Position</p>
                                                </div>
                                            </li>
                                            <li>
                                                <div className="icon">
                                                    <img src="assets/images/icon/job-openings/icon-clock.png" alt="icon"/>
                                                </div>
                                                <div className="text">
                                                    <p>Apply until Sep 14, 2025</p>
                                                </div>
                                            </li>
                                            <li>
                                                <div className="icon">
                                                    <img src="assets/images/icon/job-openings/icon-dollar.png" alt="icon"/>
                                                </div>
                                                <div className="text">
                                                    <p>Package: $35k / yr</p>
                                                </div>
                                            </li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                            
                            <div className="col-xl-3 col-lg-4 col-md-6">
                                <div className="single-job-post">
                                    <div className="category-box">
                                        <p>Full time</p>
                                    </div>
                                    <div className="top-box text-center">
                                        <div className="icon">
                                            <img src="assets/images/icon/job-openings/job-post-1-icon-1.png" alt="icon"/>
                                        </div>
                                        <div className="title-box">
                                            <h3><Link href="/apply-now">Senior<br/>Graphic Designer</Link></h3>
                                            <p>Newyork</p>
                                        </div>
                                        <div className="btn-box">
                                            <a className="btn-one" href="/apply-now">
                                                <span className="txt">Apply Now</span>
                                            </a>
                                        </div>
                                    </div>
                                    <div className="bottom-box">
                                        <ul className="clearfix">
                                            <li>
                                                <div className="icon">
                                                    <img src="assets/images/icon/job-openings/icon-bag.png" alt="icon"/>
                                                </div>
                                                <div className="text">
                                                    <p>3 Open Position</p>
                                                </div>
                                            </li>
                                            <li>
                                                <div className="icon">
                                                    <img src="assets/images/icon/job-openings/icon-clock.png" alt="icon"/>
                                                </div>
                                                <div className="text">
                                                    <p>Apply until Feb 14, 2025</p>
                                                </div>
                                            </li>
                                            <li>
                                                <div className="icon">
                                                    <img src="assets/images/icon/job-openings/icon-dollar.png" alt="icon"/>
                                                </div>
                                                <div className="text">
                                                    <p>Package: $25k / yr</p>
                                                </div>
                                            </li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                            
                            <div className="col-xl-3 col-lg-4 col-md-6">
                                <div className="single-job-post">
                                    <div className="category-box">
                                        <p>Part time</p>
                                    </div>
                                    <div className="top-box text-center">
                                        <div className="icon">
                                            <img src="assets/images/icon/job-openings/job-post-1-icon-2.png" alt="icon"/>
                                        </div>
                                        <div className="title-box">
                                            <h3><Link href="/apply-now">PPC Marketing<br/>Executive</Link></h3>
                                            <p>Houston</p>
                                        </div>
                                        <div className="btn-box">
                                            <Link className="btn-one" href="/apply-now">
                                                <span className="txt">Apply Now</span>
                                            </Link>
                                        </div>
                                    </div>
                                    <div className="bottom-box">
                                        <ul className="clearfix">
                                            <li>
                                                <div className="icon">
                                                    <img src="assets/images/icon/job-openings/icon-bag.png" alt="icon"/>
                                                </div>
                                                <div className="text">
                                                    <p>1 Open Position</p>
                                                </div>
                                            </li>
                                            <li>
                                                <div className="icon">
                                                    <img src="assets/images/icon/job-openings/icon-clock.png" alt="icon"/>
                                                </div>
                                                <div className="text">
                                                    <p>Apply until Feb 10, 2025</p>
                                                </div>
                                            </li>
                                            <li>
                                                <div className="icon">
                                                    <img src="assets/images/icon/job-openings/icon-dollar.png" alt="icon"/>
                                                </div>
                                                <div className="text">
                                                    <p>Package: $15k / yr</p>
                                                </div>
                                            </li>
                                        </ul>
                                    </div>
                                </div>
                            </div>

                        </div>
                    </div>
                </section>
            </Layout>
        </div>
    )
}