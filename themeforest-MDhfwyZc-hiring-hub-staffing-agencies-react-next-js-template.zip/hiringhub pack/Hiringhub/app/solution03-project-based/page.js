'use client'
import React from 'react'
import { useState } from "react"
import Link from "next/link"
import Layout from "@/components/layout/Layout"
import { Autoplay, Navigation, Pagination } from "swiper/modules"
import { Swiper, SwiperSlide } from "swiper/react"
import Case_Two from '@/components/sections/home2/Case_Two'
const swiperOptions = {
    modules: [Autoplay, Pagination, Navigation],
    slidesPerView: 1,
    spaceBetween: 30,
    autoplay: {
        delay: 5000,
        disableOnInteraction: false,
    },
    loop: true,

    // Pagination
    "pagination": {
        "el": "#solution-detail-highlighs-box-pagination",
        "type": "progressbar",
        "clickable": true
    },

    breakpoints: {
        320: {
            slidesPerView: 1,
            spaceBetween: 30,
        },
        575: {
            slidesPerView: 1,
            spaceBetween: 30,
        },
        767: {
            slidesPerView: 1,
            spaceBetween: 30,
        },
        991: {
            slidesPerView: 2,
            spaceBetween: 30,
        },
        1199: {
            slidesPerView: 2,
            spaceBetween: 30,
        },
        1350: {
            slidesPerView: 2,
            spaceBetween: 30,
        },
    }
}

export default function Service_details_three() {
    const [activeIndex, setActiveIndex] = useState(1)
        const handleOnClick = (index) => {
            setActiveIndex(index)
        }
    return (
        <div className="page-wrapper boxed_wrapper">
            <Layout headerStyle={1} footerStyle={1} breadcrumbTitle="Project-Based Hiring">
                <section className="solution-detail-page">
                    <div className="container">
                        <div className="row">

                            <div className="col-xl-8 col-lg-7">
                                <div className="solution-detail-page-content">
                                    <div className="intro-box">
                                        <div className="intro-title-box">
                                            <h2>Tailored to match your short<br/>term needs</h2>
                                        </div>
                                        <div className="intro-img-box">
                                            <img src="assets/images/resources/solution-detail-page__img1.jpg" alt="image"/>
                                        </div>
                                        <div className="text1">
                                            <p>
                                                It is a long established fact that a reader will be distracted by the readable
                                                content page when looking at its layout. The point of using lorem ipsum is that
                                                it has more-or-less normal distribution letters, as opposed using content here
                                                content here making it look like readable english many desktop publishing
                                                packages and web page editors now use versions.
                                            </p>
                                        </div>
                                        <div className="text2">
                                            <p>
                                                Obligations of business it will frequently occur pleasure have repudiated
                                                annoyances accept wise man therefore always holds in these matters
                                            </p>
                                        </div>
                                        <div className="text3">
                                            <p>
                                                The point of using lorem ipsum is that it has more-or-less normal distribution
                                                letters, as opposed using content here content here making it look like readable
                                                english many desktop publishing packages and web page editors now use versions.
                                            </p>
                                        </div>
                                    </div>

                                    <div className="solution-detail-highlighs-box">

                                        <Swiper {...swiperOptions} className="swiper-container thm-swiper__slider">
                                            <SwiperSlide>
                                                <div className="swiper-slide">
                                                    <div className="single-highlighs-box">
                                                        <div className="icon">
                                                            <img src="assets/images/icon/solution-detail-page-icon-1.png"
                                                                alt="icon"/>
                                                        </div>
                                                        <div className="title-box">
                                                            <h3><Link href="#">Project Based</Link></h3>
                                                            <p>Foresee the pain & troublethat are bound ensure equal blame
                                                                belongs
                                                                to those who fail in their duty.</p>
                                                        </div>
                                                    </div>
                                                </div>
                                            </SwiperSlide>
                                            <SwiperSlide>
                                                <div className="swiper-slide">
                                                    <div className="single-highlighs-box">
                                                        <div className="icon">
                                                            <img src="assets/images/icon/solution-detail-page-icon-1.png"
                                                                alt="icon"/>
                                                        </div>
                                                        <div className="title-box">
                                                            <h3><Link href="#">Project Based</Link></h3>
                                                            <p>Foresee the pain & troublethat are bound ensure equal blame
                                                                belongs
                                                                to those who fail in their duty.</p>
                                                        </div>
                                                    </div>
                                                </div>
                                            </SwiperSlide>
                                            <SwiperSlide>
                                                <div className="swiper-slide">
                                                    <div className="single-highlighs-box">
                                                        <div className="icon">
                                                            <img src="assets/images/icon/solution-detail-page-icon-1.png"
                                                                alt="icon"/>
                                                        </div>
                                                        <div className="title-box">
                                                            <h3><Link href="#">Project Based</Link></h3>
                                                            <p>Foresee the pain & troublethat are bound ensure equal blame
                                                                belongs
                                                                to those who fail in their duty.</p>
                                                        </div>
                                                    </div>
                                                </div>
                                            </SwiperSlide>
                                            <SwiperSlide>
                                                <div className="swiper-slide">
                                                    <div className="single-highlighs-box">
                                                        <div className="icon">
                                                            <img src="assets/images/icon/solution-detail-page-icon-1.png"
                                                                alt="icon"/>
                                                        </div>
                                                        <div className="title-box">
                                                            <h3><Link href="#">Project Based</Link></h3>
                                                            <p>Foresee the pain & troublethat are bound ensure equal blame
                                                                belongs
                                                                to those who fail in their duty.</p>
                                                        </div>
                                                    </div>
                                                </div>
                                            </SwiperSlide>
                                            <div className="swiper-pagination" id="solution-detail-highlighs-box-pagination"></div>
                                        </Swiper>
                                    </div>

                                    <div className="service-advantages">
                                        <div className="service-advantages-title">
                                            <h3>Service Advantages</h3>
                                            <p>Distracted by the readable content page when lookingat its layout the point of
                                                using lorem ipsum is that it has more-or-less normal distribution letters.</p>
                                        </div>
                                        <div className="service-advantages__inner">
                                            <div className="service-advantages__bg"
                                                style={{ backgroundImage: "url(assets/images/backgrounds/service-advantages__bg.jpg)" }}>
                                            </div>

                                            <div className="service-advantages__tab">
                                                <div className="service-advantages-tab__button">
                                                    <ul className="tabs-button-box clearfix">
                                                        <li onClick={() => handleOnClick(1)} className={activeIndex === 1 ? "tab-btn-item active-btn" : "tab-btn-item"}>
                                                            <h4>
                                                                Flexibility
                                                                <span className="icon-right-arrow-1 arrow-hover"></span>
                                                            </h4>
                                                        </li>
                                                        <li onClick={() => handleOnClick(2)} className={activeIndex === 2 ? "tab-btn-item active-btn" : "tab-btn-item"}>
                                                            <h4>
                                                                Cost-Efficiency
                                                                <span className="icon-right-arrow-1 arrow-hover"></span>
                                                            </h4>
                                                        </li>
                                                        <li onClick={() => handleOnClick(3)} className={activeIndex === 3 ? "tab-btn-item active-btn" : "tab-btn-item"}>
                                                            <h4>
                                                                Specialized Skill
                                                                <span className="icon-right-arrow-1 arrow-hover"></span>
                                                            </h4>
                                                        </li>
                                                        <li onClick={() => handleOnClick(4)} className={activeIndex === 4 ? "tab-btn-item active-btn" : "tab-btn-item"}>
                                                            <h4>
                                                                Quick Deployment
                                                                <span className="icon-right-arrow-1 arrow-hover"></span>
                                                            </h4>
                                                        </li>
                                                    </ul>
                                                </div>

                                                <div className="tabs-content-box">
                                                    <div className="service-advantages__shape"
                                                        style={{ backgroundImage: "url(assets/images/shapes/service-advantages__shape.png)" }}>
                                                    </div>

                                                    
                                                    <div className={activeIndex === 1 ? "tab-content-box-item active-tab" : "tab-content-box-item"}>
                                                        <div className="service-advantages__content-tab-item">
                                                            <div className="service-advantages__content-tab-item__inner">
                                                                <div className="title-box">
                                                                    <h3>Flexibility</h3>
                                                                    <p>
                                                                        Must explain too you how all this mistaken idea
                                                                        of denouncing pleasures praising pain was born
                                                                        complete account of the system.
                                                                    </p>
                                                                </div>
                                                                <div className="btn-box">
                                                                    <Link href="#">
                                                                        Explore More
                                                                        <i className="icon-arrow-angle-pointing-to-right"></i>
                                                                    </Link>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>

                                                    <div className={activeIndex === 2 ? "tab-content-box-item active-tab" : "tab-content-box-item"}>
                                                        <div className="service-advantages__content-tab-item">
                                                            <div className="service-advantages__content-tab-item__inner">
                                                                <div className="title-box">
                                                                    <h3>Cost-Efficiency</h3>
                                                                    <p>
                                                                        Must explain too you how all this mistaken idea
                                                                        of denouncing pleasures praising pain was born
                                                                        complete account of the system.
                                                                    </p>
                                                                </div>
                                                                <div className="btn-box">
                                                                    <Link href="#">
                                                                        Explore More
                                                                        <i className="icon-arrow-angle-pointing-to-right"></i>
                                                                    </Link>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>

                                                    <div className={activeIndex === 3 ? "tab-content-box-item active-tab" : "tab-content-box-item"}>
                                                        <div className="service-advantages__content-tab-item">
                                                            <div className="service-advantages__content-tab-item__inner">
                                                                <div className="title-box">
                                                                    <h3>Specialized Skill</h3>
                                                                    <p>
                                                                        Must explain too you how all this mistaken idea
                                                                        of denouncing pleasures praising pain was born
                                                                        complete account of the system.
                                                                    </p>
                                                                </div>
                                                                <div className="btn-box">
                                                                    <Link href="#">
                                                                        Explore More
                                                                        <i className="icon-arrow-angle-pointing-to-right"></i>
                                                                    </Link>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>

                                                    <div className={activeIndex === 4 ? "tab-content-box-item active-tab" : "tab-content-box-item"}>
                                                        <div className="service-advantages__content-tab-item">
                                                            <div className="service-advantages__content-tab-item__inner">
                                                                <div className="title-box">
                                                                    <h3>Quick Deployment</h3>
                                                                    <p>
                                                                        Must explain too you how all this mistaken idea
                                                                        of denouncing pleasures praising pain was born
                                                                        complete account of the system.
                                                                    </p>
                                                                </div>
                                                                <div className="btn-box">
                                                                    <Link href="#">
                                                                        Explore More
                                                                        <i className="icon-arrow-angle-pointing-to-right"></i>
                                                                    </Link>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>

                                                </div>
                                            </div>

                                        </div>
                                    </div>
                                </div>
                            </div>

                            
                            <div className="col-xl-4 col-lg-5">
                                <div className="solution-detail-page-sidebar">

                                    <div className="services-box">
                                        <div className="title">
                                            <div className="icon">
                                                <i className="icon-play"></i>
                                            </div>
                                            <h3>Services</h3>
                                        </div>
                                        <div className="list-box">
                                            <ul>
                                                <li>
                                                    <div className="text">
                                                        <h5>
                                                            <Link href="/solution01-temporary-stafing">
                                                                Temporary Staffing
                                                                <i className="icon-right-arrow-1 arrow-hover"></i>
                                                            </Link>
                                                        </h5>
                                                    </div>
                                                    <div className="icon">
                                                        <i className="icon-arrow-angle-pointing-to-right"></i>
                                                    </div>
                                                </li>
                                                <li>
                                                    <div className="text">
                                                        <h5>
                                                            <Link href="/solution02-contract-stafing">
                                                                Contract Staffing
                                                                <i className="icon-right-arrow-1 arrow-hover"></i>
                                                            </Link>
                                                        </h5>
                                                    </div>
                                                    <div className="icon">
                                                        <i className="icon-arrow-angle-pointing-to-right"></i>
                                                    </div>
                                                </li>
                                                <li className="active">
                                                    <div className="text">
                                                        <h5>
                                                            <Link href="/solution03-project-based">
                                                                Project-Based Hiring
                                                                <i className="icon-right-arrow-1 arrow-hover"></i>
                                                            </Link>
                                                        </h5>
                                                    </div>
                                                    <div className="icon">
                                                        <i className="icon-arrow-angle-pointing-to-right"></i>
                                                    </div>
                                                </li>
                                                <li>
                                                    <div className="text">
                                                        <h5>
                                                            <Link href="/solution04-permanent-stafing">
                                                                Permanent Staffing
                                                                <i className="icon-right-arrow-1 arrow-hover"></i>
                                                            </Link>
                                                        </h5>
                                                    </div>
                                                    <div className="icon">
                                                        <i className="icon-arrow-angle-pointing-to-right"></i>
                                                    </div>
                                                </li>
                                                <li>
                                                    <div className="text">
                                                        <h5>
                                                            <Link href="/solution05-payrolling">
                                                                Payrolling
                                                                <i className="icon-right-arrow-1 arrow-hover"></i>
                                                            </Link>
                                                        </h5>
                                                    </div>
                                                    <div className="icon">
                                                        <i className="icon-arrow-angle-pointing-to-right"></i>
                                                    </div>
                                                </li>
                                                <li>
                                                    <div className="text">
                                                        <h5>
                                                            <Link href="/solution06-outsourcing">
                                                                Outsourcing
                                                                <i className="icon-right-arrow-1 arrow-hover"></i>
                                                            </Link>
                                                        </h5>
                                                    </div>
                                                    <div className="icon">
                                                        <i className="icon-arrow-angle-pointing-to-right"></i>
                                                    </div>
                                                </li>
                                            </ul>
                                        </div>
                                    </div>

                                    <div className="downloads-box">
                                        <div className="title">
                                            <div className="icon">
                                                <i className="icon-play"></i>
                                            </div>
                                            <h3>Downloads</h3>
                                        </div>
                                        <div className="list-box">
                                            <ul>
                                                <li>
                                                    <div className="icon">
                                                        <span className="icon-pdf-file"><span className="path1"></span><span
                                                                className="path2"></span><span className="path3"></span><span
                                                                className="path4"></span><span className="path5"></span><span
                                                                className="path6"></span><span className="path7"></span>
                                                        </span>
                                                    </div>
                                                    <div className="text">
                                                        <h5>Service Brochure</h5>
                                                        <div className="btn">
                                                            <Link href="#">
                                                                <i className="icon-cloud-computing"></i>
                                                                Download
                                                            </Link>
                                                        </div>
                                                    </div>
                                                </li>
                                                <li>
                                                    <div className="icon">
                                                        <span className="icon-pdf-file"><span className="path1"></span><span
                                                                className="path2"></span><span className="path3"></span><span
                                                                className="path4"></span><span className="path5"></span><span
                                                                className="path6"></span><span className="path7"></span>
                                                        </span>
                                                    </div>
                                                    <div className="text">
                                                        <h5>Terms & Conditions</h5>
                                                        <div className="btn">
                                                            <Link href="#">
                                                                <i className="icon-cloud-computing"></i>
                                                                Download
                                                            </Link>
                                                        </div>
                                                    </div>
                                                </li>
                                            </ul>
                                        </div>
                                    </div>

                                    <div className="banner-box">
                                        <div className="banner-box__shape">
                                            <img src="assets/images/shapes/solution-detail-page-sidebar__banner-shape1.png"
                                                alt="shape"/>
                                        </div>
                                        <div className="logo">
                                            <Link href="solution01-temporary-stafing.html">
                                                <img src="assets/images/resources/solution-detail-page-sidebar__banner-logo1.png"
                                                    alt="logo"/>
                                            </Link>
                                        </div>
                                        <div className="title">
                                            <h3>
                                                Always On<br/><span>Fire To Find</span><br/>
                                                The Next<br/><span>Hire!...</span>
                                            </h3>
                                        </div>
                                        <div className="text">
                                            <p>Finding the right person for<br/>the right job.</p>
                                        </div>
                                        <div className="btn-box">
                                            <Link className="btn-one" href="/solution01-temporary-stafing">
                                                <span className="txt">Get in Touch</span>
                                            </Link>
                                        </div>
                                    </div>

                                </div>
                            </div>

                        </div>

                        
                        <Case_Two/>

                    </div>
                </section>
            </Layout>
        </div>
    )
}