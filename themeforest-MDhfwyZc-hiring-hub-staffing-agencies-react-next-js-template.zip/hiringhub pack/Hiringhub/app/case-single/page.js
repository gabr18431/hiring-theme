'use client'
import React from 'react'
import Link from "next/link"
import Layout from "@/components/layout/Layout"

export default function Case_single() {
    return (
        <div className="page-wrapper boxed_wrapper">
            <Layout headerStyle={1} footerStyle={1} breadcrumbTitle="Single Case">
                <section className="single-case-studies">
                    <div className="container">
                        <div className="row">
                            <div className="col-xl-4 col-lg-5">
                                <div className="single-case-studies__sidebar">
                                    <div className="project-info">
                                        <div className="title">
                                            <h3>Project Info</h3>
                                        </div>
                                        <ul className="clearfix">
                                            <li>
                                                <p>Client</p>
                                                <h4>Naxly Info Tech</h4>
                                            </li>
                                            <li>
                                                <p>Catgory</p>
                                                <h4>Business Consulting</h4>
                                            </li>
                                            <li>
                                                <p>Date</p>
                                                <h4>14 February, 2025</h4>
                                            </li>
                                            <li>
                                                <p>Location</p>
                                                <h4>Los Angeles, USA</h4>
                                            </li>
                                        </ul>
                                        <div className="btn-box">
                                            <Link className="btn-one" href="/single-case">
                                                <span className="txt">Learn More</span>
                                            </Link>
                                        </div>
                                    </div>
                                    <div className="social-links">
                                        <div className="text">
                                            <p>Share this Project</p>
                                        </div>
                                        <ul>
                                            <li>
                                                <Link href="https://www.facebook.com/">
                                                    <span className="icon-facebook"></span>
                                                </Link>
                                            </li>
                                            <li>
                                                <Link href="https://x.com/i/flow/login">
                                                    <span className="icon-twitter"></span>
                                                </Link>
                                            </li>
                                            <li>
                                                <Link href="https://www.instagram.com/accounts/login/?hl=en">
                                                    <span className="icon-instagram-logo"></span>
                                                </Link>
                                            </li>
                                            <li>
                                                <Link href="https://www.youtube.com/">
                                                    <span className="icon-youtube"></span>
                                                </Link>
                                            </li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                            <div className="col-xl-8 col-lg-7">
                                <div className="single-case-studies__content">
                                    <div className="title">
                                        <h2>Placements Driving Growth</h2>
                                        <p>
                                            Make a type specimen book. It has survived not only five centuries, but also the
                                            leap into electronic type setting, remaining essentially unchanged. It was
                                            popularised the 1960s with the release of letraset sheet containing lorem Ipsum
                                            passages, and more recently with desktop publishing software like aldus page maker
                                            including versions of lorem ipsum.
                                        </p>
                                    </div>
                                    <div className="img-box">
                                        <img src="assets/images/resources/single-case-studies-img1.jpg" alt="image"/>
                                    </div>
                                    <div className="text-box">
                                        <p>
                                            Obligations of business it will frequently occur pleasure have repudiated annoyances
                                            accept wise man therefore always holds in these matters beguiled and demoralized by
                                            the charms pleasure the moment, so blinded by desire, that they cannot foresee right
                                            to find fault with a man chooses to enjoy a pleasure that has no annoying
                                            consequences.
                                        </p>
                                    </div>
                                    <ul className="clearfix">
                                        <li>
                                            <div className="icon">
                                                <span className="icon-effort"><span className="path1"></span><span
                                                        className="path2"></span></span>
                                            </div>
                                            <div className="content-box">
                                                <div className="text">
                                                    <h3>The Challenges</h3>
                                                    <p>How all this mistaken idea of denouncing pleasure and praising pain was
                                                        born and<br/> we will give you acomplete account of the system.</p>
                                                </div>
                                                <ul className="clearfix">
                                                    <li>
                                                        <div className="icon">
                                                            <i className="icon-spark"></i>
                                                        </div>
                                                        <div className="text">
                                                            <p>Power of choice is untrammelled and when nothing prevents.</p>
                                                        </div>
                                                    </li>
                                                    <li>
                                                        <div className="icon">
                                                            <i className="icon-spark"></i>
                                                        </div>
                                                        <div className="text">
                                                            <p>Our being able to do what we like best.</p>
                                                        </div>
                                                    </li>
                                                    <li>
                                                        <div className="icon">
                                                            <i className="icon-spark"></i>
                                                        </div>
                                                        <div className="text">
                                                            <p>Every pleasure is to be welcomed and every pain avoided.</p>
                                                        </div>
                                                    </li>
                                                </ul>
                                            </div>
                                        </li>
                                        <li>
                                            <div className="icon">
                                                <span className="icon-value"><span className="path1"></span><span
                                                        className="path2"></span><span className="path3"></span><span
                                                        className="path4"></span><span className="path5"></span><span
                                                        className="path6"></span><span className="path7"></span><span
                                                        className="path8"></span><span className="path9"></span><span
                                                        className="path10"></span><span className="path11"></span></span>
                                            </div>
                                            <div className="content-box">
                                                <div className="text">
                                                    <h3>The Challenges</h3>
                                                    <p>How all this mistaken idea of denouncing pleasure and praising pain
                                                        was
                                                        born and<br/> we will give you acomplete account of the system.</p>
                                                </div>
                                            </div>
                                        </li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                </section>
            </Layout>
        </div>
    )
}