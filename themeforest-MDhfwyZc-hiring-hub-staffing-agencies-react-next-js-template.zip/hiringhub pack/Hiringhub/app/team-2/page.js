'use client'
import React from 'react'
import Link from "next/link"
import Layout from "@/components/layout/Layout"

export default function Team_page_Two() {
    return (
        <div className="page-wrapper boxed_wrapper">
            <Layout headerStyle={1} footerStyle={1} breadcrumbTitle="Team Members 02">
                <section className="team-style2">
                    <div className="container">
                        <div className="row">

                            <div className="col-xl-3 col-lg-4 col-md-6">
                                <div className="team-style2__single">
                                    <div className="img-box">
                                        <div className="inner">
                                            <img src="assets/images/team/team-v2-1.jpg" alt="image"/>
                                            <div className="social-share-box">
                                                <span className="icon-share"></span>
                                                <ul className="clearfix">
                                                    <li>
                                                        <Link href="#">
                                                            <i className="icon-facebook"></i>
                                                        </Link>
                                                    </li>
                                                    <li>
                                                        <Link href="#">
                                                            <i className="icon-twitter"></i>
                                                        </Link>
                                                    </li>
                                                    <li>
                                                        <Link href="#">
                                                            <i className="icon-instagram-logo"></i>
                                                        </Link>
                                                    </li>
                                                </ul>
                                            </div>
                                        </div>
                                        <div className="overlay-content">
                                            <div className="title">
                                                <h3><Link href="#">Bertram Irvin</Link></h3>
                                            </div>
                                            <div className="border-line"></div>
                                            <div className="text">
                                                <p>Senior Recruiter</p>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            
                            <div className="col-xl-3 col-lg-4 col-md-6">
                                <div className="team-style2__single">
                                    <div className="img-box">
                                        <div className="inner">
                                            <img src="assets/images/team/team-v2-2.jpg" alt="image"/>
                                            <div className="social-share-box">
                                                <span className="icon-share"></span>
                                                <ul className="clearfix">
                                                    <li>
                                                        <Link href="#">
                                                            <i className="icon-facebook"></i>
                                                        </Link>
                                                    </li>
                                                    <li>
                                                        <Link href="#">
                                                            <i className="icon-twitter"></i>
                                                        </Link>
                                                    </li>
                                                    <li>
                                                        <Link href="#">
                                                            <i className="icon-instagram-logo"></i>
                                                        </Link>
                                                    </li>
                                                </ul>
                                            </div>
                                        </div>
                                        <div className="overlay-content">
                                            <div className="title">
                                                <h3><Link href="#">Michel Kyle</Link></h3>
                                            </div>
                                            <div className="border-line"></div>
                                            <div className="text">
                                                <p>Recruitment Manager</p>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            
                            <div className="col-xl-3 col-lg-4 col-md-6">
                                <div className="team-style2__single">
                                    <div className="img-box">
                                        <div className="inner">
                                            <img src="assets/images/team/team-v2-3.jpg" alt="image"/>
                                            <div className="social-share-box">
                                                <span className="icon-share"></span>
                                                <ul className="clearfix">
                                                    <li>
                                                        <Link href="#">
                                                            <i className="icon-facebook"></i>
                                                        </Link>
                                                    </li>
                                                    <li>
                                                        <Link href="#">
                                                            <i className="icon-twitter"></i>
                                                        </Link>
                                                    </li>
                                                    <li>
                                                        <Link href="#">
                                                            <i className="icon-instagram-logo"></i>
                                                        </Link>
                                                    </li>
                                                </ul>
                                            </div>
                                        </div>
                                        <div className="overlay-content">
                                            <div className="title">
                                                <h3><Link href="#">Nora Lillian</Link></h3>
                                            </div>
                                            <div className="border-line"></div>
                                            <div className="text">
                                                <p>IT Recruitment Specialist</p>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            
                            <div className="col-xl-3 col-lg-4 col-md-6">
                                <div className="team-style2__single">
                                    <div className="img-box">
                                        <div className="inner">
                                            <img src="assets/images/team/team-v2-4.jpg" alt="image"/>
                                            <div className="social-share-box">
                                                <span className="icon-share"></span>
                                                <ul className="clearfix">
                                                    <li>
                                                        <Link href="#">
                                                            <i className="icon-facebook"></i>
                                                        </Link>
                                                    </li>
                                                    <li>
                                                        <Link href="#">
                                                            <i className="icon-twitter"></i>
                                                        </Link>
                                                    </li>
                                                    <li>
                                                        <Link href="#">
                                                            <i className="icon-instagram-logo"></i>
                                                        </Link>
                                                    </li>
                                                </ul>
                                            </div>
                                        </div>
                                        <div className="overlay-content">
                                            <div className="title">
                                                <h3><Link href="#">Scarlett Lavern</Link></h3>
                                            </div>
                                            <div className="border-line"></div>
                                            <div className="text">
                                                <p>Account Manager</p>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            
                            <div className="col-xl-3 col-lg-4 col-md-6">
                                <div className="team-style2__single">
                                    <div className="img-box">
                                        <div className="inner">
                                            <img src="assets/images/team/team-v2-5.jpg" alt="image"/>
                                            <div className="social-share-box">
                                                <span className="icon-share"></span>
                                                <ul className="clearfix">
                                                    <li>
                                                        <Link href="#">
                                                            <i className="icon-facebook"></i>
                                                        </Link>
                                                    </li>
                                                    <li>
                                                        <Link href="#">
                                                            <i className="icon-twitter"></i>
                                                        </Link>
                                                    </li>
                                                    <li>
                                                        <Link href="#">
                                                            <i className="icon-instagram-logo"></i>
                                                        </Link>
                                                    </li>
                                                </ul>
                                            </div>
                                        </div>
                                        <div className="overlay-content">
                                            <div className="title">
                                                <h3><Link href="#">Nora Lillian</Link></h3>
                                            </div>
                                            <div className="border-line"></div>
                                            <div className="text">
                                                <p>IT Recruitment Specialist</p>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            
                            <div className="col-xl-3 col-lg-4 col-md-6">
                                <div className="team-style2__single">
                                    <div className="img-box">
                                        <div className="inner">
                                            <img src="assets/images/team/team-v2-6.jpg" alt="image"/>
                                            <div className="social-share-box">
                                                <span className="icon-share"></span>
                                                <ul className="clearfix">
                                                    <li>
                                                        <Link href="#">
                                                            <i className="icon-facebook"></i>
                                                        </Link>
                                                    </li>
                                                    <li>
                                                        <Link href="#">
                                                            <i className="icon-twitter"></i>
                                                        </Link>
                                                    </li>
                                                    <li>
                                                        <Link href="#">
                                                            <i className="icon-instagram-logo"></i>
                                                        </Link>
                                                    </li>
                                                </ul>
                                            </div>
                                        </div>
                                        <div className="overlay-content">
                                            <div className="title">
                                                <h3><Link href="#">Scarlett Lavern</Link></h3>
                                            </div>
                                            <div className="border-line"></div>
                                            <div className="text">
                                                <p>Account Manager</p>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            
                            <div className="col-xl-3 col-lg-4 col-md-6">
                                <div className="team-style2__single">
                                    <div className="img-box">
                                        <div className="inner">
                                            <img src="assets/images/team/team-v2-7.jpg" alt="image"/>
                                            <div className="social-share-box">
                                                <span className="icon-share"></span>
                                                <ul className="clearfix">
                                                    <li>
                                                        <Link href="#">
                                                            <i className="icon-facebook"></i>
                                                        </Link>
                                                    </li>
                                                    <li>
                                                        <Link href="#">
                                                            <i className="icon-twitter"></i>
                                                        </Link>
                                                    </li>
                                                    <li>
                                                        <Link href="#">
                                                            <i className="icon-instagram-logo"></i>
                                                        </Link>
                                                    </li>
                                                </ul>
                                            </div>
                                        </div>
                                        <div className="overlay-content">
                                            <div className="title">
                                                <h3><Link href="#">Bertram Irvin</Link></h3>
                                            </div>
                                            <div className="border-line"></div>
                                            <div className="text">
                                                <p>Senior Recruiter</p>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            
                            <div className="col-xl-3 col-lg-4 col-md-6">
                                <div className="team-style2__single">
                                    <div className="img-box">
                                        <div className="inner">
                                            <img src="assets/images/team/team-v2-8.jpg" alt="image"/>
                                            <div className="social-share-box">
                                                <span className="icon-share"></span>
                                                <ul className="clearfix">
                                                    <li>
                                                        <Link href="#">
                                                            <i className="icon-facebook"></i>
                                                        </Link>
                                                    </li>
                                                    <li>
                                                        <Link href="#">
                                                            <i className="icon-twitter"></i>
                                                        </Link>
                                                    </li>
                                                    <li>
                                                        <Link href="#">
                                                            <i className="icon-instagram-logo"></i>
                                                        </Link>
                                                    </li>
                                                </ul>
                                            </div>
                                        </div>
                                        <div className="overlay-content">
                                            <div className="title">
                                                <h3><Link href="#">Michel Kyle</Link></h3>
                                            </div>
                                            <div className="border-line"></div>
                                            <div className="text">
                                                <p>Recruitment Manager</p>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>

                        </div>
                    </div>
                </section>
            </Layout>
        </div>
    )
}