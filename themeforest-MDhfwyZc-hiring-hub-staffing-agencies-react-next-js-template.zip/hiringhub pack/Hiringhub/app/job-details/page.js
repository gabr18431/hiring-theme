'use client'
import React from 'react'
import Link from "next/link"
import Layout from "@/components/layout/Layout"

export default function Job_details() {
    return (
        <div className="page-wrapper boxed_wrapper">
            <Layout headerStyle={1} footerStyle={1} breadcrumbTitle="Job Details">
                <section className="job-details-page">
                    <div className="container">
                        <div className="row">

                            <div className="col-xl-8 col-lg-7">
                                <div className="job-details-page-content">
                                    <div className="title-section">
                                        <div className="left-box">
                                            <div className="icon-box">
                                                <img src="assets/images/icon/job-openings/job-post-1-icon-1.png" alt="icon"/>
                                            </div>
                                            <div className="content-box">
                                                <div className="category-box">
                                                    <p>Full time</p>
                                                </div>
                                                <h3><Link href="/job-openings">Senior Graphic Designer</Link></h3>
                                                <p>Rochester, Newyork</p>
                                            </div>
                                        </div>
                                        <div className="right-box">
                                            <ul>
                                                <li>
                                                    <i className="icon-bookmark"></i>
                                                    <div className="overlay-box">Save this job</div>
                                                </li>
                                                <li>
                                                    <i className="icon-cloud-computing"></i>
                                                    <div className="overlay-box">download this job</div>
                                                </li>
                                            </ul>
                                        </div>
                                    </div>
                                    <div className="job-description">
                                        <h3>Job Description</h3>
                                        <p>
                                            Fail in their duty through weakness of will, which is the same as saying through
                                            shrinking from toil and pain.These cases are perfectly simple and easy to
                                            distinguish. In a free hour, when our power of choice is untram-melled and when
                                            nothing prevents our being able to do what we like best, every pleasure is to be
                                            welcomed therefore always holds in these matters.
                                        </p>
                                        <p>
                                            Same as saying through shrinking from toil and pain these cases are perfectly simple
                                            and easy to distin- guish in a free hour, when our power of choice is untrammelled
                                            and when nothing prevents our being able to do and every pain avoided but in certain
                                            circumstances and owing to the claims.
                                        </p>
                                    </div>

                                    <div className="job-responsibilities">
                                        <h3>Responsibilities</h3>
                                        <ul className="list-item clearfix">
                                            <li>
                                                <div className="icon-box">
                                                    <i className="icon-arrowhead"></i>
                                                </div>
                                                <div className="text-box">
                                                    <p>
                                                        Cases are perfectly simple and easy to distinguish. In a free hour, when
                                                        our power.
                                                    </p>
                                                </div>
                                            </li>
                                            <li>
                                                <div className="icon-box">
                                                    <i className="icon-arrowhead"></i>
                                                </div>
                                                <div className="text-box">
                                                    <p>Able to do what we like best, every pleasure is to be welcomed.</p>
                                                </div>
                                            </li>
                                            <li>
                                                <div className="icon-box">
                                                    <i className="icon-arrowhead"></i>
                                                </div>
                                                <div className="text-box">
                                                    <p>Obligations of business it will frequently occur.</p>
                                                </div>
                                            </li>
                                            <li>
                                                <div className="icon-box">
                                                    <i className="icon-arrowhead"></i>
                                                </div>
                                                <div className="text-box">
                                                    <p>
                                                        Repudiated and annoyances accepted. The wise man therefore always holds.
                                                    </p>
                                                </div>
                                            </li>
                                        </ul>
                                    </div>

                                    <div className="job-requirements">
                                        <h3>Requirements</h3>
                                        <ul className="list-item clearfix">
                                            <li>
                                                <div className="icon-box">
                                                    <i className="icon-arrowhead"></i>
                                                </div>
                                                <div className="text-box">
                                                    <div className="title">
                                                        <h4>Age</h4><span>:</span>
                                                    </div>
                                                    <div className="text">
                                                        <p>28+</p>
                                                    </div>
                                                </div>
                                            </li>
                                            <li>
                                                <div className="icon-box">
                                                    <i className="icon-arrowhead"></i>
                                                </div>
                                                <div className="text-box">
                                                    <div className="title">
                                                        <h4>Pronoun</h4><span>:</span>
                                                    </div>
                                                    <div className="text">
                                                        <p>Male/Female</p>
                                                    </div>
                                                </div>
                                            </li>
                                            <li>
                                                <div className="icon-box">
                                                    <i className="icon-arrowhead"></i>
                                                </div>
                                                <div className="text-box">
                                                    <div className="title">
                                                        <h4>Education</h4><span>:</span>
                                                    </div>
                                                    <div className="text">
                                                        <p>Bachelor Degree in Related Field</p>
                                                    </div>
                                                </div>
                                            </li>
                                            <li>
                                                <div className="icon-box">
                                                    <i className="icon-arrowhead"></i>
                                                </div>
                                                <div className="text-box">
                                                    <div className="title">
                                                        <h4>Experience</h4><span>:</span>
                                                    </div>
                                                    <div className="text">
                                                        <p>1-3 Yrs of Human Resources Leadship</p>
                                                    </div>
                                                </div>
                                            </li>
                                            <li>
                                                <div className="icon-box">
                                                    <i className="icon-arrowhead"></i>
                                                </div>
                                                <div className="text-box">
                                                    <div className="title">
                                                        <h4>Skills</h4><span>:</span>
                                                    </div>
                                                    <div className="text">
                                                        <p>Something Related this Job</p>
                                                    </div>
                                                </div>
                                            </li>
                                        </ul>
                                    </div>

                                    <div className="share-link-box">
                                        <ul className="clearfix">
                                            <li>
                                                <Link href="https://www.facebook.com/"><i className="icon-facebook"></i>Facebook</Link>
                                            </li>
                                            <li>
                                                <Link href="https://www.facebook.com/" className="bg1"><i
                                                        className="icon-share"></i>Share</Link>
                                            </li>
                                            <li>
                                                <Link href="https://www.linkedin.com/login" className="bg2"><i
                                                        className="icon-linkedin"></i>Linkedin</Link>
                                            </li>
                                            <li>
                                                <Link href="https://www.whatsapp.com/" className="bg3"><i
                                                        className="icon-whatsapp"></i>Whatsapp</Link>
                                            </li>
                                        </ul>
                                        <div className="btn-box">
                                            <a className="btn-one" href="/job-openings">
                                                <span className="txt">Click to Related Jobs</span>
                                            </a>
                                        </div>
                                    </div>

                                </div>
                            </div>

                            <div className="col-xl-4 col-lg-5">
                                <div className="job-details-page-sidebar">
                                    <div className="job-details-page-sidebar-btn">
                                        <a className="btn-one" href="apply-now.html">
                                            <span className="txt">Apply for this Job</span>
                                        </a>
                                    </div>

                                    <div className="job-details-page-sidebar-job-details">
                                        <ul className="list-item clearfix">
                                            <li>
                                                <h4>Job Number</h4>
                                                <p>2022ER</p>
                                            </li>
                                            <li>
                                                <h4>Company</h4>
                                                <p>Deepsea Shipping Logistics</p>
                                            </li>
                                            <li>
                                                <h4>Website</h4>
                                                <p><Link href="http://www.deepsea.com">http://www.deepsea.com</Link></p>
                                            </li>
                                            <li>
                                                <h4>Salary</h4>
                                                <p>$85,000 - $90,000 Per Year</p>
                                            </li>
                                            <li>
                                                <h4>Vacancy</h4>
                                                <p>05 Vacancies Available</p>
                                            </li>
                                            <li>
                                                <h4>Apply on or Before</h4>
                                                <p>28th June, 2020</p>
                                            </li>
                                        </ul>
                                    </div>

                                    <div className="job-details-page-sidebar__newsletter">
                                        <div className="job-details-page-sidebar__newsletter-bg"
                                            style={{ backgroundImage: "url(assets/images/resources/sidebar-newsletter-bg1.jpg)" }}>
                                        </div>
                                        <div className="title-box">
                                            <h3>Job Notifications</h3>
                                            <p>Subcribe & Receive job updates.</p>
                                        </div>
                                        <div className="job-details-page-sidebar__form">
                                            <form action="index.html" method="post">
                                                <div className="form-group">
                                                    <input type="email" name="email" placeholder="Enter your email..."
                                                        required=""/>
                                                </div>
                                                <div className="checked-box1">
                                                    <input type="checkbox" name="skipper1" id="agree"/>
                                                    <label for="agree">
                                                        <span></span>I agree to the Privacy Policy.
                                                    </label>
                                                </div>
                                                <div className="btn-box">
                                                    <button className="submit btn-one">
                                                        <span className="txt">Subscribe Us</span>
                                                    </button>
                                                </div>
                                            </form>
                                        </div>
                                    </div>

                                </div>
                            </div>

                        </div>
                    </div>
                </section>
            </Layout>
        </div>
    )
}