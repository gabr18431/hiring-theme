'use client'
import React from 'react'
import Link from "next/link"
import Layout from "@/components/layout/Layout"
import CounterUp from "@/components/elements/CounterUp"
import { Autoplay, Navigation, Pagination } from "swiper/modules"
import { Swiper, SwiperSlide } from "swiper/react"
import Service_Two from '@/components/sections/home2/Service_Two'
import Pricing from '@/components/sections/home1/Pricing'
import Partner from '@/components/sections/home1/Partner'
const swiperOptions = {
    modules: [Autoplay, Pagination, Navigation],
    slidesPerView: 1,
    spaceBetween: 0,
    autoplay: {
        delay: 5000,
        disableOnInteraction: false,
    },
    loop: true,

    // Navigation
    navigation: {
        nextEl: '.swiper-button-prev',
        prevEl: '.swiper-button-next',
    },

    breakpoints: {
        320: {
            slidesPerView: 1,
            spaceBetween: 0,
        },
        575: {
            slidesPerView: 1,
            spaceBetween: 0,
        },
        767: {
            slidesPerView: 2,
            spaceBetween: 0,
        },
        991: {
            slidesPerView: 2,
            spaceBetween: 0,
        },
        1199: {
            slidesPerView: 3,
            spaceBetween: 0,
        },
        1750: {
            slidesPerView: 4,
            spaceBetween: 0,
        },
    }
}

export default function Overview_page() {
    return (
        <div className="page-wrapper boxed_wrapper">
            <Layout headerStyle={1} footerStyle={1} breadcrumbTitle="Overview">
                <section className="fact-counter-style2">
                    <div className="container">
                        <div className="sec-title withtext text-center">
                            <div className="sub-title">
                                <h4>Partnering for Success</h4>
                            </div>
                            <h2>Optimize Your Staffing Methods</h2>
                            <div className="text">
                                <p>
                                    Long established fact that a reader will be distracted by the<br/>readable content of a page.
                                </p>
                            </div>
                        </div>

                        <ul className="row fact-counter-style2--row">
                            <li className="col-xl-3 col-lg-3 col-md-6 text-center">
                                <div className="fact-counter-style1__single fact-counter-style1__single--style2">
                                    <div className="fact-counter-box">
                                        <div className="round-box"></div>
                                        <div className="counter-box">
                                            <h2>
                                                <span className="odometer"><CounterUp end={24} /></span>
                                                <span className="k">k</span>
                                            </h2>
                                        </div>
                                        <p>Employees hired in<br/>last year</p>
                                    </div>
                                </div>
                            </li>
                            
                            <li className="col-xl-3 col-lg-3 col-md-6 text-center">
                                <div className="fact-counter-style1__single fact-counter-style1__single--style2">
                                    <div className="fact-counter-box">
                                        <div className="round-box"></div>
                                        <div className="counter-box">
                                            <h2>
                                                <span className="odometer"><CounterUp end={839} /></span>
                                            </h2>
                                        </div>
                                        <p>Employers formed in<br/>last year</p>
                                    </div>
                                </div>
                            </li>
                            
                            <li className="col-xl-3 col-lg-3 col-md-6 text-center">
                                <div className="fact-counter-style1__single fact-counter-style1__single--style2">
                                    <div className="fact-counter-box">
                                        <div className="round-box"></div>
                                        <div className="counter-box">
                                            <h2>
                                                <span className="odometer"><CounterUp end={36} /></span>
                                                <span className="k">+</span>
                                            </h2>
                                        </div>
                                        <p>Countries Served by<br/>our team</p>
                                    </div>
                                </div>
                            </li>
                            
                            <li className="col-xl-3 col-lg-3 col-md-6 text-center">
                                <div className="fact-counter-style1__single fact-counter-style1__single--style2">
                                    <div className="fact-counter-box">
                                        <div className="round-box"></div>
                                        <div className="counter-box">
                                            <h2>
                                                <span className="odometer"><CounterUp end={99} /></span>
                                                <span className="k">%</span>
                                            </h2>
                                        </div>
                                        <p>Client Successful<br/>Rate</p>
                                    </div>
                                </div>
                            </li>
                        </ul>

                    </div>
                </section>

                <section className="page-banner">
                    <div className="container">
                        <div className="page-banner__inner">
                            <div className="page-banner__shape">
                                <img src="assets/images/shapes/page-banner__shape1.png" alt="shape"/>
                            </div>
                            <div className="page-banner__content">
                                <div className="sub-title">
                                    <h3>Seeking Qualified</h3>
                                </div>
                                <div className="big-title">Candidates</div>
                                <div className="title-box">
                                    <h3>For Employement?</h3>
                                    <p>Beguiled and demoralized by the charms of pleasure moment.</p>
                                </div>
                                <div className="btn-box">
                                    <Link className="btn-one" href="/employers-overview">
                                        <span className="txt">Start Hiring</span>
                                    </Link>
                                </div>
                            </div>
                            <div className="page-banner__img"
                                style={{ backgroundImage: "url(assets/images/resources/page-banner__img1.jpg)" }}>
                            </div>
                        </div>
                    </div>
                </section>

                <section className="service-style5">
                    <div className="container">
                        <div className="sec-title withtext text-center">
                            <div className="sub-title">
                                <h4>Solutions we provide</h4>
                            </div>
                            <h2>Innovative Solutions for Talents</h2>
                            <div className="text">
                                <p>
                                    Long established fact that a reader will be distracted by the<br/>readable content of a page.
                                </p>
                            </div>
                        </div>
                        <div className="service-style5__inner">
                            <div className="service-style5__img-box">
                                <div className="service-style5__img-box-bg"
                                    style={{ backgroundImage: "url(assets/images/services/service-v5-1.jpg)" }}>
                                </div>
                            </div>

                            <Swiper {...swiperOptions} className="swiper-container service-style5-carousel">
                                <SwiperSlide>
                                    <div className="service-style5__single">
                                        <div className="stap-box">
                                            <p>Service 01</p>
                                        </div>
                                        <div className="title-box">
                                            <h3><Link href="/solution01-temporary-stafing">Temporary Staffing</Link></h3>
                                        </div>
                                        <div className="icon-box">
                                            <div className="icon-box__bg">
                                                <img src="assets/images/shapes/service-style5-icon-bg1.png" alt="Img"/>
                                            </div>
                                            <div className="icon-box__bg-overlay">
                                                <img src="assets/images/shapes/service-style5-icon-overlay-bg1.png" alt="Img"/>
                                            </div>
                                            <img src="assets/images/icon/services/service-icon-2-1.png" alt="icon"/>
                                        </div>
                                        <div className="text">
                                            <p>
                                                The wise man therefore always holds in<br/>these matters to this one...
                                            </p>
                                        </div>
                                        <div className="btn-box">
                                            <Link href="/solution01-temporary-stafing">
                                                Hire Now
                                                <span className="icon-arrow-angle-pointing-to-right"></span>
                                                <span className="icon-right-arrow-1 arrow-hover"></span>
                                            </Link>
                                        </div>
                                    </div>
                                </SwiperSlide>
                                <SwiperSlide>
                                    <div className="service-style5__single">
                                        <div className="stap-box">
                                            <p>Service 02</p>
                                        </div>
                                        <div className="title-box">
                                            <h3><Link href="/solution02-contract-stafing">Contract Staffing</Link></h3>
                                        </div>
                                        <div className="icon-box">
                                            <div className="icon-box__bg">
                                                <img src="assets/images/shapes/service-style5-icon-bg1.png" alt="bg"/>
                                            </div>
                                            <div className="icon-box__bg-overlay">
                                                <img src="assets/images/shapes/service-style5-icon-overlay-bg1.png" alt="bg"/>
                                            </div>
                                            <img src="assets/images/icon/services/service-icon-2-2.png" alt="icon"/>
                                        </div>
                                        <div className="text">
                                            <p>
                                                Right to find fault with a man chooses all
                                                annoying to be consequences...
                                            </p>
                                        </div>
                                        <div className="btn-box">
                                            <Link href="/solution02-contract-stafing">
                                                Hire Now
                                                <span className="icon-arrow-angle-pointing-to-right"></span>
                                                <span className="icon-right-arrow-1 arrow-hover"></span>
                                            </Link>
                                        </div>
                                    </div>
                                </SwiperSlide>
                                <SwiperSlide>
                                    <div className="service-style5__single">
                                        <div className="stap-box">
                                            <p>Service 03</p>
                                        </div>
                                        <div className="title-box">
                                            <h3><Link href="/solution03-project-based">Project Based Hiring</Link></h3>
                                        </div>
                                        <div className="icon-box">
                                            <div className="icon-box__bg">
                                                <img src="assets/images/shapes/service-style5-icon-bg1.png" alt="bg"/>
                                            </div>
                                            <div className="icon-box__bg-overlay">
                                                <img src="assets/images/shapes/service-style5-icon-overlay-bg1.png" alt="bg"/>
                                            </div>
                                            <img src="assets/images/icon/services/service-icon-2-3.png" alt="icon"/>
                                        </div>
                                        <div className="text">
                                            <p>
                                                Occasionally circumstances occur in pain
                                                procure some great content...
                                            </p>
                                        </div>
                                        <div className="btn-box">
                                            <Link href="/solution03-project-based">
                                                Hire Now
                                                <span className="icon-arrow-angle-pointing-to-right"></span>
                                                <span className="icon-right-arrow-1 arrow-hover"></span>
                                            </Link>
                                        </div>
                                    </div>
                                </SwiperSlide>
                                <SwiperSlide>
                                    <div className="service-style5__single">
                                        <div className="stap-box">
                                            <p>Service 04</p>
                                        </div>
                                        <div className="title-box">
                                            <h3><Link href="/solution04-permanent-stafing">Permanent Staffing</Link></h3>
                                        </div>
                                        <div className="icon-box">
                                            <div className="icon-box__bg">
                                                <img src="assets/images/shapes/service-style5-icon-bg1.png" alt="bg"/>
                                            </div>
                                            <div className="icon-box__bg-overlay">
                                                <img src="assets/images/shapes/service-style5-icon-overlay-bg1.png" alt="bg"/>
                                            </div>
                                            <img src="assets/images/icon/services/service-icon-2-4.png" alt="icon"/>
                                        </div>
                                        <div className="text">
                                            <p>
                                                The claims off duty or the obligations of
                                                business it will frequently occur that...
                                            </p>
                                        </div>
                                        <div className="btn-box">
                                            <Link href="/solution04-permanent-stafing">
                                                Hire Now
                                                <span className="icon-arrow-angle-pointing-to-right"></span>
                                                <span className="icon-right-arrow-1 arrow-hover"></span>
                                            </Link>
                                        </div>
                                    </div>
                                </SwiperSlide>
                            </Swiper>

                            <div className="swiper-nav-style-one">
                                <button className="swiper-button-prev">
                                    <span className="left icon-left-arrow-angle-big-gross-symbol"></span>
                                </button>
                                <button className="swiper-button-next">
                                    <span className="right icon-arrow-angle-pointing-to-right"></span>
                                </button>
                            </div>
                        </div>
                    </div>
                </section>
                <Service_Two/>
                <section className="essential-guide-style1">
                    <div className="container">
                        <div className="sec-title withtext text-center">
                            <div className="sub-title">
                                <h4>Essential Guide</h4>
                            </div>
                            <h2>Discover Fundamental Essentials</h2>
                            <div className="text">
                                <p>
                                    Long established fact that a reader will be distracted by the<br/>readable content of a page.
                                </p>
                            </div>
                        </div>
                        <div className="row">
                            <div className="col-xl-4 col-lg-6 col-md-6">
                                <div className="single-essential-guide-style1">
                                    <div className="img-box">
                                        <div className="icon-box">
                                            <img src="assets/images/icon/essential-guide/essential-guide-style1-icon-1.png"
                                                alt="icon"/>
                                        </div>
                                        <div className="inner">
                                            <img src="assets/images/resources/essential-guide-v1-1.jpg" alt="image"/>
                                        </div>
                                        <div className="overlay-title">
                                            <div className="arrow-right"
                                                style={{ backgroundImage: "url(assets/images/shapes/arrow-1.png)" }}></div>
                                            <h3><Link href="/employers-overview">Post Your Need</Link></h3>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            
                            <div className="col-xl-4 col-lg-6 col-md-6">
                                <div className="single-essential-guide-style1">
                                    <div className="img-box">
                                        <div className="icon-box">
                                            <img src="assets/images/icon/essential-guide/essential-guide-style1-icon-2.png"
                                                alt="icon"/>
                                        </div>
                                        <div className="inner">
                                            <img src="assets/images/resources/essential-guide-v1-2.jpg" alt="image"/>
                                        </div>
                                        <div className="overlay-title">
                                            <div className="arrow-right"
                                                style={{ backgroundImage: "url(assets/images/shapes/arrow-1.png)" }}></div>
                                            <h3><Link href="/employers-overview">Executive Search</Link></h3>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            
                            <div className="col-xl-4 col-lg-6 col-md-6">
                                <div className="single-essential-guide-style1">
                                    <div className="img-box">
                                        <div className="icon-box">
                                            <img src="assets/images/icon/essential-guide/essential-guide-style1-icon-3.png"
                                                alt="icon"/>
                                        </div>
                                        <div className="inner">
                                            <img src="assets/images/resources/essential-guide-v1-3.jpg" alt="image"/>
                                        </div>
                                        <div className="overlay-title">
                                            <div className="arrow-right"
                                                style={{ backgroundImage: "url(assets/images/shapes/arrow-1.png)" }}></div>
                                            <h3><Link href="/employers-overview">News & Updates</Link></h3>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </section>
                <Pricing/>
                <Partner/>
            </Layout>
        </div>
    )
}