import Layout from "@/components/layout/Layout"
import About from "@/components/sections/home1/About"
import Banner from "@/components/sections/home1/Banner"
import Blog from "@/components/sections/home1/Blog"
import Choose from "@/components/sections/home1/Choose"
import Industries from "@/components/sections/home1/Industries"
import Partner from "@/components/sections/home1/Partner"
import Pricing from "@/components/sections/home1/Pricing"
import Service from "@/components/sections/home1/Service"
import Slogan from "@/components/sections/home1/Slogan"
import Testimonials from "@/components/sections/home1/Testmonials"
import Welcome from "@/components/sections/home1/Welcome"
import Work from "@/components/sections/home1/Work"
export default function Home() {

    return (
        <div className="page-wrapper boxed_wrapper">
            <Layout headerStyle={1} footerStyle={1}>
                <Banner/>
                <Welcome/>
                <Service/>
                <Choose/>
                <Slogan/>
                <About/>
                <Industries/>
                <Work/>
                <Pricing/>
                <Blog/>
                <Testimonials/>
                <Partner/>
            </Layout>
        </div>
    )
}