import Layout from "@/components/layout/Layout"
import Choose from "@/components/sections/home1/Choose"
import Slogan from "@/components/sections/home1/Slogan"
import About from "@/components/sections/home2/About"
import Award from "@/components/sections/home2/Award"
import Banner from "@/components/sections/home2/Banner"
import Blog from "@/components/sections/home2/Blog"
import Case from "@/components/sections/home2/Case"
import Service from "@/components/sections/home2/Service"
import Service_Two from "@/components/sections/home2/Service_Two"
import Team from "@/components/sections/home2/Team"
import Testimonial from "@/components/sections/home2/Testimonial"
import Touch from "@/components/sections/home2/Touch"
export default function Home_Two() {

    return (
        <div className="page-wrapper boxed_wrapper">
            <Layout headerStyle={2} footerStyle={2}>
                <Banner/>
                <Service/>
                <About/>
                <Case/>
                <Service_Two/>
                <Choose/>
                <Slogan/>
                <Team/>
                <Award/>
                <Testimonial/>
                <Blog/>
                <Touch/>
            </Layout>
        </div>
    )
}