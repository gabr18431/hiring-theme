'use client'
import React from 'react'
import Link from "next/link"
import Layout from "@/components/layout/Layout"

export default function Blog_three() {
    return (
        <div className="page-wrapper boxed_wrapper">
            <Layout headerStyle={1} footerStyle={1} breadcrumbTitle="List View 01">
                <section className="blog-page-three">
                    <div className="container">
                        <div className="row">

                            <div className="col-xl-8 col-lg-7 col-md-12">
                                <div className="blog-page-three__inner">


                                    <div className="blog-style1__single blog-style1__single--2">
                                        <div className="author-info">
                                            <div className="author-info__img">
                                                <img src="assets/images/blog/blog-v1-author-info1.jpg" alt="image"/>
                                            </div>
                                            <div className="author-info__text">
                                                <h5>Boone Gerardo</h5>
                                                <ul className="clearfix">
                                                    <li>
                                                        <Link href="#">Nov 15, 2025</Link>
                                                    </li>
                                                    <li>
                                                        <Link href="#">2 Comments</Link>
                                                    </li>
                                                    <li>
                                                        <Link href="#">25 Views</Link>
                                                    </li>
                                                    <li>
                                                        <Link href="#">10 Likes</Link>
                                                    </li>
                                                </ul>
                                            </div>
                                        </div>
                                        <div className="blog-style1__single-img">
                                            <div className="category-box">
                                                <p>News & Tips</p>
                                            </div>
                                            <img src="assets/images/blog/blog-p3-1.jpg" alt="image"/>
                                        </div>
                                        <div className="blog-style-2__single-content">
                                            <div className="title-box">
                                                <h3>
                                                    <Link href="/blog-single">
                                                        Unlocking Success: Top Eight Tips for Leadership Recruitment.
                                                    </Link>
                                                </h3>
                                            </div>
                                            <div className="text-box">
                                                <p>
                                                    Every pain avoided but in certain circumstances and owing to the claims of
                                                    duty or the therefore always holds in these matters to this principle
                                                    consequences...
                                                </p>
                                            </div>
                                            <div className="blog-style1__single-btn blog-style1__single-btn--2">
                                                <div className="left">
                                                    <p>2 Mins Read</p>
                                                </div>
                                                <div className="right">
                                                    <Link href="/blog-single">Continue Reading
                                                        <span className="icon-arrow-angle-pointing-to-right"></span>
                                                        <span className="icon-right-arrow-1 arrow-hover"></span>
                                                    </Link>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    
                                    <div className="blog-style1__single blog-style1__single--2">
                                        <div className="author-info">
                                            <div className="author-info__img">
                                                <img src="assets/images/blog/blog-v1-author-info2.jpg" alt="image"/>
                                            </div>
                                            <div className="author-info__text">
                                                <h5>Harley Reuban</h5>
                                                <ul className="clearfix">
                                                    <li>
                                                        <Link href="#">Oct 24, 2025</Link>
                                                    </li>
                                                    <li>
                                                        <Link href="#">3 Comments</Link>
                                                    </li>
                                                    <li>
                                                        <Link href="#">40 Views</Link>
                                                    </li>
                                                    <li>
                                                        <Link href="#">25 Likes</Link>
                                                    </li>
                                                </ul>
                                            </div>
                                        </div>
                                        <div className="blog-style1__single-img">
                                            <div className="category-box">
                                                <p>Job Seekers</p>
                                            </div>
                                            <img src="assets/images/blog/blog-p3-2.jpg" alt="image"/>
                                        </div>
                                        <div className="blog-style-2__single-content">
                                            <div className="title-box">
                                                <h3>
                                                    <Link href="/blog-single">
                                                        Navigating remote work: Six tips for employers & employees.
                                                    </Link>
                                                </h3>
                                            </div>
                                            <div className="text-box">
                                                <p>
                                                    Denounce with righteous indignation and dislike men who are so beguiled
                                                    demoralized by the charms of pleasure of the moment how to pursue pleasure
                                                    rationally...
                                                </p>
                                            </div>
                                            <div className="blog-style1__single-btn blog-style1__single-btn--2">
                                                <div className="left">
                                                    <p>3 Mins Read</p>
                                                </div>
                                                <div className="right">
                                                    <Link href="/blog-single">Continue Reading
                                                        <span className="icon-arrow-angle-pointing-to-right"></span>
                                                        <span className="icon-right-arrow-1 arrow-hover"></span>
                                                    </Link>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    
                                    <div className="blog-style1__single blog-style1__single--2">
                                        <div className="author-info">
                                            <div className="author-info__img">
                                                <img src="assets/images/blog/blog-v1-author-info3.jpg" alt="image"/>
                                            </div>
                                            <div className="author-info__text">
                                                <h5>Dahlia Bianca</h5>
                                                <ul className="clearfix">
                                                    <li>
                                                        <Link href="#">Oct 10, 2025</Link>
                                                    </li>
                                                    <li>
                                                        <Link href="#">8 Comments</Link>
                                                    </li>
                                                </ul>
                                            </div>
                                        </div>
                                        <div className="blog-style1__single-img">
                                            <div className="category-box">
                                                <p>Human Resource</p>
                                            </div>
                                            <img src="assets/images/blog/blog-p3-3.jpg" alt="image"/>
                                        </div>
                                        <div className="blog-style-2__single-content">
                                            <div className="title-box">
                                                <h3>
                                                    <Link href="/blog-single">
                                                        Hiringhub chosen for crown commer-cial's staffing services.
                                                    </Link>
                                                </h3>
                                            </div>
                                            <div className="text-box">
                                                <p>
                                                    How to pursue pleasure rationally encounter consequences that are extremely
                                                    painful nor again is there anyone who loves or pursues or desires to obtain
                                                    pain...
                                                </p>
                                            </div>
                                            <div className="blog-style1__single-btn blog-style1__single-btn--2">
                                                <div className="left">
                                                    <p>5 Mins Read</p>
                                                </div>
                                                <div className="right">
                                                    <Link href="/blog-single">Continue Reading
                                                        <span className="icon-arrow-angle-pointing-to-right"></span>
                                                        <span className="icon-right-arrow-1 arrow-hover"></span>
                                                    </Link>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    
                                    <div className="blog-style1__single blog-style1__single--2">
                                        <div className="author-info">
                                            <div className="author-info__img">
                                                <img src="assets/images/blog/blog-v1-author-info1.jpg" alt="image"/>
                                            </div>
                                            <div className="author-info__text">
                                                <h5>Boone Gerardo</h5>
                                                <ul className="clearfix">
                                                    <li>
                                                        <Link href="#">Nov 15, 2025</Link>
                                                    </li>
                                                    <li>
                                                        <Link href="#">2 Comments</Link>
                                                    </li>
                                                    <li>
                                                        <Link href="#">25 Views</Link>
                                                    </li>
                                                    <li>
                                                        <Link href="#">10 Likes</Link>
                                                    </li>
                                                </ul>
                                            </div>
                                        </div>
                                        <div className="blog-style1__single-img">
                                            <div className="category-box">
                                                <p>News & Tips</p>
                                            </div>
                                            <img src="assets/images/blog/blog-p3-4.jpg" alt="image"/>
                                        </div>
                                        <div className="blog-style-2__single-content">
                                            <div className="title-box">
                                                <h3>
                                                    <Link href="/blog-single">
                                                        Unlocking Success: Top Eight Tips for Leadership Recruitment.
                                                    </Link>
                                                </h3>
                                            </div>
                                            <div className="text-box">
                                                <p>
                                                    Every pain avoided but in certain circumstances and owing to the claims of
                                                    duty or the therefore always holds in these matters to this principle
                                                    consequences...
                                                </p>
                                            </div>
                                            <div className="blog-style1__single-btn blog-style1__single-btn--2">
                                                <div className="left">
                                                    <p>2 Mins Read</p>
                                                </div>
                                                <div className="right">
                                                    <Link href="/blog-single">Continue Reading
                                                        <span className="icon-arrow-angle-pointing-to-right"></span>
                                                        <span className="icon-right-arrow-1 arrow-hover"></span>
                                                    </Link>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    
                                    <div className="blog-style1__single blog-style1__single--2">
                                        <div className="author-info">
                                            <div className="author-info__img">
                                                <img src="assets/images/blog/blog-v1-author-info2.jpg" alt="image"/>
                                            </div>
                                            <div className="author-info__text">
                                                <h5>Harley Reuban</h5>
                                                <ul className="clearfix">
                                                    <li>
                                                        <Link href="#">Oct 24, 2025</Link>
                                                    </li>
                                                    <li>
                                                        <Link href="#">3 Comments</Link>
                                                    </li>
                                                    <li>
                                                        <Link href="#">40 Views</Link>
                                                    </li>
                                                    <li>
                                                        <Link href="#">25 Likes</Link>
                                                    </li>
                                                </ul>
                                            </div>
                                        </div>
                                        <div className="blog-style1__single-img">
                                            <div className="category-box">
                                                <p>Job Seekers</p>
                                            </div>
                                            <img src="assets/images/blog/blog-p3-5.jpg" alt="image"/>
                                        </div>
                                        <div className="blog-style-2__single-content">
                                            <div className="title-box">
                                                <h3>
                                                    <Link href="/blog-single">
                                                        Navigating remote work: Six tips for<br/>employers & employees.
                                                    </Link>
                                                </h3>
                                            </div>
                                            <div className="text-box">
                                                <p>
                                                    Denounce with righteous indignation and dislike men who are so beguiled
                                                    demoralized by the charms of pleasure of the moment how to pursue pleasure
                                                    rationally...
                                                </p>
                                            </div>
                                            <div className="blog-style1__single-btn blog-style1__single-btn--2">
                                                <div className="left">
                                                    <p>3 Mins Read</p>
                                                </div>
                                                <div className="right">
                                                    <Link href="/blog-single">Continue Reading
                                                        <span className="icon-arrow-angle-pointing-to-right"></span>
                                                        <span className="icon-right-arrow-1 arrow-hover"></span>
                                                    </Link>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    
                                    <div className="blog-style1__single blog-style1__single--2">
                                        <div className="author-info">
                                            <div className="author-info__img">
                                                <img src="assets/images/blog/blog-v1-author-info3.jpg" alt="image"/>
                                            </div>
                                            <div className="author-info__text">
                                                <h5>Dahlia Bianca</h5>
                                                <ul className="clearfix">
                                                    <li>
                                                        <Link href="#">Oct 10, 2025</Link>
                                                    </li>
                                                    <li>
                                                        <Link href="#">8 Comments</Link>
                                                    </li>
                                                </ul>
                                            </div>
                                        </div>
                                        <div className="blog-style1__single-img">
                                            <div className="category-box">
                                                <p>Human Resource</p>
                                            </div>
                                            <img src="assets/images/blog/blog-p3-6.jpg" alt="image"/>
                                        </div>
                                        <div className="blog-style-2__single-content">
                                            <div className="title-box">
                                                <h3>
                                                    <Link href="/blog-single">
                                                        Hiringhub chosen for crown commer-cial's staffing services.
                                                    </Link>
                                                </h3>
                                            </div>
                                            <div className="text-box">
                                                <p>
                                                    How to pursue pleasure rationally encounter consequences that are extremely
                                                    painful nor again is there anyone who loves or pursues or desires to obtain
                                                    pain...
                                                </p>
                                            </div>
                                            <div className="blog-style1__single-btn blog-style1__single-btn--2">
                                                <div className="left">
                                                    <p>5 Mins Read</p>
                                                </div>
                                                <div className="right">
                                                    <Link href="/blog-single">Continue Reading
                                                        <span className="icon-arrow-angle-pointing-to-right"></span>
                                                        <span className="icon-right-arrow-1 arrow-hover"></span>
                                                    </Link>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div className="col-xl-4 col-lg-5 col-md-7">
                                <div className="sidebar-box-style1 sidebar-box-style1--style2">

                                    <div className="sidebar-search-box-one">
                                        <form className="search-form" action="#">
                                            <input placeholder="Search..." type="text"/>
                                            <button type="submit">
                                                <i className="icon-search"></i>
                                            </button>
                                        </form>
                                    </div>

                                    <div className="single-sidebar-box">
                                        <div className="sidebar-title">
                                            <h3>Categories</h3>
                                        </div>
                                        <div className="sidebar-categories-box">
                                            <ul className="list-item clearfix">
                                                <li>
                                                    <div className="icon">
                                                        <span className="icon-down-right-arrow"></span>
                                                    </div>
                                                    <div className="text">
                                                        <Link href="#">
                                                            Employer
                                                            <i className="icon-down-right-arrow arrow-hover"></i>
                                                        </Link>
                                                    </div>
                                                </li>
                                                <li>
                                                    <div className="icon">
                                                        <span className="icon-down-right-arrow"></span>
                                                    </div>
                                                    <div className="text">
                                                        <Link href="#">
                                                            Hiring Tips
                                                            <i className="icon-down-right-arrow arrow-hover"></i>
                                                        </Link>
                                                    </div>
                                                </li>
                                                <li>
                                                    <div className="icon">
                                                        <span className="icon-down-right-arrow"></span>
                                                    </div>
                                                    <div className="text">
                                                        <Link href="#">
                                                            Human Resourse
                                                            <i className="icon-down-right-arrow arrow-hover"></i>
                                                        </Link>
                                                    </div>
                                                </li>
                                                <li>
                                                    <div className="icon">
                                                        <span className="icon-down-right-arrow"></span>
                                                    </div>
                                                    <div className="text">
                                                        <Link href="#">
                                                            Job Seekers
                                                            <i className="icon-down-right-arrow arrow-hover"></i>
                                                        </Link>
                                                    </div>
                                                </li>
                                                <li>
                                                    <div className="icon">
                                                        <span className="icon-down-right-arrow"></span>
                                                    </div>
                                                    <div className="text">
                                                        <Link href="#">
                                                            Market Analysis
                                                            <i className="icon-down-right-arrow arrow-hover"></i>
                                                        </Link>
                                                    </div>
                                                </li>
                                                <li>
                                                    <div className="icon">
                                                        <span className="icon-down-right-arrow"></span>
                                                    </div>
                                                    <div className="text">
                                                        <Link href="#">
                                                            News & Tips
                                                            <i className="icon-down-right-arrow arrow-hover"></i>
                                                        </Link>
                                                    </div>
                                                </li>
                                                <li>
                                                    <div className="icon">
                                                        <span className="icon-down-right-arrow"></span>
                                                    </div>
                                                    <div className="text">
                                                        <Link href="#">
                                                            Startups
                                                            <i className="icon-down-right-arrow arrow-hover"></i>
                                                        </Link>
                                                    </div>
                                                </li>
                                            </ul>
                                        </div>
                                    </div>

                                    <div className="single-sidebar-box">
                                        <div className="sidebar-title">
                                            <h3>Popular Post</h3>
                                        </div>
                                        <div className="sidebar-blog-post">
                                            <ul className="clearfix">
                                                <li>
                                                    <div className="overlay-img">
                                                        <img src="assets/images/resources/sidebar-blog-post-img-1.jpg"
                                                            alt="image"/>
                                                    </div>
                                                    <div className="category-box">
                                                        <p>News & Tips</p>
                                                    </div>
                                                    <div className="title-box">
                                                        <h3>
                                                            <Link href="#">Utilizing Technology in the<br/>Hiring Process.</Link>
                                                        </h3>
                                                    </div>
                                                    <div className="btn-box">
                                                        <Link href="/blog-single"><span className="icon-right-arrow-1"></span></Link>
                                                        <div className="overlay-btn">
                                                            <Link href="/blog-single">Read More
                                                                <span className="icon-arrow-angle-pointing-to-right"></span>
                                                            </Link>
                                                        </div>
                                                    </div>
                                                </li>
                                                <li>
                                                    <div className="overlay-img">
                                                        <img src="assets/images/resources/sidebar-blog-post-img-1.jpg"
                                                            alt="image"/>
                                                    </div>
                                                    <div className="category-box">
                                                        <p>Job Seekers</p>
                                                    </div>
                                                    <div className="title-box">
                                                        <h3>
                                                            <Link href="#">Navigating Legalities in Staf-<br/>fing and Hiring.</Link>
                                                        </h3>
                                                    </div>
                                                    <div className="btn-box">
                                                        <Link href="/blog-single"><span className="icon-right-arrow-1"></span></Link>
                                                        <div className="overlay-btn">
                                                            <Link href="/blog-single">Read More
                                                                <span className="icon-arrow-angle-pointing-to-right"></span>
                                                            </Link>
                                                        </div>
                                                    </div>
                                                </li>
                                            </ul>
                                        </div>
                                    </div>

                                    <div className="single-sidebar-box">
                                        <div className="sidebar-title">
                                            <h3>Popular Tag</h3>
                                        </div>
                                        <div className="sidebar-blog-tag">
                                            <ul className="clearfix">
                                                <li><Link href="/about">company</Link></li>
                                                <li><Link href="/contact">contract</Link></li>
                                                <li><Link href="#">events</Link></li>
                                                <li><Link href="#">hiring</Link></li>
                                                <li><Link href="#">indutries</Link></li>
                                                <li><Link href="/job-seekers-overview">job seekers</Link></li>
                                                <li><Link href="/solution06-outsourcing">outsourcing</Link></li>
                                                <li><Link href="#">recruiters</Link></li>
                                                <li><Link href="#">trends</Link></li>
                                                <li><Link href="#">timesheets</Link></li>
                                            </ul>
                                        </div>
                                    </div>

                                    <div className="single-sidebar-box">
                                        <div className="sidebar-blog-banner text-center">
                                            <div className="sidebar-blog-banner__shape1"
                                                style={{ backgroundImage: "url(assets/images/shapes/sidebar-blog-banner__shape1.png)" }}>
                                            </div>
                                            <div className="icon">
                                                <i className="icon-tie-1"></i>
                                            </div>
                                            <div className="title">
                                                <h3>Solution to</h3>
                                                <h2>Staffing Problems</h2>
                                            </div>
                                            <div className="text">
                                                <p>Except to obtain advantage.</p>
                                            </div>
                                            <div className="btn-box">
                                                <Link className="btn-one" href="/blog-single">
                                                    <span className="txt">Learn More</span>
                                                </Link>
                                            </div>
                                        </div>
                                    </div>

                                </div>
                            </div>

                        </div>

                        <div className="row">
                            <div className="col-xl-12">
                                <ul className="styled-pagination pdtop0 blog-three-page clearfix text-center">
                                    <li className="arrow prev">
                                        <Link href="#"><span className="icon-left-arrow-angle-big-gross-symbol left"></span></Link>
                                    </li>
                                    <li className="active"><Link href="#">01</Link></li>
                                    <li><Link href="#">02</Link></li>
                                    <li><Link href="#">03</Link></li>
                                    <li className="arrow next">
                                        <Link href="#"><span className="icon-arrow-angle-pointing-to-right right"></span></Link>
                                    </li>
                                </ul>
                            </div>
                        </div>

                    </div>
                </section>
            </Layout>
        </div>
    )
}