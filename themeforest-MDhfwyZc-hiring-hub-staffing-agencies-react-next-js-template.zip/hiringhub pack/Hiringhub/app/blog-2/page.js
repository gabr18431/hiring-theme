'use client'
import React from 'react'
import Link from "next/link"
import Layout from "@/components/layout/Layout"

export default function Blog_two() {
    return (
        <div className="page-wrapper boxed_wrapper">
            <Layout headerStyle={1} footerStyle={1} breadcrumbTitle="Grid View 02">
                <section className="blog-page-two">
                    <div className="container">
                        <div className="blog-page-two__inner">
                            <div className="row masonary-layout">

                                <div className="col-xl-4 col-lg-4 col-md-6">
                                    <div className="blog-style3__single blog-style2__single--style4">
                                        <div className="author-info">
                                            <div className="author-info__img">
                                                <img src="assets/images/blog/blog-v1-author-info1.jpg" alt="image"/>
                                            </div>
                                            <div className="author-info__text">
                                                <h5>Boone Gerardo</h5>
                                                <ul className="clearfix">
                                                    <li>
                                                        <Link href="#">Nov 15, 2025</Link>
                                                    </li>
                                                    <li>
                                                        <Link href="#">2 Comments</Link>
                                                    </li>
                                                </ul>
                                            </div>
                                        </div>
                                        <div className="category-box">
                                            <p>News & Tips</p>
                                        </div>
                                        <div className="title-box">
                                            <h3>
                                                <Link href="/blog-single">
                                                    Unlocking Success: Top<br/> Eight Tips for Leadership <br/>Recruitment.
                                                </Link>
                                            </h3>
                                        </div>
                                        <div className="text">
                                            <p>Cases are perfectly simple and easy to<br/>distinguish in a free hour...</p>
                                        </div>
                                        <div className="blog-style3__single-btn">
                                            <div className="left">
                                                <p>2 Mins Read</p>
                                            </div>
                                            <div className="right">
                                                <Link href="/blog-single"><span className="icon-right-arrow-1"></span></Link>
                                                <div className="overlay-btn">
                                                    <Link href="/blog-single">Read More
                                                        <span className="icon-arrow-angle-pointing-to-right"></span>
                                                    </Link>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                
                                <div className="col-xl-4 col-lg-4 col-md-6">
                                    <div className="blog-style3__single blog-style2__single--style4">
                                        <div className="author-info">
                                            <div className="author-info__img">
                                                <img src="assets/images/blog/blog-v1-author-info2.jpg" alt="image"/>
                                            </div>
                                            <div className="author-info__text">
                                                <h5>Harley Reuban</h5>
                                                <ul className="clearfix">
                                                    <li>
                                                        <Link href="#">Oct 24, 2025</Link>
                                                    </li>
                                                    <li>
                                                        <Link href="#">3 Comments</Link>
                                                    </li>
                                                </ul>
                                            </div>
                                        </div>
                                        <div className="category-box">
                                            <p>Job Seekers</p>
                                        </div>
                                        <div className="title-box">
                                            <h3>
                                                <Link href="/blog-single">
                                                    Navigating Remote Work:<br/>Six Tips for Employers &<br/>Employees.
                                                </Link>
                                            </h3>
                                        </div>
                                        <div className="text">
                                            <p>Choice is untrammelled when nothing to<br/>able to do what we like best...</p>
                                        </div>
                                        <div className="blog-style3__single-btn">
                                            <div className="left">
                                                <p>3 Mins Read</p>
                                            </div>
                                            <div className="right">
                                                <Link href="/blog-single"><span className="icon-right-arrow-1"></span></Link>
                                                <div className="overlay-btn">
                                                    <Link href="/blog-single">Read More
                                                        <span className="icon-arrow-angle-pointing-to-right"></span>
                                                    </Link>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                
                                <div className="col-xl-4 col-lg-4 col-md-6">
                                    <div className="blog-style3__single blog-style2__single--style4">
                                        <div className="author-info">
                                            <div className="author-info__img">
                                                <img src="assets/images/blog/blog-v1-author-info3.jpg" alt="image"/>
                                            </div>
                                            <div className="author-info__text">
                                                <h5>Dahlia Bianca</h5>
                                                <ul className="clearfix">
                                                    <li>
                                                        <Link href="#">Oct 10, 2025</Link>
                                                    </li>
                                                    <li>
                                                        <Link href="#">8 Comments</Link>
                                                    </li>
                                                </ul>
                                            </div>
                                        </div>
                                        <div className="category-box">
                                            <p>Human Resource</p>
                                        </div>
                                        <div className="title-box">
                                            <h3>
                                                <Link href="/blog-single">
                                                    Hiringhub Chosen for<br/>Crown Commercial's Staff-<br/>ing Services.
                                                </Link>
                                            </h3>
                                        </div>
                                        <div className="text">
                                            <p>Duty or the obligations of business it will<br/>frequently occur...</p>
                                        </div>
                                        <div className="blog-style3__single-btn">
                                            <div className="left">
                                                <p>5 Mins Read</p>
                                            </div>
                                            <div className="right">
                                                <Link href="/blog-single"><span className="icon-right-arrow-1"></span></Link>
                                                <div className="overlay-btn">
                                                    <Link href="/blog-single">Read More
                                                        <span className="icon-arrow-angle-pointing-to-right"></span>
                                                    </Link>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                
                                <div className="col-xl-4 col-lg-4 col-md-6">
                                    <div className="blog-style3__single blog-style2__single--style4">
                                        <div className="author-info">
                                            <div className="author-info__img">
                                                <img src="assets/images/blog/blog-v1-author-info3.jpg" alt="image"/>
                                            </div>
                                            <div className="author-info__text">
                                                <h5>Dahlia Bianca</h5>
                                                <ul className="clearfix">
                                                    <li>
                                                        <Link href="#">Sep 12, 2025</Link>
                                                    </li>
                                                    <li>
                                                        <Link href="#">4 Comments</Link>
                                                    </li>
                                                </ul>
                                            </div>
                                        </div>
                                        <div className="category-box">
                                            <p>Human Resource</p>
                                        </div>
                                        <div className="title-box">
                                            <h3>
                                                <Link href="/blog-single">Utilizing Technology in the<br/>Hiring Process.</Link>
                                            </h3>
                                        </div>
                                        <div className="text">
                                            <p>Holds in these matters to this principle of<br/>selection rejects pleasures...</p>
                                        </div>
                                        <div className="blog-style3__single-btn">
                                            <div className="left">
                                                <p>5 Mins Read</p>
                                            </div>
                                            <div className="right">
                                                <Link href="/blog-single"><span className="icon-right-arrow-1"></span></Link>
                                                <div className="overlay-btn">
                                                    <Link href="/blog-single">Read More
                                                        <span className="icon-arrow-angle-pointing-to-right"></span>
                                                    </Link>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                
                                <div className="col-xl-4 col-lg-4 col-md-6">
                                    <div className="blog-style3__single blog-style2__single--style4">
                                        <div className="author-info">
                                            <div className="author-info__img">
                                                <img src="assets/images/blog/blog-v1-author-info1.jpg" alt="image"/>
                                            </div>
                                            <div className="author-info__text">
                                                <h5>Boone Gerardo</h5>
                                                <ul className="clearfix">
                                                    <li>
                                                        <Link href="#">Aug 28, 2025</Link>
                                                    </li>
                                                    <li>
                                                        <Link href="#">2 Comments</Link>
                                                    </li>
                                                </ul>
                                            </div>
                                        </div>
                                        <div className="category-box">
                                            <p>News & Tips</p>
                                        </div>
                                        <div className="title-box">
                                            <h3>
                                                <Link href="/blog-single">Navigating Legalities in<br/>Staffing and Hiring</Link>
                                            </h3>
                                        </div>
                                        <div className="text">
                                            <p>
                                                Those who fail in their duty through weak-<br/>ness of will, which is the same...
                                            </p>
                                        </div>
                                        <div className="blog-style3__single-btn">
                                            <div className="left">
                                                <p>2 Mins Read</p>
                                            </div>
                                            <div className="right">
                                                <Link href="/blog-single"><span className="icon-right-arrow-1"></span></Link>
                                                <div className="overlay-btn">
                                                    <Link href="/blog-single">Read More
                                                        <span className="icon-arrow-angle-pointing-to-right"></span>
                                                    </Link>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                
                                <div className="col-xl-4 col-lg-4 col-md-6">
                                    <div className="blog-style3__single blog-style2__single--style4">
                                        <div className="author-info">
                                            <div className="author-info__img">
                                                <img src="assets/images/blog/blog-v1-author-info2.jpg" alt="image"/>
                                            </div>
                                            <div className="author-info__text">
                                                <h5>Harley Reuban</h5>
                                                <ul className="clearfix">
                                                    <li>
                                                        <Link href="#">Oct 24, 2025</Link>
                                                    </li>
                                                    <li>
                                                        <Link href="#">3 Comments</Link>
                                                    </li>
                                                </ul>
                                            </div>
                                        </div>
                                        <div className="category-box">
                                            <p>Job Seekers</p>
                                        </div>
                                        <div className="title-box">
                                            <h3>
                                                <Link href="/blog-single">
                                                    Navigating Remote Work: Six Tips & Employees.
                                                </Link>
                                            </h3>
                                        </div>
                                        <div className="text">
                                            <p>Choice is untrammelled when nothing to<br/>able to do what we like best...</p>
                                        </div>
                                        <div className="blog-style3__single-btn">
                                            <div className="left">
                                                <p>3 Mins Read</p>
                                            </div>
                                            <div className="right">
                                                <Link href="/blog-single"><span className="icon-right-arrow-1"></span></Link>
                                                <div className="overlay-btn">
                                                    <Link href="/blog-single">Read More
                                                        <span className="icon-arrow-angle-pointing-to-right"></span>
                                                    </Link>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                
                                <div className="col-xl-4 col-lg-4 col-md-6">
                                    <div className="blog-style3__single blog-style2__single--style4">
                                        <div className="author-info">
                                            <div className="author-info__img">
                                                <img src="assets/images/blog/blog-v1-author-info2.jpg" alt="image"/>
                                            </div>
                                            <div className="author-info__text">
                                                <h5>Harley Reuban</h5>
                                                <ul className="clearfix">
                                                    <li>
                                                        <Link href="#">Oct 24, 2025</Link>
                                                    </li>
                                                    <li>
                                                        <Link href="#">3 Comments</Link>
                                                    </li>
                                                </ul>
                                            </div>
                                        </div>
                                        <div className="category-box">
                                            <p>Job Seekers</p>
                                        </div>
                                        <div className="title-box">
                                            <h3>
                                                <Link href="/blog-single">
                                                    Navigating Remote Work:<br/>Six Tips for Employers &<br/>Employees.
                                                </Link>
                                            </h3>
                                        </div>
                                        <div className="text">
                                            <p>Choice is untrammelled when nothing to<br/>able to do what we like best...</p>
                                        </div>
                                        <div className="blog-style3__single-btn">
                                            <div className="left">
                                                <p>3 Mins Read</p>
                                            </div>
                                            <div className="right">
                                                <Link href="/blog-single"><span className="icon-right-arrow-1"></span></Link>
                                                <div className="overlay-btn">
                                                    <Link href="/blog-single">Read More
                                                        <span className="icon-arrow-angle-pointing-to-right"></span>
                                                    </Link>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                
                                <div className="col-xl-4 col-lg-4 col-md-6">
                                    <div className="blog-style3__single blog-style2__single--style4">
                                        <div className="author-info">
                                            <div className="author-info__img">
                                                <img src="assets/images/blog/blog-v1-author-info3.jpg" alt="image"/>
                                            </div>
                                            <div className="author-info__text">
                                                <h5>Dahlia Bianca</h5>
                                                <ul className="clearfix">
                                                    <li>
                                                        <Link href="#">Oct 10, 2025</Link>
                                                    </li>
                                                    <li>
                                                        <Link href="#">8 Comments</Link>
                                                    </li>
                                                </ul>
                                            </div>
                                        </div>
                                        <div className="category-box">
                                            <p>Human Resource</p>
                                        </div>
                                        <div className="title-box">
                                            <h3>
                                                <Link href="/blog-single">
                                                    Hiringhub Chosen for<br/>Crown Commercial's Staff-<br/>ing Services.
                                                </Link>
                                            </h3>
                                        </div>
                                        <div className="text">
                                            <p>Duty or the obligations of business it will<br/>frequently occur...</p>
                                        </div>
                                        <div className="blog-style3__single-btn">
                                            <div className="left">
                                                <p>5 Mins Read</p>
                                            </div>
                                            <div className="right">
                                                <Link href="/blog-single"><span className="icon-right-arrow-1"></span></Link>
                                                <div className="overlay-btn">
                                                    <Link href="/blog-single">Read More
                                                        <span className="icon-arrow-angle-pointing-to-right"></span>
                                                    </Link>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                
                                <div className="col-xl-4 col-lg-4 col-md-6">
                                    <div className="blog-style3__single blog-style2__single--style4">
                                        <div className="author-info">
                                            <div className="author-info__img">
                                                <img src="assets/images/blog/blog-v1-author-info1.jpg" alt="image"/>
                                            </div>
                                            <div className="author-info__text">
                                                <h5>Boone Gerardo</h5>
                                                <ul className="clearfix">
                                                    <li>
                                                        <Link href="#">Nov 15, 2025</Link>
                                                    </li>
                                                    <li>
                                                        <Link href="#">2 Comments</Link>
                                                    </li>
                                                </ul>
                                            </div>
                                        </div>
                                        <div className="category-box">
                                            <p>News & Tips</p>
                                        </div>
                                        <div className="title-box">
                                            <h3>
                                                <Link href="/blog-single">
                                                    Unlocking Success: Top<br/>Eight Tips for Leadership<br/>Recruitment.
                                                </Link>
                                            </h3>
                                        </div>
                                        <div className="text">
                                            <p>Cases are perfectly simple and easy to<br/>distinguish in a free hour...</p>
                                        </div>
                                        <div className="blog-style3__single-btn">
                                            <div className="left">
                                                <p>2 Mins Read</p>
                                            </div>
                                            <div className="right">
                                                <Link href="/blog-single"><span className="icon-right-arrow-1"></span></Link>
                                                <div className="overlay-btn">
                                                    <Link href="/blog-single">Read More
                                                        <span className="icon-arrow-angle-pointing-to-right"></span>
                                                    </Link>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                            </div>
                        </div>

                        <div className="row">
                            <div className="col-xl-12">
                                <ul className="styled-pagination pdtop0 clearfix text-center">
                                    <li className="arrow prev">
                                        <Link href="#"><span className="icon-left-arrow-angle-big-gross-symbol left"></span></Link>
                                    </li>
                                    <li className="active"><Link href="#">01</Link></li>
                                    <li><Link href="#">02</Link></li>
                                    <li><Link href="#">03</Link></li>
                                    <li className="arrow next">
                                        <Link href="#"><span className="icon-arrow-angle-pointing-to-right right"></span></Link>
                                    </li>
                                </ul>
                            </div>
                        </div>

                    </div>
                </section>
            </Layout>
        </div>
    )
}