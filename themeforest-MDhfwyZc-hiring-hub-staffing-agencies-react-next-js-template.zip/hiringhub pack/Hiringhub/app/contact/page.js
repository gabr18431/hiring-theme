'use client'
import React from 'react'
import Link from "next/link"
import Layout from "@/components/layout/Layout"

export default function Contact_page() {
    return (
        <div className="page-wrapper boxed_wrapper">
            <Layout headerStyle={1} footerStyle={6} breadcrumbTitle="Contact Us">
                <section className="corporate-office-style1">
                    <div className="container">
                        <div className="sec-title withtext text-center">
                            <div className="sub-title">
                                <h4>Corporate office</h4>
                            </div>
                            <h2>Ready to Assist—Contact Now</h2>
                            <div className="text">
                                <p>
                                    Long established fact that a reader will be distracted by the<br/>readable content of a page.
                                </p>
                            </div>
                        </div>
                        <div className="row">
                            
                            <div className="col-xl-4 col-lg-6 col-md-6">
                                <div className="single-corporate-office-style1 text-center">
                                    <div className="icon">
                                        <img src="assets/images/icon/corporate-office/corporate-office-icon-1.png" alt="icon"/>
                                    </div>
                                    <div className="title">
                                        <h3>
                                            <Link
                                                href="https://www.google.com/maps/search/54+Berrick+2nd+St+Boston,+MCA+02115,+United+States./@42.3194571,-71.1893359,12z/data=!3m1!4b1?entry=ttu&g_ep=EgoyMDI1MDIyNi4xIKXMDSoASAFQAw%3D%3D">
                                                Office Location</Link>
                                        </h3>
                                        <p>Discover innovation at our doorstep.</p>
                                    </div>
                                    <div className="btn-box">
                                        <Link
                                            href="https://www.google.com/maps/search/54+Berrick+2nd+St+Boston,+MCA+02115,+United+States./@42.3194571,-71.1893359,12z/data=!3m1!4b1?entry=ttu&g_ep=EgoyMDI1MDIyNi4xIKXMDSoASAFQAw%3D%3D">
                                            View On Map
                                            <span className="icon-arrow-angle-pointing-to-right"></span>
                                        </Link>
                                    </div>
                                    <div className="text">
                                        <p>54 Berrick 2nd St Boston, MCA<br/>02115, United States.</p>
                                    </div>
                                </div>
                            </div>
                            
                            <div className="col-xl-4 col-lg-6 col-md-6">
                                <div className="single-corporate-office-style1 text-center">
                                    <div className="icon">
                                        <img src="assets/images/icon/corporate-office/corporate-office-icon-2.png" alt="icon"/>
                                    </div>
                                    <div className="title">
                                        <h3><Link href="mailto:getsupport@hiringhub.com">Quick Contact</Link></h3>
                                        <p>Call or email us for immediate help.</p>
                                    </div>
                                    <div className="btn-box">
                                        <Link href="tel:1888.56.7890">
                                            Get call back
                                            <span className="icon-arrow-angle-pointing-to-right"></span>
                                        </Link>
                                    </div>
                                    <div className="text">
                                        <p>
                                            <Link href="tel:1888.56.7890">+1 888.56.7890</Link><br/>
                                            <Link href="mailto:getsupport@hiringhub.com">getsupport@hiringhub.com</Link>
                                        </p>
                                    </div>
                                </div>
                            </div>
                            
                            <div className="col-xl-4 col-lg-6 col-md-6">
                                <div className="single-corporate-office-style1 text-center">
                                    <div className="icon">
                                        <img src="assets/images/icon/corporate-office/corporate-office-icon-3.png" alt="icon"/>
                                    </div>
                                    <div className="title">
                                        <h3><Link href="#">Office Hrs</Link></h3>
                                        <p>Visit us during our office hours.</p>
                                    </div>
                                    <div className="btn-box">
                                        <Link href="https://www.aplustopper.com/appointment-letter/">
                                            Appointment
                                            <span className="icon-arrow-angle-pointing-to-right"></span>
                                        </Link>
                                    </div>
                                    <div className="text">
                                        <p><span>Mon - Satday: </span>9am to 6.30pm<br/><span>Sunday: </span>Closed.</p>
                                    </div>
                                </div>
                            </div>

                        </div>
                    </div>
                </section>

                <section className="location-style1">
                    <div className="container">
                        <div className="row">
                            
                            <div className="col-xl-6 col-lg-6">
                                <div className="single-location-style1">
                                    <div className="img-box">
                                        <img src="assets/images/resources/location-v1-img-1.jpg" alt="image"/>
                                        <div className="overlay-title">
                                            <h2>
                                                <Link
                                                    href="https://www.google.com/maps/place/United+Kingdom/@52.7054192,-25.2871226,4z/data=!3m1!4b1!4m6!3m5!1s0x25a3b1142c791a9:0xc4f8a0433288257a!8m2!3d55.378051!4d-3.435973!16zL20vMDdzc2M?entry=ttu&g_ep=EgoyMDI1MDIyNi4xIKXMDSoASAFQAw%3D%3D">
                                                    United Kingdom
                                                </Link>
                                            </h2>
                                        </div>
                                        <div className="overlay-text">
                                            <div className="left">
                                                <p>54 Berrick 2nd St Boston, MCA</p>
                                                <p>02115, United States.</p>
                                            </div>
                                            <div className="right">
                                                <p><Link href="tel:1888.56.7890">+1 888.56.7890</Link></p>
                                                <p><Link href="mailto:getsupport@hiringhub.com">getsupport@hiringhub.com</Link></p>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            
                            <div className="col-xl-6 col-lg-6 col-md-12">
                                <div className="single-location-style1">
                                    <div className="img-box">
                                        <img src="assets/images/resources/location-v1-img-2.jpg" alt="image"/>
                                        <div className="overlay-title">
                                            <h2>
                                                <Link
                                                    href="https://www.google.com/maps?sca_esv=53a1189ee8f55c43&output=search&q=switzerland&source=lnms&fbs=ABzOT_CWdhQLP1FcmU5B0fn3xuWpA-dk4wpBWOGsoR7DG5zJBjnSuuKZNj-6zieDk_gkn6CyymgG_tEVFNWvBwycIom9fAkLCsPsF-grDFWWIT-hUy9gjDnOqHAscclkbqUs-aKqQw1BuVYSe3mWOm_HEN5M1PyKWy7kVwhFL7Y9dKiFLZmsmbNRUSTNaLeNYodqyW8DTHGMgzQko7oM8twTkhON5lEj0Q&entry=mc&ved=1t:200715&ictx=111">
                                                    Switzerland
                                                </Link>
                                            </h2>
                                        </div>
                                        <div className="overlay-text">
                                            <div className="left">
                                                <p>54 Berrick 2nd St Boston, MCA</p>
                                                <p>02115, United States.</p>
                                            </div>
                                            <div className="right">
                                                <p><Link href="tel:1888.56.7890">+1 888.56.7890</Link></p>
                                                <p><Link href="mailto:getsupport@hiringhub.com">getsupport@hiringhub.com</Link></p>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            
                            <div className="col-xl-6 col-lg-6 col-md-12">
                                <div className="single-location-style1">
                                    <div className="img-box">
                                        <img src="assets/images/resources/location-v1-img-3.jpg" alt="image"/>
                                        <div className="overlay-title">
                                            <h2>
                                                <Link
                                                    href="https://www.google.com/maps/place/Germany/@51.0568081,5.1752319,6z/data=!3m1!4b1!4m6!3m5!1s0x479a721ec2b1be6b:0x75e85d6b8e91e55b!8m2!3d51.165691!4d10.451526!16zL20vMDM0NWg?entry=ttu&g_ep=EgoyMDI1MDIyNi4xIKXMDSoASAFQAw%3D%3D">
                                                    Germany
                                                </Link>
                                            </h2>
                                        </div>
                                        <div className="overlay-text">
                                            <div className="left">
                                                <p>54 Berrick 2nd St Boston, MCA</p>
                                                <p>02115, United States.</p>
                                            </div>
                                            <div className="right">
                                                <p><Link href="tel:1888.56.7890">+1 888.56.7890</Link></p>
                                                <p><Link href="mailto:getsupport@hiringhub.com">getsupport@hiringhub.com</Link></p>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            
                            <div className="col-xl-6 col-lg-6 col-md-12">
                                <div className="single-location-style1">
                                    <div className="img-box">
                                        <img src="assets/images/resources/location-v1-img-4.jpg" alt="image"/>
                                        <div className="overlay-title">
                                            <h2>
                                                <Link
                                                    href="https://www.google.com/maps/place/Australia/@-18.8457077,87.3921897,3z/data=!3m1!4b1!4m6!3m5!1s0x2b2bfd076787c5df:0x538267a1955b1352!8m2!3d-25.274398!4d133.775136!16zL20vMGNoZ2h5?entry=ttu&g_ep=EgoyMDI1MDIyNi4xIKXMDSoASAFQAw%3D%3D">
                                                    Australia
                                                </Link>
                                            </h2>
                                        </div>
                                        <div className="overlay-text">
                                            <div className="left">
                                                <p>54 Berrick 2nd St Boston, MCA</p>
                                                <p>02115, United States.</p>
                                            </div>
                                            <div className="right">
                                                <p><Link href="tel:1888.56.7890">+1 888.56.7890</Link></p>
                                                <p><Link href="mailto:getsupport@hiringhub.com">getsupport@hiringhub.com</Link></p>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>

                        </div>
                    </div>
                </section>

                <section className="main-contact-form">
                    <div className="container">
                        <div className="sec-title withtext text-center">
                            <div className="sub-title">
                                <h4>Send Message</h4>
                            </div>
                            <h2>Reach Out Drop us a Line Here</h2>
                            <div className="text">
                                <p>
                                    Long established fact that a reader will be distracted by the.
                                </p>
                            </div>
                        </div>
                        <div className="contact-form">
                            <form id="contact-form" name="contact_form" className="default-form2" action="assets/inc/sendmail.php"
                                method="post">
                                <div className="row">
                                    <div className="col-xl-6 col-lg-6">
                                        <div className="contact-form-left">
                                            <div className="form-group">
                                                <div className="input-box">
                                                    <input type="text" name="form_name" id="formName"
                                                        placeholder="Enter name here" required=""/>
                                                </div>
                                            </div>

                                            <div className="form-group">
                                                <div className="input-box">
                                                    <input type="email" name="form_email" id="formEmail"
                                                        placeholder="Email address" required=""/>
                                                </div>
                                            </div>

                                            <div className="form-group">
                                                <div className="input-box">
                                                    <input type="text" name="form_phone" value="" id="formPhone"
                                                        placeholder="Enter phone num"/>
                                                </div>
                                            </div>

                                            <div className="form-group">
                                                <div className="input-box">
                                                    <input type="text" name="form_subject" value="" id="formSubject"
                                                        placeholder="Subject"/>
                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                    <div className="col-xl-6 col-lg-6">
                                        <div className="contact-form-right">
                                            <div className="form-group">
                                                <div className="input-box">
                                                    <textarea name="form_message" id="formMessage" placeholder="Message"
                                                        required="" aria-required="true"></textarea>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <div className="row">
                                    <div className="co-xl-12 text-center">
                                        <div className="button-box">
                                            <div className="checked-box2">
                                                <input type="checkbox" name="agree" id="iamagree"/>
                                                <label for="iamagree">
                                                    <span></span>I agree the terms &amp; Conditions
                                                </label>
                                            </div>

                                            <input id="form_botcheck" name="form_botcheck" className="form-control" type="hidden"
                                                value=""/>
                                            <button className="btn-one" type="submit" data-loading-text="Please wait...">
                                                <span className="txt">
                                                    Send Message
                                                    <i className="icon-next1"></i>
                                                </span>
                                            </button>
                                        </div>
                                    </div>
                                </div>

                            </form>
                        </div>
                    </div>
                </section>
            </Layout>
        </div>
    )
}