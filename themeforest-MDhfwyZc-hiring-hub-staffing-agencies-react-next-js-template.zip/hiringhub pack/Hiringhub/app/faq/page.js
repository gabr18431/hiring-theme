'use client'
import React from 'react'
import { useState } from "react"
import Link from "next/link"
import Layout from "@/components/layout/Layout"

export default function Faq_page() {
    const [isActive, setIsActive] = useState({
        status: false,
        key: 1,
    })

    const handleToggle = (key) => {
        if (isActive.key === key) {
            setIsActive({
                status: false,
            })
        } else {
            setIsActive({
                status: true,
                key,
            })
        }
    }
    return (
        <div className="page-wrapper boxed_wrapper">
            <Layout headerStyle={1} footerStyle={1} breadcrumbTitle="Faq’s">
                <section className="faq-style1">
                    <div className="container">
                        <div className="row">

                            <div className="col-xl-6">
                                <div className="faq-style1__img">
                                    <div className="inner">
                                        <img src="assets/images/resources/faq-v1-img1.jpg" alt="image"/>
                                    </div>
                                    <div className="overlay-content">
                                        <Link href="/about" className="icon">
                                            <span className="icon-question"><span className="path1"></span><span
                                                    className="path2"></span><span className="path3"></span></span>
                                        </Link>
                                        <h3>Can't Find<br/>Your Answer?</h3>
                                        <p>Send you questions<br/>to our team, they’ll help you.</p>
                                        <div className="btn-box">
                                            <Link className="btn-one" href="/faq">
                                                <span className="txt">Send Now</span>
                                            </Link>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div className="col-xl-6">
                                <div className="faq-style1__content">
                                    <ul className="accordion-box-style1">
                                        
                                        <li className="accordion accordion-block">
                                            <div className={isActive.key == 1 ? "accord-btn active" : "accord-btn"} onClick={() => handleToggle(1)}>
                                                <h4>
                                                    What industries do you specialize in?
                                                </h4>
                                            </div>
                                            <div className={isActive.key == 1 ? "accord-content current" : "accord-content"}>
                                                <p>
                                                    There are many variations passages of lorem ipsum available,
                                                    but the majority have suffered alteration form injected humours
                                                    randomises don't look even slightly.
                                                </p>
                                            </div>
                                        </li>
                                        
                                        <li className="accordion accordion-block">
                                            <div className={isActive.key == 2 ? "accord-btn active" : "accord-btn"} onClick={() => handleToggle(2)}>
                                                <h4>What types of jobs do you offer?</h4>
                                            </div>
                                            <div className={isActive.key == 2 ? "accord-content current" : "accord-content"}>
                                                <p>
                                                    There are many variations passages of lorem ipsum available,
                                                    but the majority have suffered alteration form injected humours
                                                    randomises don't look even slightly.
                                                </p>
                                            </div>
                                        </li>
                                        
                                        <li className="accordion accordion-block">
                                            <div className={isActive.key == 3 ? "accord-btn active" : "accord-btn"} onClick={() => handleToggle(3)}>
                                                <h4>Are there fees for job seekers?</h4>
                                            </div>
                                            <div className={isActive.key == 3 ? "accord-content current" : "accord-content"}>
                                                <p>
                                                    There are many variations passages of lorem ipsum available,
                                                    but the majority have suffered alteration form injected humours
                                                    randomises don't look even slightly.
                                                </p>
                                            </div>
                                        </li>
                                        
                                        <li className="accordion accordion-block">
                                            <div className={isActive.key == 4 ? "accord-btn active" : "accord-btn"} onClick={() => handleToggle(4)}>
                                                <h4>How long can temporary assignments last?</h4>
                                            </div>
                                            <div className={isActive.key == 4 ? "accord-content current" : "accord-content"}>
                                                <p>
                                                    There are many variations passages of lorem ipsum available,
                                                    but the majority have suffered alteration form injected humours
                                                    randomises don't look even slightly.
                                                </p>
                                            </div>
                                        </li>
                                        
                                        <li className="accordion accordion-block">
                                            <div className={isActive.key == 5 ? "accord-btn active" : "accord-btn"} onClick={() => handleToggle(5)}>
                                                <h4>How is billing handled for staffing services?</h4>
                                            </div>
                                            <div className={isActive.key == 5 ? "accord-content current" : "accord-content"}>
                                                <p>
                                                    There are many variations passages of lorem ipsum available,
                                                    but the majority have suffered alteration form injected humours
                                                    randomises don't look even slightly.
                                                </p>
                                            </div>
                                        </li>
                                        
                                        <li className="accordion accordion-block">
                                            <div className={isActive.key == 6 ? "accord-btn active" : "accord-btn"} onClick={() => handleToggle(6)}>
                                                <h4>How long does it typically take to fill a position?</h4>
                                            </div>
                                            <div className={isActive.key == 6 ? "accord-content current" : "accord-content"}>
                                                <p>
                                                    There are many variations passages of lorem ipsum available,
                                                    but the majority have suffered alteration form injected humours
                                                    randomises don't look even slightly.
                                                </p>
                                            </div>
                                        </li>
                                        
                                        <li className="accordion accordion-block">
                                            <div className={isActive.key == 7 ? "accord-btn active" : "accord-btn"} onClick={() => handleToggle(7)}>
                                                <h4>How do I get started?</h4>
                                            </div>
                                            <div className={isActive.key == 7 ? "accord-content current" : "accord-content"}>
                                                <p>
                                                    There are many variations passages of lorem ipsum available,
                                                    but the majority have suffered alteration form injected humours
                                                    randomises don't look even slightly.
                                                </p>
                                            </div>
                                        </li>
                                        
                                        <li className="accordion accordion-block">
                                            <div className={isActive.key == 8 ? "accord-btn active" : "accord-btn"} onClick={() => handleToggle(8)}>
                                                <h4>How does the staffing process work?</h4>
                                            </div>
                                            <div className={isActive.key == 8 ? "accord-content current" : "accord-content"}>
                                                <p>
                                                    There are many variations passages of lorem ipsum available,
                                                    but the majority have suffered alteration form injected humours
                                                    randomises don't look even slightly.
                                                </p>
                                            </div>
                                        </li>
                                        <li className="accordion accordion-block">
                                            <div className={isActive.key == 9 ? "accord-btn active" : "accord-btn"} onClick={() => handleToggle(9)}>
                                                <h4>Do you offer any guarantees on placements?</h4>
                                            </div>
                                            <div className={isActive.key == 9 ? "accord-content current" : "accord-content"}>
                                                <p>
                                                    There are many variations passages of lorem ipsum available,
                                                    but the majority have suffered alteration form injected humours
                                                    randomises don't look even slightly.
                                                </p>
                                            </div>
                                        </li>
                                    </ul>
                                </div>
                            </div>

                        </div>
                    </div>
                </section>
            </Layout>
        </div>
    )
}