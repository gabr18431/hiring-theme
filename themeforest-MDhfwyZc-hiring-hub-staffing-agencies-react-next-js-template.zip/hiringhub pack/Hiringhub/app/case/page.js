'use client'
import React from 'react'
import Layout from "@/components/layout/Layout"
import dynamic from 'next/dynamic'
const PortfolioFilter1 = dynamic(() => import('@/components/elements/PortfolioFilter1'), { ssr: false,})


export default function Case_page_one() {
    return (
        <div className="page-wrapper boxed_wrapper">
            <Layout headerStyle={1} footerStyle={1} breadcrumbTitle="Grid View 01">
            <PortfolioFilter1/>
            </Layout>
        </div>
    )
}