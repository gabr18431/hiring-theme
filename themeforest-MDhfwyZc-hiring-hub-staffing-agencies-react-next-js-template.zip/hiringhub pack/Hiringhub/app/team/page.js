'use client'
import React from 'react'
import Link from "next/link"
import Layout from "@/components/layout/Layout"

export default function Team_page() {
    return (
        <div className="page-wrapper boxed_wrapper">
            <Layout headerStyle={1} footerStyle={1} breadcrumbTitle="Team Members">
            <section class="team-style1 instyle--2">
                <div class="container">
                    <div class="row">
                        
                        <div class="col-xl-4 col-lg-4 col-md-6">
                            <div class="team-style1__single instyle--2">
                                <div class="img-box">
                                    <img src="assets/images/team/team-v1-1.jpg" alt="image"/>
                                    <div class="overlay-content">
                                        <div class="title">
                                            <h3><Link href="#">Bertram Irvin</Link></h3>
                                        </div>
                                        <div class="border-line"></div>
                                        <div class="sub-title">
                                            <div class="text">
                                                <p>Senior Recruiter</p>
                                            </div>

                                            <div class="social-share-box">
                                                <span class="icon-share"></span>
                                                <ul class="clearfix">
                                                    <li>
                                                        <Link href="#">
                                                            <i class="icon-facebook"></i>
                                                        </Link>
                                                    </li>
                                                    <li>
                                                        <Link href="#">
                                                            <i class="icon-twitter"></i>
                                                        </Link>
                                                    </li>
                                                    <li>
                                                        <Link href="#">
                                                            <i class="icon-instagram-logo"></i>
                                                        </Link>
                                                    </li>
                                                </ul>
                                            </div>

                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        
                        <div class="col-xl-4 col-lg-4 col-md-6">
                            <div class="team-style1__single instyle--2">
                                <div class="img-box">
                                    <img src="assets/images/team/team-v1-2.jpg" alt="image"/>
                                    <div class="overlay-content">
                                        <div class="title">
                                            <h3><Link href="#">Michel Kyle</Link></h3>
                                        </div>
                                        <div class="border-line"></div>
                                        <div class="sub-title">
                                            <div class="text">
                                                <p>Recruitment Manager</p>
                                            </div>

                                            <div class="social-share-box">
                                                <span class="icon-share"></span>
                                                <ul class="clearfix">
                                                    <li>
                                                        <Link href="#">
                                                            <i class="icon-facebook"></i>
                                                        </Link>
                                                    </li>
                                                    <li>
                                                        <Link href="#">
                                                            <i class="icon-twitter"></i>
                                                        </Link>
                                                    </li>
                                                    <li>
                                                        <Link href="#">
                                                            <i class="icon-instagram-logo"></i>
                                                        </Link>
                                                    </li>
                                                </ul>
                                            </div>

                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        
                        <div class="col-xl-4 col-lg-4 col-md-6">
                            <div class="team-style1__single instyle--2">
                                <div class="img-box">
                                    <img src="assets/images/team/team-v1-3.jpg" alt="image"/>
                                    <div class="overlay-content">
                                        <div class="title">
                                            <h3><Link href="#">Nora Lillian</Link></h3>
                                        </div>
                                        <div class="border-line"></div>
                                        <div class="sub-title">
                                            <div class="text">
                                                <p>IT Recruitment Specialist</p>
                                            </div>

                                            <div class="social-share-box">
                                                <span class="icon-share"></span>
                                                <ul class="clearfix">
                                                    <li>
                                                        <Link href="#">
                                                            <i class="icon-facebook"></i>
                                                        </Link>
                                                    </li>
                                                    <li>
                                                        <Link href="#">
                                                            <i class="icon-twitter"></i>
                                                        </Link>
                                                    </li>
                                                    <li>
                                                        <Link href="#">
                                                            <i class="icon-instagram-logo"></i>
                                                        </Link>
                                                    </li>
                                                </ul>
                                            </div>

                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        
                        <div class="col-xl-4 col-lg-4 col-md-6">
                            <div class="team-style1__single instyle--2">
                                <div class="img-box">
                                    <img src="assets/images/team/team-v1-4.jpg" alt="image"/>
                                    <div class="overlay-content">
                                        <div class="title">
                                            <h3><Link href="#">Scarlett Lavern</Link></h3>
                                        </div>
                                        <div class="border-line"></div>
                                        <div class="sub-title">
                                            <div class="text">
                                                <p>Account Manager</p>
                                            </div>

                                            <div class="social-share-box">
                                                <span class="icon-share"></span>
                                                <ul class="clearfix">
                                                    <li>
                                                        <Link href="#">
                                                            <i class="icon-facebook"></i>
                                                        </Link>
                                                    </li>
                                                    <li>
                                                        <Link href="#">
                                                            <i class="icon-twitter"></i>
                                                        </Link>
                                                    </li>
                                                    <li>
                                                        <Link href="#">
                                                            <i class="icon-instagram-logo"></i>
                                                        </Link>
                                                    </li>
                                                </ul>
                                            </div>

                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        
                        <div class="col-xl-4 col-lg-4 col-md-6">
                            <div class="team-style1__single instyle--2">
                                <div class="img-box">
                                    <img src="assets/images/team/team-v1-5.jpg" alt="image"/>
                                    <div class="overlay-content">
                                        <div class="title">
                                            <h3><Link href="#">Milo Frederick</Link></h3>
                                        </div>
                                        <div class="border-line"></div>
                                        <div class="sub-title">
                                            <div class="text">
                                                <p>Operations Manager</p>
                                            </div>

                                            <div class="social-share-box">
                                                <span class="icon-share"></span>
                                                <ul class="clearfix">
                                                    <li>
                                                        <Link href="#">
                                                            <i class="icon-facebook"></i>
                                                        </Link>
                                                    </li>
                                                    <li>
                                                        <Link href="#">
                                                            <i class="icon-twitter"></i>
                                                        </Link>
                                                    </li>
                                                    <li>
                                                        <Link href="#">
                                                            <i class="icon-instagram-logo"></i>
                                                        </Link>
                                                    </li>
                                                </ul>
                                            </div>

                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        
                        <div class="col-xl-4 col-lg-4 col-md-6">
                            <div class="team-style1__single instyle--2">
                                <div class="img-box">
                                    <img src="assets/images/team/team-v1-6.jpg" alt="image"/>
                                    <div class="overlay-content">
                                        <div class="title">
                                            <h3><Link href="#">Dylan Zachary</Link></h3>
                                        </div>
                                        <div class="border-line"></div>
                                        <div class="sub-title">
                                            <div class="text">
                                                <p>Marketing Coordinator</p>
                                            </div>

                                            <div class="social-share-box">
                                                <span class="icon-share"></span>
                                                <ul class="clearfix">
                                                    <li>
                                                        <Link href="#">
                                                            <i class="icon-facebook"></i>
                                                        </Link>
                                                    </li>
                                                    <li>
                                                        <Link href="#">
                                                            <i class="icon-twitter"></i>
                                                        </Link>
                                                    </li>
                                                    <li>
                                                        <Link href="#">
                                                            <i class="icon-instagram-logo"></i>
                                                        </Link>
                                                    </li>
                                                </ul>
                                            </div>

                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                    </div>
                </div>
            </section>
            </Layout>
        </div>
    )
}