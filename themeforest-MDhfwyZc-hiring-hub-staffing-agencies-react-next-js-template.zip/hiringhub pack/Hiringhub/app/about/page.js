'use client'
import React from 'react'
import { useState } from "react"
import Link from "next/link"
import Layout from "@/components/layout/Layout"
import About from "@/components/sections/home3/About"
import Team from '@/components/sections/home2/Team'
import Counter from '@/components/sections/home4/Counter'
import Choose from '@/components/sections/home4/Choose'
import Partner from '@/components/sections/home5/Partner'

export default function About_page() {
    const [activeIndex, setActiveIndex] = useState(1)
        const handleOnClick = (index) => {
            setActiveIndex(index)
        }
    return (
        <div className="page-wrapper boxed_wrapper">
            <Layout headerStyle={1} footerStyle={6} breadcrumbTitle="About Us">
                <About/>
                <section className="award-style1">
                    <div className="container">
                        <div className="sec-title withtext text-center">
                            <div className="sub-title">
                                <h4>Awards & Achivements</h4>
                            </div>
                            <h2>Our Impressive Milestones</h2>
                            <div className="text">
                                <p>Long established fact that a reader will be distracted by the.</p>
                            </div>
                        </div>
                        <div className="row">

                            <div className="col-xl-6 col-lg-6 col-md-6">
                                <div className="award-style1__single">
                                    <div className="award-style1__single-shape1">
                                        <img src="assets/images/shapes/award-style1__shape1.png" alt="shape"/>
                                    </div>
                                    <div className="row">
                                        <div className="col-xl-6">
                                            <div className="award-style1__single-content">
                                                <div className="icon">
                                                    <img src="assets/images/icon/award/award-v1-icon-1.png" alt="icon"/>
                                                </div>
                                                <div className="category-box">
                                                    <p>mca’s awards</p>
                                                </div>
                                                <div className="title">
                                                    <h3><Link href="#">Best Personnel Service<br/>Provider.</Link></h3>
                                                </div>
                                                <div className="year">
                                                    <h4>2025</h4>
                                                </div>
                                            </div>
                                        </div>
                                        <div className="col-xl-6">
                                            <div className="award-style1__single-img">
                                                <img src="assets/images/resources/award-v1-img1.jpg" alt="image"/>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            
                            <div className="col-xl-6 col-lg-6 col-md-6">
                                <div className="award-style1__single">
                                    <div className="award-style1__single-shape1">
                                        <img src="assets/images/shapes/award-style1__shape1.png" alt="shape"/>
                                    </div>
                                    <div className="row">
                                        <div className="col-xl-6">
                                            <div className="award-style1__single-content">
                                                <div className="icon">
                                                    <img src="assets/images/icon/award/award-v1-icon-1.png" alt="icon"/>
                                                </div>
                                                <div className="category-box">
                                                    <p>Arup awards</p>
                                                </div>
                                                <div className="title">
                                                    <h3><Link href="#">Best Staffing Firm to<br/>Work For.</Link></h3>
                                                </div>
                                                <div className="year">
                                                    <h4>2022</h4>
                                                </div>
                                            </div>
                                        </div>
                                        <div className="col-xl-6">
                                            <div className="award-style1__single-img">
                                                <img src="assets/images/resources/award-v1-img2.jpg" alt="image"/>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>

                        </div>
                    </div>
                </section>
                <section className="about-style2">
                    <div className="container">
                        <div className="about-style2__tab">
                            <div className="row">
                                <div className="col-xl-5">
                                    <div className="about-style2__content">
                                        <div className="sec-title withtext">
                                            <div className="sub-title">
                                                <h4>Principles & Purpose</h4>
                                            </div>
                                            <h2>Delivering High<br/>Impact Recruitment<br/>Solutions</h2>
                                            <div className="text">
                                                <p>
                                                    Our being able to do what we like best every pleasure that<br/>but in certain
                                                    circumstances.
                                                </p>
                                            </div>
                                        </div>

                                        <div className="about-style2__tab-btn">
                                            <ul className="tabs-button-box clearfix">
                                                <li onClick={() => handleOnClick(1)} className={activeIndex === 1 ? "tab-btn-item active-btn" : "tab-btn-item"}>
                                                    <span>
                                                        Philosophy
                                                        <i className="icon-diagonal-arrow arrow-hover"></i>
                                                    </span>
                                                </li>
                                                <li onClick={() => handleOnClick(2)} className={activeIndex === 2 ? "tab-btn-item active-btn" : "tab-btn-item"}>
                                                    <span>
                                                        Our Milestones
                                                        <i className="icon-diagonal-arrow arrow-hover"></i>
                                                    </span>
                                                </li>
                                                <li onClick={() => handleOnClick(3)} className={activeIndex === 3 ? "tab-btn-item active-btn" : "tab-btn-item"}>
                                                    <span>
                                                        Our Statements
                                                        <i className="icon-diagonal-arrow arrow-hover"></i>
                                                    </span>
                                                </li>
                                            </ul>
                                        </div>
                                        <div className="btn-box2">
                                            <Link href="/about">
                                                More about our Agency
                                                <i className="icon-arrow-angle-pointing-to-right"></i>
                                            </Link>
                                        </div>
                                    </div>
                                </div>

                                <div className="col-xl-7">
                                    <div className="tabs-content-box">
                                        
                                        <div className={activeIndex === 1 ? "tab-content-box-item active-tab" : "tab-content-box-item"}>

                                            <div className="about-style2-tab-content-box-item">
                                                <div className="about-style2__img clearfix">
                                                    <div className="about-style2__shape1">
                                                        <img src="assets/images/shapes/about-v2-shape1.png" alt="shape"/>
                                                    </div>
                                                    <div className="about-style2__shape2">
                                                        <img src="assets/images/shapes/about-v2-shape2.png" alt="shape"/>
                                                    </div>
                                                    <div className="icon-box">
                                                        <img src="assets/images/icon/about/about-v2-icon-1.png" alt="icon"/>
                                                    </div>
                                                    <div className="img-box">
                                                        <img src="assets/images/about/about-v2-1.jpg" alt="image"/>
                                                    </div>
                                                    <div className="content-box">
                                                        <h3>Philosophy</h3>
                                                        <div className="line"></div>
                                                        <p>
                                                            Best every pleasure to welcomed<br/>every pain avoided but in
                                                            certain<br/>circumstances have be repudiate <br/>enjoy pleasure who
                                                            avoids a
                                                            pain<br/>that produces no resultant.
                                                        </p>
                                                        <div className="btn-box">
                                                            <Link href="/about">
                                                                Explore More
                                                                <i className="icon-arrow-angle-pointing-to-right"></i>
                                                            </Link>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>

                                        </div>
                                        
                                        <div className={activeIndex === 2 ? "tab-content-box-item active-tab" : "tab-content-box-item"}>
                                            <div className="about-style2-tab-content-box-item">
                                                <div className="about-style2__img clearfix">
                                                    <div className="about-style2__shape1">
                                                        <img src="assets/images/shapes/about-v2-shape1.png" alt="shape"/>
                                                    </div>
                                                    <div className="about-style2__shape2">
                                                        <img src="assets/images/shapes/about-v2-shape2.png" alt="shape"/>
                                                    </div>
                                                    <div className="icon-box">
                                                        <img src="assets/images/icon/about/about-v2-icon-1.png" alt="icon"/>
                                                    </div>
                                                    <div className="img-box">
                                                        <img src="assets/images/about/about-v2-1.jpg" alt="image"/>
                                                    </div>
                                                    <div className="content-box">
                                                        <h3>Our Milestones</h3>
                                                        <div className="line"></div>
                                                        <p>
                                                            Best every pleasure to welcomed<br/>every pain avoided but in
                                                            certain<br/>circumstances have be repudiate <br/>enjoy pleasure who
                                                            avoids a
                                                            pain<br/>that produces no resultant.
                                                        </p>
                                                        <div className="btn-box">
                                                            <Link href="/about">
                                                                Explore More
                                                                <i className="icon-arrow-angle-pointing-to-right"></i>
                                                            </Link>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        
                                        <div className={activeIndex === 3 ? "tab-content-box-item active-tab" : "tab-content-box-item"}>
                                            <div className="about-style2-tab-content-box-item">
                                                <div className="about-style2__img clearfix">
                                                    <div className="about-style2__shape1">
                                                        <img src="assets/images/shapes/about-v2-shape1.png" alt="shape"/>
                                                    </div>
                                                    <div className="about-style2__shape2">
                                                        <img src="assets/images/shapes/about-v2-shape2.png" alt="shape"/>
                                                    </div>
                                                    <div className="icon-box">
                                                        <img src="assets/images/icon/about/about-v2-icon-1.png" alt="icon"/>
                                                    </div>
                                                    <div className="img-box">
                                                        <img src="assets/images/about/about-v2-1.jpg" alt="image"/>
                                                    </div>
                                                    <div className="content-box">
                                                        <h3>Our Statements</h3>
                                                        <div className="line"></div>
                                                        <p>
                                                            Best every pleasure to welcomed<br/>every pain avoided but in
                                                            certain<br/>circumstances have be repudiate <br/>enjoy pleasure who
                                                            avoids a
                                                            pain<br/>that produces no resultant.
                                                        </p>
                                                        <div className="btn-box">
                                                            <Link href="/about">
                                                                Explore More
                                                                <i className="icon-arrow-angle-pointing-to-right"></i>
                                                            </Link>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>

                                    </div>

                                </div>
                            </div>

                        </div>
                    </div>
                </section>
                <Team/>
                <Counter/>
                <Choose/>
                <section className="growth-rate-style1">
                    <div className="container">
                        <div className="row">

                            <div className="col-xl-6">
                                <div className="growth-rate-style1__content">
                                    <div className="sec-title withtext">
                                        <div className="sub-title">
                                            <h4>Growth Rate</h4>
                                        </div>
                                        <h2>Rising Successful<br/>Placements Percentage</h2>
                                        <div className="text">
                                            <p>
                                                Pleasure is to be welcomed and every pain avoided but in
                                                certain<br/>circumstances and owing to the claims of duty.
                                            </p>
                                        </div>
                                    </div>
                                    <div className="btn-box">
                                        <Link className="btn-one" href="/cart">
                                            <span className="txt">Download</span>
                                        </Link>
                                    </div>
                                </div>
                            </div>

                            <div className="col-xl-6">
                                <div className="growth-rate-style1__growth">
                                    <div className="progress-levels-outer-box">
                                        <div className="inner-title">
                                            <h5>Annual growth rate 2021 - 2022</h5>
                                        </div>
                                        <div className="inner-content">
                                            <div className="value-box">
                                                <div className="single-box first">
                                                    <p>0</p>
                                                </div>
                                                <div className="single-box">
                                                    <p>20</p>
                                                </div>
                                                <div className="single-box">
                                                    <p>40</p>
                                                </div>
                                                <div className="single-box">
                                                    <p>60</p>
                                                </div>
                                                <div className="single-box">
                                                    <p>80</p>
                                                </div>
                                                <div className="single-box single-box-right">
                                                    <p>100</p>
                                                </div>
                                            </div>

                                            <ul className="progress-levels">
                                                
                                                <li className="progress-box wow">
                                                    <div className="top">
                                                        <h4>Placement Rate</h4>
                                                        <div className="count-box">
                                                            <div className="skill-percent">
                                                                <span className="count-text" data-speed="3000"
                                                                    data-stop="48">48</span>
                                                                <span className="percent">%</span>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div className="inner">
                                                        <div className="bar">
                                                            <div className="bar-innner">
                                                                <div className="bar-fill" style={{ width: '48%' }}>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </li>
                                                
                                                <li className="progress-box wow">
                                                    <div className="top">
                                                        <h4>Client Satisfaction Increase</h4>
                                                        <div className="count-box">
                                                            <div className="skill-percent">
                                                                <span className="count-text" data-speed="3000"
                                                                    data-stop="79">79</span>
                                                                <span className="percent">%</span>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div className="inner">
                                                        <div className="bar">
                                                            <div className="bar-innner">
                                                                <div className="bar-fill" style={{ width: '79%' }}>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </li>
                                                
                                                <li className="progress-box wow">
                                                    <div className="top">
                                                        <h4>Revenue Growth</h4>
                                                        <div className="count-box">
                                                            <div className="skill-percent">
                                                                <span className="count-text" data-speed="3000"
                                                                    data-stop="65">65</span>
                                                                <span className="percent">%</span>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div className="inner">
                                                        <div className="bar">
                                                            <div className="bar-innner">
                                                                <div className="bar-fill" style={{ width: '65%' }}>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                            </div>

                        </div>
                    </div>
                </section>
                <Partner/>
            </Layout>
        </div>
    )
}