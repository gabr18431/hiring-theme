'use client'
import React from 'react'
import Layout from "@/components/layout/Layout"

export default function Job_page() {
    return (
        <div className="page-wrapper boxed_wrapper">
            <Layout headerStyle={1} footerStyle={1} breadcrumbTitle="Place Your Job">
                <section className="place-job-form">
                    <div className="container">
                        <div className="sec-title withtext text-center">
                            <div className="sub-title">
                                <h4>Request Needed Talent</h4>
                            </div>
                            <h2>Tell Us About Your Hiring Needs</h2>
                            <div className="text">
                                <p>
                                    Long established fact that a reader will be distracted by the<br/>
                                    readable content of a page.
                                </p>
                            </div>
                        </div>
                        <form id="place-job-form-box" className="place-job-form-box" name="job-form" action="#" method="post">
                            <div className="row">


                                <div className="col-xl-6 col-lg-6">
                                    <div className="company-details-form">
                                        <div className="title-box">
                                            <div className="icon">
                                                <span className="icon-company"><span className="path1"></span><span
                                                        className="path2"></span><span className="path3"></span><span
                                                        className="path4"></span><span className="path5"></span><span
                                                        className="path6"></span><span className="path7"></span><span
                                                        className="path8"></span><span className="path9"></span><span
                                                        className="path10"></span><span className="path11"></span><span
                                                        className="path12"></span><span className="path13"></span><span
                                                        className="path14"></span><span className="path15"></span><span
                                                        className="path16"></span></span>
                                            </div>
                                            <div className="title">
                                                <h3>Company Details</h3>
                                                <p>Please fill out your company details here.</p>
                                            </div>
                                        </div>

                                        <div className="row">
                                            <div className="col-xl-6">
                                                <div className="form-group">
                                                    <div className="input-box">
                                                        <input type="text" name="company_name" id="CompanyName"
                                                            placeholder="Company Name*" required=""/>
                                                    </div>
                                                </div>
                                            </div>
                                            <div className="col-xl-6">
                                                <div className="form-group">
                                                    <div className="input-box">
                                                        <input type="text" name="form_website" id="formWebsite"
                                                            placeholder="Website" required=""/>
                                                    </div>
                                                </div>
                                            </div>
                                            <div className="col-xl-6">
                                                <div className="form-group">
                                                    <div className="input-box">
                                                        <div className="select-box clearfix">
                                                            <select className="wide">
                                                                <option data-display="Industry">Industry</option>
                                                                <option value="1">Industry 01</option>
                                                                <option value="2">Industry 02</option>
                                                                <option value="3">Industry 03</option>
                                                                <option value="3">Industry 04</option>
                                                            </select>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div className="col-xl-6">
                                                <div className="form-group">
                                                    <div className="input-box">
                                                        <div className="select-box clearfix">
                                                            <select className="wide">
                                                                <option data-display="Country">Country</option>
                                                                <option value="1">India</option>
                                                                <option value="2">Pakistan</option>
                                                                <option value="3">Bangladesh</option>
                                                                <option value="3">Usa</option>
                                                            </select>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div className="row">
                                            <div className="col-xl-12">
                                                <div className="form-group">
                                                    <div className="input-box">
                                                        <input type="text" name="form_address" id="formAddress"
                                                            placeholder="Address (eg: No,Street,City,State,Zip)" required=""/>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                
                                <div className="col-xl-6 col-lg-6">
                                    <div className="company-details-form company-details-form--2">
                                        <div className="title-box">
                                            <div className="icon">
                                                <span className="icon-phone"><span className="path1"></span><span
                                                        className="path2"></span><span className="path3"></span><span
                                                        className="path4"></span><span className="path5"></span><span
                                                        className="path6"></span><span className="path7"></span><span
                                                        className="path8"></span><span className="path9"></span><span
                                                        className="path10"></span><span className="path11"></span></span>
                                            </div>
                                            <div className="title">
                                                <h3>Contact Person</h3>
                                                <p>Please fill out your company details here.</p>
                                            </div>
                                        </div>

                                        <div className="row">
                                            <div className="col-xl-6">
                                                <div className="form-group">
                                                    <div className="input-box">
                                                        <input type="text" name="form_fname" id="formfName"
                                                            placeholder="First Name*" required=""/>
                                                    </div>
                                                </div>
                                            </div>
                                            <div className="col-xl-6">
                                                <div className="form-group">
                                                    <div className="input-box">
                                                        <input type="text" name="form_lname" id="formlName"
                                                            placeholder="Last Name*" required=""/>
                                                    </div>
                                                </div>
                                            </div>
                                            <div className="col-xl-6">
                                                <div className="form-group">
                                                    <div className="input-box">
                                                        <input type="text" name="form_landline" id="formLandline"
                                                            placeholder="Landline*" required=""/>
                                                    </div>
                                                </div>
                                            </div>
                                            <div className="col-xl-6">
                                                <div className="form-group">
                                                    <div className="input-box">
                                                        <input type="text" name="form_mobile" id="formMobile"
                                                            placeholder="Mobile" required=""/>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div className="row">
                                            <div className="col-xl-12">
                                                <div className="form-group">
                                                    <div className="input-box">
                                                        <input type="email" name="form_email" id="formEmail"
                                                            placeholder="Email*" required=""/>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                
                                <div className="col-xl-12">
                                    <div className="company-details-form job-details-form">
                                        <div className="title-box">
                                            <div className="icon">
                                                <span className="icon-candidates"><span className="path1"></span><span
                                                        className="path2"></span><span className="path3"></span><span
                                                        className="path4"></span><span className="path5"></span><span
                                                        className="path6"></span></span>
                                            </div>
                                            <div className="title">
                                                <h3>Request Talent</h3>
                                                <p>Here you can leave your job details & Submit your job post.</p>
                                            </div>
                                        </div>

                                        <div className="row">
                                            <div className="col-xl-8">
                                                <div className="row">
                                                    <div className="col-xl-6">
                                                        <div className="form-group">
                                                            <div className="input-box">
                                                                <div className="select-box clearfix">
                                                                    <select className="wide">
                                                                        <option data-display="Specialisation">Specialisation
                                                                        </option>
                                                                        <option value="1">Specialisation 01</option>
                                                                        <option value="2">Specialisation 02</option>
                                                                        <option value="3">Specialisation 03</option>
                                                                        <option value="3">Specialisation 04</option>
                                                                    </select>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div className="col-xl-6">
                                                        <div className="form-group">
                                                            <div className="input-box">
                                                                <input type="text" name="form_position" id="formPosition"
                                                                    placeholder="Position hiring for" required=""/>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div className="col-xl-6">
                                                        <div className="form-group">
                                                            <div className="input-box">
                                                                <input type="text" name="form_location" id="formLocation"
                                                                    placeholder="Job Location" required=""/>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div className="col-xl-6">
                                                        <div className="form-group">
                                                            <div className="input-box">
                                                                <div className="select-box clearfix">
                                                                    <select className="wide">
                                                                        <option data-display="Preferred-Pronoun">Preferred
                                                                            Pronoun
                                                                        </option>
                                                                        <option value="1">Preferred Pronoun 01</option>
                                                                        <option value="2">Preferred Pronoun 02</option>
                                                                        <option value="3">Preferred Pronoun 03</option>
                                                                        <option value="3">Preferred Pronoun 04</option>
                                                                    </select>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div className="col-xl-6">
                                                        <div className="form-group">
                                                            <div className="input-box">
                                                                <input type="text" name="form_rate" id="formRate"
                                                                    placeholder="Pay Rate Range" required=""/>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div className="col-xl-6">
                                                        <div className="form-group">
                                                            <div className="input-box">
                                                                <div className="select-box clearfix">
                                                                    <select className="wide">
                                                                        <option data-display="Number-Openings">Number of
                                                                            Openings
                                                                        </option>
                                                                        <option value="1">Number of Openings 01</option>
                                                                        <option value="2">Number of Openings 02</option>
                                                                        <option value="3">Number of Openings 03</option>
                                                                        <option value="3">Number of Openings 04</option>
                                                                    </select>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>

                                            <div className="col-xl-4">
                                                <div className="form-group">
                                                    <div className="input-box">
                                                        <textarea name="form_message" id="formMessage"
                                                            placeholder="Job Description" required=""></textarea>
                                                    </div>
                                                </div>
                                                <div className="button-box">
                                                    <button className="btn-one" type="submit" data-loading-text="Please wait...">
                                                        <span className="txt">
                                                            Post Your Need
                                                        </span>
                                                    </button>
                                                </div>
                                            </div>

                                        </div>
                                    </div>
                                </div>

                            </div>
                        </form>
                    </div>
                </section>
            </Layout>
        </div>
    )
}