'use client'
import React from 'react'
import Link from "next/link"
import Layout from "@/components/layout/Layout"
import CounterUp from "@/components/elements/CounterUp"
import { Autoplay, Navigation, Pagination } from "swiper/modules"
import { Swiper, SwiperSlide } from "swiper/react"
import Pricing from '@/components/sections/home1/Pricing'
import Featurs from '@/components/sections/home5/Featurs'
const swiperOptions = {
    modules: [Autoplay, Pagination, Navigation],
    slidesPerView: 1,
    spaceBetween: 30,
    autoplay: {
        delay: 5000,
        disableOnInteraction: false,
    },
    loop: true,

    // Navigation
    navigation: {
        nextEl: '.swiper-button-prev',
        prevEl: '.swiper-button-next',
    },

    breakpoints: {
        320: {
            slidesPerView: 1,
            spaceBetween: 30,
        },
        575: {
            slidesPerView: 1,
            spaceBetween: 30,
        },
        767: {
            slidesPerView: 2,
            spaceBetween: 30,
        },
        991: {
            slidesPerView: 2,
            spaceBetween: 30,
        },
        1199: {
            slidesPerView: 3,
            spaceBetween: 30,
        },
        1750: {
            slidesPerView: 3,
            spaceBetween: 30,
        },
    }
}

export default function Overview_page_two() {
    return (
        <div className="page-wrapper boxed_wrapper">
            <Layout headerStyle={1} footerStyle={1} breadcrumbTitle="Overview">

                <section className="page-banner pdt">
                    <div className="container">
                        <div className="sec-title withtext text-center">
                            <div className="sub-title">
                                <h4>Welcome to Hiringhub</h4>
                            </div>
                            <h2>Navigating Careers Together</h2>
                            <div className="text">
                                <p>
                                    Long established fact that a reader will be distracted by the<br/>readable content of a page.
                                </p>
                            </div>
                        </div>
                        <div className="page-banner__inner">
                            <div className="page-banner__shape">
                                <img src="assets/images/shapes/page-banner__shape1.png" alt="shape"/>
                            </div>
                            <div className="page-banner__content">
                                <div className="sub-title">
                                    <h3>The Perfect</h3>
                                </div>
                                <div className="big-title">Profession</div>
                                <div className="title-box">
                                    <h3>is waiting for You</h3>
                                    <p>Beguiled and demoralized by the charms of pleasure moment.</p>
                                </div>
                                <div className="btn-box">
                                    <Link className="btn-one" href="/apply-now">
                                        <span className="txt">Apply Now</span>
                                    </Link>
                                </div>
                            </div>
                            <div className="page-banner__img"
                                style={{ backgroundImage: "url(assets/images/resources/page-banner__img2.jpg)" }}>
                            </div>
                        </div>
                    </div>
                </section>

                <section className="fact-counter-style2 pdb120">
                    <div className="container">
                        <ul className="row fact-counter-style2--row">
                            <li className="col-xl-3 col-lg-3 col-md-6 text-center">
                                <div className="fact-counter-style1__single fact-counter-style1__single--style2">
                                    <div className="fact-counter-box">
                                        <div className="round-box"></div>
                                        <div className="counter-box">
                                            <h2>
                                                <span className="odometer"><CounterUp end={24} /></span>
                                                <span className="k">k</span>
                                            </h2>
                                        </div>
                                        <p>Employees hired in<br/>last year</p>
                                    </div>
                                </div>
                            </li>
                            
                            <li className="col-xl-3 col-lg-3 col-md-6 text-center">
                                <div className="fact-counter-style1__single fact-counter-style1__single--style2">
                                    <div className="fact-counter-box">
                                        <div className="round-box"></div>
                                        <div className="counter-box">
                                            <h2>
                                                <span className="odometer"><CounterUp end={839} /></span>
                                            </h2>
                                        </div>
                                        <p>Employers formed in<br/>last year</p>
                                    </div>
                                </div>
                            </li>
                            
                            <li className="col-xl-3 col-lg-3 col-md-6 text-center">
                                <div className="fact-counter-style1__single fact-counter-style1__single--style2">
                                    <div className="fact-counter-box">
                                        <div className="round-box"></div>
                                        <div className="counter-box">
                                            <h2>
                                                <span className="odometer"><CounterUp end={36} /></span>
                                                <span className="k">+</span>
                                            </h2>
                                        </div>
                                        <p>Countries Served by<br/>our team</p>
                                    </div>
                                </div>
                            </li>
                            
                            <li className="col-xl-3 col-lg-3 col-md-6 text-center">
                                <div className="fact-counter-style1__single fact-counter-style1__single--style2">
                                    <div className="fact-counter-box">
                                        <div className="round-box"></div>
                                        <div className="counter-box">
                                            <h2>
                                                <span className="odometer"><CounterUp end={99} /></span>
                                                <span className="k">%</span>
                                            </h2>
                                        </div>
                                        <p>Client Successful<br/>Rate</p>
                                    </div>
                                </div>
                            </li>
                        </ul>

                    </div>
                </section>
                
                <section className="service-style4">
                    <div className="service-style4__gray-bg"></div>
                    <div className="container">
                        <div className="sec-title withtext text-center">
                            <div className="sub-title">
                                <h4>jobs by field</h4>
                            </div>
                            <h2>Explore Careers by Industry</h2>
                            <div className="text">
                                <p>
                                    Long established fact that a reader will be distracted by the<br/>readable content of a page.
                                </p>
                            </div>
                        </div>
                        <div className="service-style4__inner">
                            <ul className="row">

                                <li className="col-xl-4 col-lg-4 col-md-6">
                                    <div className="service-style4__single">
                                        <div className="service-style4__img">
                                            <img src="assets/images/services/service-v4-1.jpg" alt="image"/>
                                        </div>
                                        <div className="service-style4__content text-center">
                                            <div className="icon-box">
                                                <img src="assets/images/icon/services/service-v4-icon1.png" alt="icon"/>
                                            </div>
                                            <div className="title-box">
                                                <h3><Link href="/job-seekers-overview">Accounting & Finance</Link></h3>
                                                <p>129 Job Vacancies</p>
                                            </div>
                                            <div className="btn-box">
                                                <Link href="/job-seekers-overview">
                                                    Explore
                                                    <i className="icon-arrow-angle-pointing-to-right"></i>
                                                </Link>
                                            </div>
                                        </div>
                                    </div>
                                </li>
                                <li className="col-xl-4 col-lg-4 col-md-6">
                                    <div className="service-style4__single">
                                        <div className="service-style4__img">
                                            <img src="assets/images/services/service-v4-2.jpg" alt="image"/>
                                        </div>
                                        <div className="service-style4__content text-center">
                                            <div className="icon-box">
                                                <img src="assets/images/icon/services/service-v4-icon2.png" alt="icon"/>
                                            </div>
                                            <div className="title-box">
                                                <h3><Link href="/job-seekers-overview">Digital Marketing</Link></h3>
                                                <p>235 Job Vacancies</p>
                                            </div>
                                            <div className="btn-box">
                                                <Link href="/job-seekers-overview">
                                                    Explore
                                                    <i className="icon-arrow-angle-pointing-to-right"></i>
                                                </Link>
                                            </div>
                                        </div>
                                    </div>
                                </li>
                                <li className="col-xl-4 col-lg-4 col-md-6">
                                    <div className="service-style4__single">
                                        <div className="service-style4__img">
                                            <img src="assets/images/services/service-v4-3.jpg" alt="image"/>
                                        </div>
                                        <div className="service-style4__content text-center">
                                            <div className="icon-box">
                                                <img src="assets/images/icon/services/service-v4-icon3.png" alt="icon"/>
                                            </div>
                                            <div className="title-box">
                                                <h3><Link href="/job-seekers-overview">Heathcare & Medical</Link></h3>
                                                <p>106 Job Vacancies</p>
                                            </div>
                                            <div className="btn-box">
                                                <Link href="/job-seekers-overview">
                                                    Explore
                                                    <i className="icon-arrow-angle-pointing-to-right"></i>
                                                </Link>
                                            </div>
                                        </div>
                                    </div>
                                </li>
                                <li className="col-xl-4 col-lg-4 col-md-6">
                                    <div className="service-style4__single">
                                        <div className="service-style4__img">
                                            <img src="assets/images/services/service-v4-4.jpg" alt="image"/>
                                        </div>
                                        <div className="service-style4__content text-center">
                                            <div className="icon-box">
                                                <img src="assets/images/icon/services/service-v4-icon4.png" alt="icon"/>
                                            </div>
                                            <div className="title-box">
                                                <h3><Link href="/job-seekers-overview">Information Technology</Link></h3>
                                                <p>314 Job Vacancies</p>
                                            </div>
                                            <div className="btn-box">
                                                <Link href="/job-seekers-overview">
                                                    Explore
                                                    <i className="icon-arrow-angle-pointing-to-right"></i>
                                                </Link>
                                            </div>
                                        </div>
                                    </div>
                                </li>
                                <li className="col-xl-4 col-lg-4 col-md-6">
                                    <div className="service-style4__single">
                                        <div className="service-style4__img">
                                            <img src="assets/images/services/service-v4-5.jpg" alt="image"/>
                                        </div>
                                        <div className="service-style4__content text-center">
                                            <div className="icon-box">
                                                <img src="assets/images/icon/services/service-v4-icon5.png" alt="icon"/>
                                            </div>
                                            <div className="title-box">
                                                <h3><Link href="/job-seekers-overview">Logistics & Services</Link></h3>
                                                <p>100 Job Vacancies</p>
                                            </div>
                                            <div className="btn-box">
                                                <Link href="/job-seekers-overview">
                                                    Explore
                                                    <i className="icon-arrow-angle-pointing-to-right"></i>
                                                </Link>
                                            </div>
                                        </div>
                                    </div>
                                </li>
                                <li className="col-xl-4 col-lg-4 col-md-6">
                                    <div className="service-style4__single">
                                        <div className="service-style4__img">
                                            <img src="assets/images/services/service-v4-6.jpg" alt="image"/>
                                        </div>
                                        <div className="service-style4__content text-center">
                                            <div className="icon-box">
                                                <img src="assets/images/icon/services/service-v4-icon6.png" alt="icon"/>
                                            </div>
                                            <div className="title-box">
                                                <h3><Link href="/job-seekers-overview">Front Line Support</Link></h3>
                                                <p>48 Job Vacancies</p>
                                            </div>
                                            <div className="btn-box">
                                                <Link href="/job-seekers-overview">
                                                    Explore
                                                    <i className="icon-arrow-angle-pointing-to-right"></i>
                                                </Link>
                                            </div>
                                        </div>
                                    </div>
                                </li>

                            </ul>
                        </div>
                        <div className="bottom-text text-center">
                            <p>
                                Explore more categories for more opportunities.
                                <Link href="/employers-overview">
                                    Explore More
                                    <i className="icon-arrow-angle-pointing-to-right"></i>
                                </Link>
                            </p>
                        </div>
                    </div>
                </section>

                <section class="why-choose-style3 why-choose-style3--style2">
                    <div class="container">
                        <div class="sec-title">
                            <div class="sub-title">
                                <h4>Why Choose Us</h4>
                            </div>
                            <h2>Advantages of Working With Us</h2>
                        </div>
                        <div class="row">
                            <div class="col-xl-12">
                                <div className='slider-content'>
                                    <Swiper {...swiperOptions} className="swiper-container why-choose-style3--style2-carousel">
                                        <SwiperSlide>
                                            <div class="why-choose-style3__single why-choose-style3__single--style2">
                                                <div class="icon-box">
                                                    <img src="assets/images/icon/why-choose/why-choose-v3-style2-icon-1.png" alt="icon"/>
                                                </div>
                                                <div class="title-box">
                                                    <h3><Link href="/job-seekers-overview">Reduce Hiring<br/>Risks</Link></h3>
                                                    <p>Denounce with righteous indignation &<br/>men who are so beguiled.</p>
                                                </div>
                                                <div class="count-box">
                                                    <h1>01</h1>
                                                </div>
                                            </div>
                                        </SwiperSlide>
                                        <SwiperSlide>
                                            <div class="why-choose-style3__single why-choose-style3__single--style2">
                                                <div class="icon-box">
                                                    <img src="assets/images/icon/why-choose/why-choose-v3-style2-icon-2.png" alt="icon"/>
                                                </div>
                                                <div class="title-box">
                                                    <h3><Link href="/job-seekers-overview">Increase<br/>Efficiencies</Link></h3>
                                                    <p>Power of choice is untrammelled when<br/>nothing prevents our being to do.</p>
                                                </div>
                                                <div class="count-box">
                                                    <h1>02</h1>
                                                </div>
                                            </div>
                                        </SwiperSlide>
                                        <SwiperSlide>
                                            <div class="why-choose-style3__single why-choose-style3__single--style2">
                                                <div class="icon-box">
                                                    <img src="assets/images/icon/why-choose/why-choose-v3-style2-icon-3.png" alt="icon"/>
                                                </div>
                                                <div class="title-box">
                                                    <h3><Link href="/job-seekers-overview">Deeper Talent<br/>Pools</Link></h3>
                                                    <p>Obligations business will fail frequently<br/>occur that pleasures.</p>
                                                </div>
                                                <div class="count-box">
                                                    <h1>03</h1>
                                                </div>
                                            </div>
                                        </SwiperSlide>
                                        <SwiperSlide>
                                            <div class="why-choose-style3__single why-choose-style3__single--style2">
                                                <div class="icon-box">
                                                    <img src="assets/images/icon/why-choose/why-choose-v3-style2-icon-1.png" alt="icon"/>
                                                </div>
                                                <div class="title-box">
                                                    <h3><Link href="/job-seekers-overview">Reduce Hiring<br/>Risks</Link></h3>
                                                    <p>Denounce with righteous indignation &<br/>men who are so beguiled.</p>
                                                </div>
                                                <div class="count-box">
                                                    <h1>01</h1>
                                                </div>
                                            </div>
                                        </SwiperSlide>
                                        <SwiperSlide>
                                            <div class="why-choose-style3__single why-choose-style3__single--style2">
                                                <div class="icon-box">
                                                    <img src="assets/images/icon/why-choose/why-choose-v3-style2-icon-2.png" alt="icon"/>
                                                </div>
                                                <div class="title-box">
                                                    <h3><Link href="/job-seekers-overview">Increase<br/>Efficiencies</Link></h3>
                                                    <p>Power of choice is untrammelled when<br/>nothing prevents our being to do.</p>
                                                </div>
                                                <div class="count-box">
                                                    <h1>02</h1>
                                                </div>
                                            </div>
                                        </SwiperSlide>
                                        <SwiperSlide>
                                            <div class="why-choose-style3__single why-choose-style3__single--style2">
                                                <div class="icon-box">
                                                    <img src="assets/images/icon/why-choose/why-choose-v3-style2-icon-3.png" alt="icon"/>
                                                </div>
                                                <div class="title-box">
                                                    <h3><Link href="/job-seekers-overview">Deeper Talent<br/>Pools</Link></h3>
                                                    <p>Obligations business will fail frequently<br/>occur that pleasures.</p>
                                                </div>
                                                <div class="count-box">
                                                    <h1>03</h1>
                                                </div>
                                            </div>
                                        </SwiperSlide>
                                    </Swiper>
                                    <div class="swiper-nav-style-one">
                                        <button class="swiper-button-prev">
                                            <span class="left icon-left-arrow-angle-big-gross-symbol"></span>
                                        </button>
                                        <button class="swiper-button-next">
                                            <span class="right icon-arrow-angle-pointing-to-right"></span>
                                        </button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </section>

                <Featurs/>
                <Pricing/>
                <section className="essential-guide-style1">
                    <div className="container">
                        <div className="sec-title withtext text-center">
                            <div className="sub-title">
                                <h4>Essential Guide</h4>
                            </div>
                            <h2>Discover Fundamental Essentials</h2>
                            <div className="text">
                                <p>
                                    Long established fact that a reader will be distracted by the<br/>readable content of a page.
                                </p>
                            </div>
                        </div>
                        <div className="row">
                            <div className="col-xl-4 col-lg-6 col-md-6">
                                <div className="single-essential-guide-style1">
                                    <div className="img-box">
                                        <div className="icon-box">
                                            <img src="assets/images/icon/essential-guide/essential-guide-style1-icon-1.png"
                                                alt="icon"/>
                                        </div>
                                        <div className="inner">
                                            <img src="assets/images/resources/essential-guide-v1-1.jpg" alt="image"/>
                                        </div>
                                        <div className="overlay-title">
                                            <div className="arrow-right"
                                                style={{ backgroundImage: "url(assets/images/shapes/arrow-1.png)" }}></div>
                                            <h3><Link href="/employers-overview">Post Your Need</Link></h3>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            
                            <div className="col-xl-4 col-lg-6 col-md-6">
                                <div className="single-essential-guide-style1">
                                    <div className="img-box">
                                        <div className="icon-box">
                                            <img src="assets/images/icon/essential-guide/essential-guide-style1-icon-2.png"
                                                alt="icon"/>
                                        </div>
                                        <div className="inner">
                                            <img src="assets/images/resources/essential-guide-v1-2.jpg" alt="image"/>
                                        </div>
                                        <div className="overlay-title">
                                            <div className="arrow-right"
                                                style={{ backgroundImage: "url(assets/images/shapes/arrow-1.png)" }}></div>
                                            <h3><Link href="/employers-overview">Executive Search</Link></h3>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            
                            <div className="col-xl-4 col-lg-6 col-md-6">
                                <div className="single-essential-guide-style1">
                                    <div className="img-box">
                                        <div className="icon-box">
                                            <img src="assets/images/icon/essential-guide/essential-guide-style1-icon-3.png"
                                                alt="icon"/>
                                        </div>
                                        <div className="inner">
                                            <img src="assets/images/resources/essential-guide-v1-3.jpg" alt="image"/>
                                        </div>
                                        <div className="overlay-title">
                                            <div className="arrow-right"
                                                style={{ backgroundImage: "url(assets/images/shapes/arrow-1.png)" }}></div>
                                            <h3><Link href="/employers-overview">News & Updates</Link></h3>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </section>
            </Layout>
        </div>
    )
}