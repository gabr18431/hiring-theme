'use client'
import React from 'react'
import Layout from "@/components/layout/Layout"
import Partner from '@/components/sections/home5/Partner'

export default function Job_apply_page() {
    return (
        <div className="page-wrapper boxed_wrapper">
            <Layout headerStyle={1} footerStyle={6} breadcrumbTitle="Apply Now">
                <section className="place-job-form apply-now-form">
                    <div className="container">
                        <div className="sec-title withtext text-center">
                            <div className="sub-title">
                                <h4>Career Pathways</h4>
                            </div>
                            <h2>Start Your Dream Career Here</h2>
                            <div className="text">
                                <p>
                                    Long established fact that a reader will be distracted by the<br/>
                                    readable content of a page.
                                </p>
                            </div>
                        </div>
                        <form id="place-job-form-box" className="place-job-form-box apply-now-form-box" name="job-form" action="#"
                            method="post">
                            <div className="row">

                                <div className="col-xl-6 col-lg-6">
                                    <div className="company-details-form">
                                        <div className="title-box">
                                            <div className="icon">
                                                <span className="icon-profile-1"><span className="path1"></span><span
                                                        className="path2"></span><span className="path3"></span><span
                                                        className="path4"></span><span className="path5"></span><span
                                                        className="path6"></span><span className="path7"></span><span
                                                        className="path8"></span><span className="path9"></span></span>
                                            </div>
                                            <div className="title">
                                                <h3>Basic Infomation</h3>
                                                <p>Please fill out your basic informations here.</p>
                                            </div>
                                        </div>

                                        <div className="row">
                                            <div className="col-xl-6">
                                                <div className="form-group">
                                                    <div className="input-box">
                                                        <input type="text" name="form_fname" id="FName"
                                                            placeholder="First Name*" required=""/>
                                                    </div>
                                                </div>
                                            </div>
                                            <div className="col-xl-6">
                                                <div className="form-group">
                                                    <div className="input-box">
                                                        <input type="text" name="form_lName" id="LName" placeholder="Last Name*"
                                                            required=""/>
                                                    </div>
                                                </div>
                                            </div>
                                            <div className="col-xl-6">
                                                <div className="form-group">
                                                    <div className="input-box">
                                                        <input type="email" name="form_email" id="formEmail"
                                                            placeholder="Email*" required=""/>
                                                    </div>
                                                </div>
                                            </div>
                                            <div className="col-xl-6">
                                                <div className="form-group">
                                                    <div className="input-box">
                                                        <input type="text" name="form_mobile" id="formMobile"
                                                            placeholder="Mobile" required=""/>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div className="row">
                                            <div className="col-xl-12">
                                                <div className="form-group">
                                                    <input type="text" name="form_address" id="formAddress"
                                                        placeholder="Address*" required=""/>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                
                                <div className="col-xl-6 col-lg-6">
                                    <div className="company-details-form company-details-form--1">
                                        <div className="title-box">
                                            <div className="icon">
                                                <span className="icon-analytics"><span className="path1"></span><span
                                                        className="path2"></span><span className="path3"></span><span
                                                        className="path4"></span><span className="path5"></span></span>
                                            </div>
                                            <div className="title">
                                                <h3>Qualification</h3>
                                                <p>Please fill out your qualification details here.</p>
                                            </div>
                                        </div>

                                        <div className="row">
                                            <div className="col-xl-6">
                                                <div className="form-group">
                                                    <div className="input-box">
                                                        <input type="text" name="form_education" id="formEducation"
                                                            placeholder="Education" required=""/>
                                                    </div>
                                                </div>
                                            </div>
                                            <div className="col-xl-6">
                                                <div className="form-group">
                                                    <div className="input-box">
                                                        <div className="select-box clearfix">
                                                            <select className="wide">
                                                                <option data-display="Skills">Skills</option>
                                                                <option value="1">Skills 01</option>
                                                                <option value="2">Skills 02</option>
                                                                <option value="3">Skills 03</option>
                                                                <option value="3">Skills 04</option>
                                                            </select>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div className="col-xl-6">
                                                <div className="form-group">
                                                    <div className="input-box">
                                                        <input type="text" name="form_texperience" id="formTExperience"
                                                            placeholder="Total Experience" required=""/>
                                                    </div>
                                                </div>
                                            </div>
                                            <div className="col-xl-6">
                                                <div className="form-group">
                                                    <div className="input-box">
                                                        <input type="text" name="form_pqualities" id="formPQualities"
                                                            placeholder="Personal Qualities" required=""/>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div className="row">
                                            <div className="col-xl-12">
                                                <div className="form-group form-group--2">
                                                    <div className="input-box">
                                                        <input type="text" name="form_files" id="formfiles"
                                                            placeholder="Drag & Drop your files here (50mb Max)" required=""/>
                                                        <button className="submit btn-one">
                                                            <span className="txt">Browse</span>
                                                        </button>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                
                                <div className="col-xl-12">
                                    <div className="company-details-form apply-now-details-form">
                                        <div className="row">
                                            <div className="col-xl-6 col-lg-6">
                                                <div className="form-group">
                                                    <div className="input-box">
                                                        <input type="text" name="form_jnumber" id="formJNumber"
                                                            placeholder="Job Number" required=""/>
                                                    </div>
                                                </div>
                                            </div>
                                            <div className="col-xl-6 col-lg-6">
                                                <div className="form-group">
                                                    <div className="input-box">
                                                        <div className="select-box clearfix">
                                                            <select className="wide">
                                                                <option data-display="Desire Work Status">Desire Work Status
                                                                </option>
                                                                <option value="1">Desire Work Status 01</option>
                                                                <option value="2">Desire Work Status 02</option>
                                                                <option value="3">Desire Work Status 03</option>
                                                                <option value="3">Desire Work Status 04</option>
                                                            </select>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div className="form-group">
                                            <div className="input-box">
                                                <textarea name="form_message" id="formMessage" placeholder="Additional Info..."
                                                    required=""></textarea>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                
                                <div className="col-xl-12">
                                    <div className="company-details-form apply-now-details-form apply-now-details-form--2">
                                        <div className="form-group">
                                            <div className="input-box">
                                                <button className="submit btn-one">
                                                    <span className="txt">Apply for Job</span>
                                                </button>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                            </div>
                        </form>
                    </div>
                </section>
                <Partner/>
            </Layout>
        </div>
    )
}