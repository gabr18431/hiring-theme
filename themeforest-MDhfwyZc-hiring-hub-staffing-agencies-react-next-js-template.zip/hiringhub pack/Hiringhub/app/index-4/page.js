import Layout from "@/components/layout/Layout"
import Work from "@/components/sections/home1/Work"
import About from "@/components/sections/home2/About"
import Blog from "@/components/sections/home2/Blog"
import Case from "@/components/sections/home2/Case"
import Video from "@/components/sections/home3/Video"
import Banner from "@/components/sections/home4/Banner"
import Choose from "@/components/sections/home4/Choose"
import Counter from "@/components/sections/home4/Counter"
import Scroll_Text from "@/components/sections/home4/Scrolling_Text"
import Service from "@/components/sections/home4/Service"
import Service_Two from "@/components/sections/home4/Service_Two"
import Slogan from "@/components/sections/home4/Slogan"
import Testimonial from "@/components/sections/home4/Testimonial"
export default function Home_Four() {

    return (
        <div className="page-wrapper boxed_wrapper">
            <Layout headerStyle={4} footerStyle={4}>
                <Banner/>
                <Service/>
                <Counter/>
                <About/>
                <Service_Two/>
                <Video/>
                <Work/>
                <Choose/>
                <Case/>
                <Testimonial/>
                <Scroll_Text/>
                <Blog/>
                <Slogan/>
            </Layout>
        </div>
    )
}