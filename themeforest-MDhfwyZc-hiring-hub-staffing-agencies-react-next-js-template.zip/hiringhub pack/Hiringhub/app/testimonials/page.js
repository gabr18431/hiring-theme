'use client'
import React from 'react'
import Layout from "@/components/layout/Layout"

export default function Testimonials_page() {
    return (
        <div className="page-wrapper boxed_wrapper">
            <Layout headerStyle={1} footerStyle={6} breadcrumbTitle="Testimonials">
                <section className="testimonial-style1 instyle--2">
                    <div className="container">
                        <div className="row masonary-layout">
                            
                            <div className="col-xl-6 col-lg-6">
                                <div className="testimonial-style1__single instyle--2">
                                    <div className="overlay-icon">
                                        <span className="icon-quote"></span>
                                    </div>
                                    <div className="testimonial-style1__single-img">
                                        <img src="assets/images/testimonial/testimonial-v1-1.png" alt="image"/>
                                    </div>
                                    <div className="testimonial-style1__single-content">
                                        <div className="title-box">
                                            <h3>Career-Altering Guidance</h3>
                                            <p>
                                                Staffy is very accurate when comes to helping you
                                                find a job and if that job finishes, They help you to find
                                                an another job placement!.
                                            </p>
                                        </div>
                                        <div className="customer-info">
                                            <div className="rating-box">
                                                <div className="icon-box">
                                                    <span className="icon-rate-star-button"></span>
                                                </div>
                                                <div className="rating-number">
                                                    <h3>4.9</h3>
                                                </div>
                                            </div>
                                            <div className="company-name">
                                                <h3>Nathan Felix</h3>
                                                <span>Manager, Cypertech pvt ltd</span>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            
                            <div className="col-xl-6 col-lg-6">
                                <div className="testimonial-style1__single instyle--2">
                                    <div className="overlay-icon">
                                        <span className="icon-quote"></span>
                                    </div>
                                    <div className="testimonial-style1__single-img">
                                        <img src="assets/images/testimonial/testimonial-v1-2.png" alt="image"/>
                                    </div>
                                    <div className="testimonial-style1__single-content">
                                        <div className="title-box">
                                            <h3>Best Hiring Assistance</h3>
                                            <p>
                                                I really appreciated the outstanding time, work & effort that the entire
                                                staff put into finding me an excellent job placement, Thank you so much.
                                            </p>
                                        </div>
                                        <div className="customer-info">
                                            <div className="rating-box">
                                                <div className="icon-box">
                                                    <span className="icon-rate-star-button"></span>
                                                </div>
                                                <div className="rating-number">
                                                    <h3>5.0</h3>
                                                </div>
                                            </div>
                                            <div className="company-name">
                                                <h3>Eloise Juniper</h3>
                                                <span>Vice president, Daily News</span>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            
                            <div className="col-xl-6 col-lg-6">
                                <div className="testimonial-style1__single">
                                    <div className="overlay-icon">
                                        <span className="icon-quote"></span>
                                    </div>
                                    <div className="testimonial-style1__single-img">
                                        <img src="assets/images/testimonial/testimonial-v1-3.png" alt="image"/>
                                    </div>
                                    <div className="testimonial-style1__single-content">
                                        <div className="title-box">
                                            <h3>Efficient Talent Solutions</h3>
                                            <p>
                                                Know how to pursue pleasure rationally encounter that are extremely painful
                                                again loves.
                                            </p>
                                        </div>
                                        <div className="customer-info">
                                            <div className="rating-box">
                                                <div className="icon-box">
                                                    <span className="icon-rate-star-button"></span>
                                                </div>
                                                <div className="rating-number">
                                                    <h3>4.9</h3>
                                                </div>
                                            </div>
                                            <div className="company-name">
                                                <h3>Ivor Hector</h3>
                                                <span>Founder, Futura Tech</span>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            
                            <div className="col-xl-6 col-lg-6">
                                <div className="testimonial-style1__single instyle--2">
                                    <div className="overlay-icon">
                                        <span className="icon-quote"></span>
                                    </div>
                                    <div className="testimonial-style1__single-img">
                                        <img src="assets/images/testimonial/testimonial-v1-4.png" alt="image"/>
                                    </div>
                                    <div className="testimonial-style1__single-content">
                                        <div className="title-box">
                                            <h3>Professional Guidance</h3>
                                            <p>
                                                Undertakes laborious physical exercise, except to obtain
                                                some advantage from it? But who has any right to find
                                                chooses to enjoy a pleasure.
                                            </p>
                                        </div>
                                        <div className="customer-info">
                                            <div className="rating-box">
                                                <div className="icon-box">
                                                    <span className="icon-rate-star-button"></span>
                                                </div>
                                                <div className="rating-number">
                                                    <h3>5.0</h3>
                                                </div>
                                            </div>
                                            <div className="company-name">
                                                <h3>Freddie Esther</h3>
                                                <span>Team leader, Sysco Solutions </span>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            
                            <div className="col-xl-6 col-lg-6">
                                <div className="testimonial-style1__single instyle--2">
                                    <div className="overlay-icon">
                                        <span className="icon-quote"></span>
                                    </div>
                                    <div className="testimonial-style1__single-img">
                                        <img src="assets/images/testimonial/testimonial-v1-5.png" alt="image"/>
                                    </div>
                                    <div className="testimonial-style1__single-content">
                                        <div className="title-box">
                                            <h3>Tailored Placement</h3>
                                            <p>
                                                Expound the actual teachings of the great explorer of the truth, the
                                                master-builder of human happiness. No one dislikes avoids extremely.
                                            </p>
                                        </div>
                                        <div className="customer-info">
                                            <div className="rating-box">
                                                <div className="icon-box">
                                                    <span className="icon-rate-star-button"></span>
                                                </div>
                                                <div className="rating-number">
                                                    <h3>5.0</h3>
                                                </div>
                                            </div>
                                            <div className="company-name">
                                                <h3>Eloise Juniper</h3>
                                                <span>Vice president, Daily News</span>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            
                            <div className="col-xl-6 col-lg-6">
                                <div className="testimonial-style1__single instyle--2">
                                    <div className="overlay-icon">
                                        <span className="icon-quote"></span>
                                    </div>
                                    <div className="testimonial-style1__single-img">
                                        <img src="assets/images/testimonial/testimonial-v1-6.png" alt="image"/>
                                    </div>
                                    <div className="testimonial-style1__single-content">
                                        <div className="title-box">
                                            <h3>Dynamic Solutions</h3>
                                            <p>
                                                Take a trivial example, which of us ever undertakes
                                                laborious physical exercise advantage.
                                            </p>
                                        </div>
                                        <div className="customer-info">
                                            <div className="rating-box">
                                                <div className="icon-box">
                                                    <span className="icon-rate-star-button"></span>
                                                </div>
                                                <div className="rating-number">
                                                    <h3>4.9</h3>
                                                </div>
                                            </div>
                                            <div className="company-name">
                                                <h3>Nathan Felix</h3>
                                                <span>Manager, Cypertech pvt ltd</span>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>

                        </div>
                    </div>
                </section>
            </Layout>
        </div>
    )
}