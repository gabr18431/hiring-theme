import Layout from "@/components/layout/Layout"
import Pricing from "@/components/sections/home1/Pricing"
import Service from "@/components/sections/home1/Service"
import Testimonials from "@/components/sections/home1/Testmonials"
import About from "@/components/sections/home3/About"
import Banner from "@/components/sections/home3/Banner"
import Blog from "@/components/sections/home3/Blog"
import Case from "@/components/sections/home3/Case"
import Choose from "@/components/sections/home3/Choose"
import Faq from "@/components/sections/home3/Faq"
import Industries from "@/components/sections/home3/Industries"
import Job from "@/components/sections/home3/Job"
import Video from "@/components/sections/home3/Video"
export default function Home_Three() {

    return (
        <div className="page-wrapper boxed_wrapper">
            <Layout headerStyle={3} footerStyle={3}>
                <Banner/>
                <Job/>
                <Service/>
                <Choose/>
                <Industries/>
                <About/>
                <Video/>
                <Case/>
                <Pricing/>
                <Faq/>
                <Testimonials/>
                <Blog/>
            </Layout>
        </div>
    )
}