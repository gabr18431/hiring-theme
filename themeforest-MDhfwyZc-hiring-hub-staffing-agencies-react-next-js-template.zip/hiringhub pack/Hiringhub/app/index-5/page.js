import Layout from "@/components/layout/Layout"
import Blog from "@/components/sections/home1/Blog"
import Pricing from "@/components/sections/home1/Pricing"
import Service from "@/components/sections/home1/Service"
import Service_Two from "@/components/sections/home2/Service_Two"
import Case from "@/components/sections/home3/Case"
import Faq from "@/components/sections/home3/Faq"
import About from "@/components/sections/home5/About"
import Banner from "@/components/sections/home5/Banner"
import Featurs from "@/components/sections/home5/Featurs"
import Partner from "@/components/sections/home5/Partner"
import Work from "@/components/sections/home5/Work"
export default function Home_Five() {

    return (
        <div className="page-wrapper boxed_wrapper">
            <Layout headerStyle={5} footerStyle={5}>
                <Banner/>
                <Work/>
                <About/>
                <Service/>
                <Case/>
                <Featurs/>
                <Service_Two/>
                <Faq/>
                <Pricing/>
                <Blog/>
                <Partner/>
            </Layout>
        </div>
    )
}