'use client'
import React from 'react'
import Link from "next/link"

export default function Slogan() {
    return (
        <> 

            <section className="slogan-style1 slogan-style2">
                <div className="container">
                    <div className="slogan-style1__inner text-center">
                        <div className="big-title">
                            <h2>Onboard Remote Staff Quickly</h2>
                        </div>
                        <div className="text">
                            <p>Effortlessly tap into skilled remote talent with our simplified hiring.</p>
                        </div>
                        <div className="highlights-box">
                            <ul>
                                <li>
                                    <div className="icon">
                                        <span className="icon-bottom-up"></span>
                                    </div>
                                    <h4>Contract / Temprory</h4>
                                </li>
                                <li>
                                    <div className="icon">
                                        <span className="icon-bottom-up"></span>
                                    </div>
                                    <h4>Permanent Placement</h4>
                                </li>
                                <li>
                                    <div className="icon">
                                        <span className="icon-bottom-up"></span>
                                    </div>
                                    <h4>Permanent Placement</h4>
                                </li>
                            </ul>
                        </div>
                        <div className="contact-communicate">
                            <div className="contact-box box1">
                                <p>Have question?</p>
                                <Link href="/faq">
                                    Explore our FAQ section
                                    <i className="icon-arrow-angle-pointing-to-right"></i>
                                </Link>
                            </div>
                            <div className="icon-box">
                                <Link href="/faq">
                                    <span className="icon-question"><span className="path1"></span><span className="path2"></span><span
                                            className="path3"></span>
                                    </span>
                                </Link>
                                <a href="mailto:inquiries@hiringhub.com" className="box1">
                                    <span className="icon-mail"><span className="path1"></span><span className="path2"></span></span>
                                </a>
                            </div>
                            <div className="contact-box">
                                <p>Email Us</p>
                                <Link href="mailto:inquiries@hiringhub.com">inquiries@hiringhub.com</Link>
                            </div>
                        </div>
                    </div>
                </div>
            </section>

        </>
    )
}
