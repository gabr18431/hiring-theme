'use client'
import React from 'react'

export default function Scroll_Text() {
    return (
        <> 

            <section className="scrolling-text-style1">
                <div className="inner">
                    <ul className="clearfix marquee_mode">
                        <li data-hover="Testimonials">
                            Testimonials
                        </li>
                        <li data-hover="Testimonials">
                            Testimonials
                        </li>
                        <li data-hover="Testimonials">
                            Testimonials
                        </li>
                        <li data-hover="Testimonials">
                            Testimonials
                        </li>
                        <li data-hover="Testimonials">
                            Testimonials
                        </li>
                        <li data-hover="Testimonials">
                            Testimonials
                        </li>
                        <li data-hover="Testimonials">
                            Testimonials
                        </li>
                        <li data-hover="Testimonials">
                            Testimonials
                        </li>
                    </ul>
                </div>
            </section>

        </>
    )
}
