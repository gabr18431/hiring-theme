'use client'
import React from 'react'
import Link from "next/link"

export default function Service() {
    return (
        <> 

            <section className="service-style4">
                <div className="container">
                    <div className="sec-title withtext text-center">
                        <div className="sub-title">
                            <h4>Service Areas</h4>
                        </div>
                        <h2>Our Specialized Industries</h2>
                        <div className="text">
                            <p>
                                Long established fact that a reader will be distracted by the<br/>readable content of a page.
                            </p>
                        </div>
                    </div>
                    <div className="service-style4__inner">
                        <ul className="row">

                            <li className="col-xl-4 col-lg-4 col-md-6">
                                <div className="service-style4__single">
                                    <div className="service-style4__img">
                                        <img src="assets/images/services/service-v4-1.jpg" alt="image"/>
                                    </div>
                                    <div className="service-style4__content text-center">
                                        <div className="icon-box">
                                            <img src="assets/images/icon/services/service-v4-icon1.png" alt="icon"/>
                                        </div>
                                        <div className="title-box">
                                            <h3><Link href="/job-seekers-overview">Accounting & Finance</Link></h3>
                                            <p>129 Job Vacancies</p>
                                        </div>
                                        <div className="btn-box">
                                            <Link href="/job-seekers-overview">
                                                Explore
                                                <i className="icon-arrow-angle-pointing-to-right"></i>
                                            </Link>
                                        </div>
                                    </div>
                                </div>
                            </li>
                            <li className="col-xl-4 col-lg-4 col-md-6">
                                <div className="service-style4__single">
                                    <div className="service-style4__img">
                                        <img src="assets/images/services/service-v4-2.jpg" alt="image"/>
                                    </div>
                                    <div className="service-style4__content text-center">
                                        <div className="icon-box">
                                            <img src="assets/images/icon/services/service-v4-icon2.png" alt="icon"/>
                                        </div>
                                        <div className="title-box">
                                            <h3><Link href="/job-seekers-overview">Digital Marketing</Link></h3>
                                            <p>235 Job Vacancies</p>
                                        </div>
                                        <div className="btn-box">
                                            <Link href="/job-seekers-overview">
                                                Explore
                                                <i className="icon-arrow-angle-pointing-to-right"></i>
                                            </Link>
                                        </div>
                                    </div>
                                </div>
                            </li>
                            <li className="col-xl-4 col-lg-4 col-md-6">
                                <div className="service-style4__single">
                                    <div className="service-style4__img">
                                        <img src="assets/images/services/service-v4-3.jpg" alt="image"/>
                                    </div>
                                    <div className="service-style4__content text-center">
                                        <div className="icon-box">
                                            <img src="assets/images/icon/services/service-v4-icon3.png" alt="icon"/>
                                        </div>
                                        <div className="title-box">
                                            <h3><Link href="/job-seekers-overview">Heathcare & Medical</Link></h3>
                                            <p>106 Job Vacancies</p>
                                        </div>
                                        <div className="btn-box">
                                            <Link href="/job-seekers-overview">
                                                Explore
                                                <i className="icon-arrow-angle-pointing-to-right"></i>
                                            </Link>
                                        </div>
                                    </div>
                                </div>
                            </li>
                            <li className="col-xl-4 col-lg-4 col-md-6">
                                <div className="service-style4__single">
                                    <div className="service-style4__img">
                                        <img src="assets/images/services/service-v4-4.jpg" alt="image"/>
                                    </div>
                                    <div className="service-style4__content text-center">
                                        <div className="icon-box">
                                            <img src="assets/images/icon/services/service-v4-icon4.png" alt="icon"/>
                                        </div>
                                        <div className="title-box">
                                            <h3><Link href="/job-seekers-overview">Information Technology</Link></h3>
                                            <p>314 Job Vacancies</p>
                                        </div>
                                        <div className="btn-box">
                                            <Link href="/job-seekers-overview">
                                                Explore
                                                <i className="icon-arrow-angle-pointing-to-right"></i>
                                            </Link>
                                        </div>
                                    </div>
                                </div>
                            </li>
                            <li className="col-xl-4 col-lg-4 col-md-6">
                                <div className="service-style4__single">
                                    <div className="service-style4__img">
                                        <img src="assets/images/services/service-v4-5.jpg" alt="image"/>
                                    </div>
                                    <div className="service-style4__content text-center">
                                        <div className="icon-box">
                                            <img src="assets/images/icon/services/service-v4-icon5.png" alt="icon"/>
                                        </div>
                                        <div className="title-box">
                                            <h3><Link href="/job-seekers-overview">Logistics & Services</Link></h3>
                                            <p>100 Job Vacancies</p>
                                        </div>
                                        <div className="btn-box">
                                            <Link href="/job-seekers-overview">
                                                Explore
                                                <i className="icon-arrow-angle-pointing-to-right"></i>
                                            </Link>
                                        </div>
                                    </div>
                                </div>
                            </li>
                            <li className="col-xl-4 col-lg-4 col-md-6">
                                <div className="service-style4__single">
                                    <div className="service-style4__img">
                                        <img src="assets/images/services/service-v4-6.jpg" alt="image"/>
                                    </div>
                                    <div className="service-style4__content text-center">
                                        <div className="icon-box">
                                            <img src="assets/images/icon/services/service-v4-icon6.png" alt="icon"/>
                                        </div>
                                        <div className="title-box">
                                            <h3><Link href="/job-seekers-overview">Front Line Support</Link></h3>
                                            <p>48 Job Vacancies</p>
                                        </div>
                                        <div className="btn-box">
                                            <Link href="/job-seekers-overview">
                                                Explore
                                                <i className="icon-arrow-angle-pointing-to-right"></i>
                                            </Link>
                                        </div>
                                    </div>
                                </div>
                            </li>

                        </ul>
                    </div>
                    <div className="bottom-text text-center">
                        <p>
                            Explore more categories for more opportunities.
                            <Link href="/job-seekers-overview">
                                Explore More
                                <i className="icon-arrow-angle-pointing-to-right"></i>
                            </Link>
                        </p>
                    </div>
                </div>
            </section>

        </>
    )
}
