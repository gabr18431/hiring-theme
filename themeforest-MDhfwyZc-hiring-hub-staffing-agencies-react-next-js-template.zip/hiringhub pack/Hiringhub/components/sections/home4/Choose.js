'use client'
import React from 'react'
import Link from "next/link"

export default function Choose() {
    return (
        <> 

            <section className="why-choose-style3">
                <div className="container">
                    <div className="sec-title">
                        <div className="sub-title">
                            <h4>Why Choose Us</h4>
                        </div>
                        <h2>Advantages of Working With Us</h2>
                    </div>
                    <div className="row">

                        <div className="col-xl-4 col-lg-4 col-md-6">
                            <div className="why-choose-style3__single">
                                <div className="icon-box">
                                    <img src="assets/images/icon/why-choose/why-choose-v3-icon-1.png" alt="icon"/>
                                </div>
                                <div className="title-box">
                                    <h3><Link href="/about">Reduce Hiring<br/>Risks</Link></h3>
                                    <p>Denounce with righteous indignation &<br/>men who are so beguiled.</p>
                                </div>
                                <div className="count-box">
                                    <h1>01</h1>
                                </div>
                            </div>
                        </div>
                        
                        <div className="col-xl-4 col-lg-4 col-md-6">
                            <div className="why-choose-style3__single">
                                <div className="icon-box">
                                    <img src="assets/images/icon/why-choose/why-choose-v3-icon-2.png" alt="icon"/>
                                </div>
                                <div className="title-box">
                                    <h3><Link href="/about">Increase<br/>Efficiencies</Link></h3>
                                    <p>Power of choice is untrammelled when<br/>nothing prevents our being to do.</p>
                                </div>
                                <div className="count-box">
                                    <h1>02</h1>
                                </div>
                            </div>
                        </div>
                        
                        <div className="col-xl-4 col-lg-4 col-md-6">
                            <div className="why-choose-style3__single">
                                <div className="icon-box">
                                    <img src="assets/images/icon/why-choose/why-choose-v3-icon-3.png" alt="icon"/>
                                </div>
                                <div className="title-box">
                                    <h3><Link href="/about">Deeper Talent<br/>Pools</Link></h3>
                                    <p>Obligations business will fail frequently<br/>occur that pleasures.</p>
                                </div>
                                <div className="count-box">
                                    <h1>03</h1>
                                </div>
                            </div>
                        </div>
                        
                        <div className="col-xl-4 col-lg-4 col-md-6">
                            <div className="why-choose-style3__single">
                                <div className="icon-box">
                                    <img src="assets/images/icon/why-choose/why-choose-v3-icon-4.png" alt="icon"/>
                                </div>
                                <div className="title-box">
                                    <h3><Link href="/about">Onboarding<br/>Support</Link></h3>
                                    <p>Obligations business will fail frequently<br/>occur that pleasures.</p>
                                </div>
                                <div className="count-box">
                                    <h1>04</h1>
                                </div>
                            </div>
                        </div>
                        
                        <div className="col-xl-4 col-lg-4 col-md-6">
                            <div className="why-choose-style3__single">
                                <div className="icon-box">
                                    <img src="assets/images/icon/why-choose/why-choose-v3-icon-5.png" alt="icon"/>
                                </div>
                                <div className="title-box">
                                    <h3><Link href="/about">Effective<br/>Employer Branding</Link></h3>
                                    <p>Denounce with righteous indignation &<br/>men who are so beguiled.</p>
                                </div>
                                <div className="count-box">
                                    <h1>05</h1>
                                </div>
                            </div>
                        </div>
                        
                        <div className="col-xl-4 col-lg-4 col-md-6">
                            <div className="why-choose-style3__single">
                                <div className="icon-box">
                                    <img src="assets/images/icon/why-choose/why-choose-v3-icon-6.png" alt="icon"/>
                                </div>
                                <div className="title-box">
                                    <h3><Link href="/about">Deep Industry<br/>Knowledge</Link></h3>
                                    <p>Power of choice is untrammelled when<br/>nothing prevents our being to do.</p>
                                </div>
                                <div className="count-box">
                                    <h1>06</h1>
                                </div>
                            </div>
                        </div>

                    </div>
                </div>
            </section>

        </>
    )
}
