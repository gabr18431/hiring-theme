'use client'
import React from 'react'
import Link from "next/link"

export default function Banner() {
    return (
        <> 

            <section className="banner-style2">
                <div className="banner-style2__shape1">
                    <img src="assets/images/shapes/banner-style2-shape1.png" alt="shape"/>
                </div>
                <div className="banner-style2__bottom-bg-left"
                    style={{ backgroundImage: "url(assets/images/shapes/banner-style2-bottom-bg-left.png)" }}></div>

                <div className="banner-style2__bottom-bg-right"
                    style={{ backgroundImage: "url(assets/images/shapes/banner-style2-bottom-bg-right.png)" }}></div>
                <div className="banner-style2__content-social-links">
                    <ul>
                        <li>
                            <Link href="https://www.facebook.com/">
                                <span className="icon-facebook"></span>
                            </Link>
                        </li>
                        <li>
                            <Link href="https://x.com/i/flow/login">
                                <span className="icon-twitter"></span>
                            </Link>
                        </li>
                        <li>
                            <Link href="https://www.instagram.com/accounts/login/?hl=en">
                                <span className="icon-instagram-logo"></span>
                            </Link>
                        </li>
                        <li>
                            <Link href="https://www.youtube.com/">
                                <span className="icon-youtube"></span>
                            </Link>
                        </li>
                    </ul>
                </div>

                <div className="banner-style2__top-text">
                    <p>Hiring Hub was established<br/> in 2014. <Link href="#"><span
                                className="icon-arrow-angle-pointing-to-right"></span></Link></p>
                </div>

                <div className="container">
                    <div className="banner-style2__contant">
                        <div className="sub-title">
                            <h3>Finding Solutions to</h3>
                        </div>
                        <div className="big-title">
                            Staffing
                        </div>
                        <div className="title">
                            <h3>Challenges...</h3>
                        </div>
                        <div className="text">
                            <p>Beguiled and demoralized by the charms of pleasure moment<br/>
                                can not foresee the pain and trouble.</p>
                        </div>
                        <div className="btn-box">
                            <Link className="btn-one" href="/about"><span className="txt">Learn More</span></Link>
                        </div>
                    </div>
                    <div className="banner-style2__img">
                        <div className="banner-style2__shape2">
                            <img src="assets/images/shapes/banner-style2-shape2.png" alt="shape"/>
                        </div>
                        <img src="assets/images/banner/banner-style2-img1.png" alt="image"/>
                    </div>
                </div>
            </section>

        </>
    )
}
