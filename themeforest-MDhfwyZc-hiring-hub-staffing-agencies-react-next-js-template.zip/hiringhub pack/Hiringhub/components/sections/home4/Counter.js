'use client'
import React from 'react'
import CounterUp from "@/components/elements/CounterUp"

export default function Counter() {
    return (
        <> 

            <section className="fact-counter-style1">
                <div className="container">
                    <div className="row">


                        <div className="col-xl-3 col-lg-3 col-md-6">
                            <div className="fact-counter-style1__single">
                                <div className="fact-counter-box">
                                    <div className="circle-box"></div>
                                    <div className="counter-box">
                                        <h2>
                                            <span className="odometer"><CounterUp end={24} /></span>
                                            <span className="k">k</span>
                                        </h2>
                                    </div>
                                    <p>Employees hired in<br/>last year</p>
                                </div>
                            </div>
                        </div>
                        
                        <div className="col-xl-3 col-lg-3 col-md-6">
                            <div className="fact-counter-style1__single">
                                <div className="fact-counter-box">
                                    <div className="circle-box"></div>
                                    <div className="counter-box">
                                        <h2>
                                            <span className="odometer"><CounterUp end={839} /></span>
                                        </h2>
                                    </div>
                                    <p>Employers formed in<br/>last year</p>
                                </div>
                            </div>
                        </div>
                        
                        <div className="col-xl-3 col-lg-3 col-md-6">
                            <div className="fact-counter-style1__single">
                                <div className="fact-counter-box">
                                    <div className="circle-box"></div>
                                    <div className="counter-box">
                                        <h2>
                                            <span className="odometer"><CounterUp end={36} /></span>
                                            <span className="k">+</span>
                                        </h2>
                                    </div>
                                    <p>Countries Served by<br/>our team</p>
                                </div>
                            </div>
                        </div>
                        
                        <div className="col-xl-3 col-lg-3 col-md-6">
                            <div className="fact-counter-style1__single fact-counter-style1__single--11">
                                <div className="fact-counter-box">
                                    <div className="circle-box"></div>
                                    <div className="counter-box">
                                        <h2>
                                            <span className="odometer"><CounterUp end={99} /></span>
                                            <span className="k">%</span>
                                        </h2>
                                    </div>
                                    <p>Client Successful<br/>Rate</p>
                                </div>
                            </div>
                        </div>

                    </div>
                </div>
            </section>

        </>
    )
}
