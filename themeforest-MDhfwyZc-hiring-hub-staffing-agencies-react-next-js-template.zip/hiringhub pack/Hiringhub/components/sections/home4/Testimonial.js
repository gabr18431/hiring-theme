'use client'
import React from 'react'
import { Autoplay, Navigation, Pagination } from "swiper/modules"
import { Swiper, SwiperSlide } from "swiper/react"
const swiperOptions = {
    modules: [Autoplay, Pagination, Navigation],
    slidesPerView: 1,
    spaceBetween: 30,
    autoplay: {
        delay: 5000,
        disableOnInteraction: false,
    },
    loop: true,

    // Navigation
    navigation: {
        nextEl: '#testimonial-style3__items-nav__next',
        prevEl: '#testimonial-style3__items-nav__prev',
    },

    // Pagination
    pagination: {
        el: '.swiper-pagination',
        clickable: true,
    },

    breakpoints: {
        320: {
            slidesPerView: 1,
            spaceBetween: 30,
        },
        575: {
            slidesPerView: 1,
            spaceBetween: 30,
        },
        767: {
            slidesPerView: 1,
            spaceBetween: 30,
        },
        991: {
            slidesPerView: 1,
            spaceBetween: 30,
        },
        1199: {
            slidesPerView: 1,
            spaceBetween: 30,
        },
        1350: {
            slidesPerView: 1,
            spaceBetween: 30,
        },
    }
}

export default function Testimonial() {
    return (
        <> 

            <section className="testimonial-style3">
                <div className="container">
                    <div className="testimonial-style3__shape">
                        <img src="assets/images/shapes/testmonials-v3-shape1.png" alt="shape"/>
                    </div>

                    <div className="testimonial-style3__inner">
                        <Swiper {...swiperOptions} className="swiper-container thm-swiper__slider">
                            <SwiperSlide>
                                <div className="swiper-slide">
                                    <div className="testimonial-style3__single">
                                        <div className="testimonial-style3__single-content-box text-center">
                                            <div className="rating-box">
                                                <ul>
                                                    <li>
                                                        <span className="icon-rate-star-button"></span>
                                                    </li>
                                                    <li>
                                                        <span className="icon-rate-star-button"></span>
                                                    </li>
                                                    <li>
                                                        <span className="icon-rate-star-button"></span>
                                                    </li>
                                                    <li>
                                                        <span className="icon-rate-star-button"></span>
                                                    </li>
                                                    <li>
                                                        <span className="icon-rate-star-button"></span>
                                                    </li>
                                                </ul>
                                            </div>
                                            <div className="title">
                                                <h3>“Career-Altering Guidance”</h3>
                                            </div>
                                            <div className="text">
                                                <p>
                                                    Hiring Hub is very accurate when comes to helping you find a job and if
                                                    that job finishes,<br/>They help you to find an another job placement!.
                                                </p>
                                            </div>
                                        </div>
                                        <div className="customer-info">
                                            <div className="img-box">
                                                <img src="assets/images/testimonial/testimonial-v3-1.jpg" alt="image"/>
                                            </div>
                                            <div className="title-box">
                                                <h3>Nathan Felix</h3>
                                                <span>Manager, Cypertech pvt ltd</span>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </SwiperSlide>
                            <SwiperSlide>
                                <div className="swiper-slide">
                                    <div className="testimonial-style3__single">
                                        <div className="testimonial-style3__single-content-box text-center">
                                            <div className="rating-box">
                                                <ul>
                                                    <li>
                                                        <span className="icon-rate-star-button"></span>
                                                    </li>
                                                    <li>
                                                        <span className="icon-rate-star-button"></span>
                                                    </li>
                                                    <li>
                                                        <span className="icon-rate-star-button"></span>
                                                    </li>
                                                    <li>
                                                        <span className="icon-rate-star-button"></span>
                                                    </li>
                                                    <li>
                                                        <span className="icon-rate-star-button"></span>
                                                    </li>
                                                </ul>
                                            </div>
                                            <div className="title">
                                                <h3>“Career-Altering Guidance”</h3>
                                            </div>
                                            <div className="text">
                                                <p>
                                                    Hiring Hub is very accurate when comes to helping you find a job and if
                                                    that job finishes,<br/>They help you to find an another job placement!.
                                                </p>
                                            </div>
                                        </div>
                                        <div className="customer-info">
                                            <div className="img-box">
                                                <img src="assets/images/testimonial/testimonial-v3-2.jpg" alt="image"/>
                                            </div>
                                            <div className="title-box">
                                                <h3>Nathan Felix</h3>
                                                <span>Manager, Cypertech pvt ltd</span>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </SwiperSlide>
                            <SwiperSlide>
                                <div className="swiper-slide">
                                    <div className="testimonial-style3__single">
                                        <div className="testimonial-style3__single-content-box text-center">
                                            <div className="rating-box">
                                                <ul>
                                                    <li>
                                                        <span className="icon-rate-star-button"></span>
                                                    </li>
                                                    <li>
                                                        <span className="icon-rate-star-button"></span>
                                                    </li>
                                                    <li>
                                                        <span className="icon-rate-star-button"></span>
                                                    </li>
                                                    <li>
                                                        <span className="icon-rate-star-button"></span>
                                                    </li>
                                                    <li>
                                                        <span className="icon-rate-star-button"></span>
                                                    </li>
                                                </ul>
                                            </div>
                                            <div className="title">
                                                <h3>“Career-Altering Guidance”</h3>
                                            </div>
                                            <div className="text">
                                                <p>
                                                    Hiring Hub is very accurate when comes to helping you find a job and if
                                                    that job finishes,<br/>They help you to find an another job placement!.
                                                </p>
                                            </div>
                                        </div>
                                        <div className="customer-info">
                                            <div className="img-box">
                                                <img src="assets/images/testimonial/testimonial-v3-1.jpg" alt="image"/>
                                            </div>
                                            <div className="title-box">
                                                <h3>Nathan Felix</h3>
                                                <span>Manager, Cypertech pvt ltd</span>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </SwiperSlide>
                            <SwiperSlide>
                                <div className="swiper-slide">
                                    <div className="testimonial-style3__single">
                                        <div className="testimonial-style3__single-content-box text-center">
                                            <div className="rating-box">
                                                <ul>
                                                    <li>
                                                        <span className="icon-rate-star-button"></span>
                                                    </li>
                                                    <li>
                                                        <span className="icon-rate-star-button"></span>
                                                    </li>
                                                    <li>
                                                        <span className="icon-rate-star-button"></span>
                                                    </li>
                                                    <li>
                                                        <span className="icon-rate-star-button"></span>
                                                    </li>
                                                    <li>
                                                        <span className="icon-rate-star-button"></span>
                                                    </li>
                                                </ul>
                                            </div>
                                            <div className="title">
                                                <h3>“Career-Altering Guidance”</h3>
                                            </div>
                                            <div className="text">
                                                <p>
                                                    Hiring Hub is very accurate when comes to helping you find a job and if
                                                    that job finishes,<br/>They help you to find an another job placement!.
                                                </p>
                                            </div>
                                        </div>
                                        <div className="customer-info">
                                            <div className="img-box">
                                                <img src="assets/images/testimonial/testimonial-v3-2.jpg" alt="image"/>
                                            </div>
                                            <div className="title-box">
                                                <h3>Nathan Felix</h3>
                                                <span>Manager, Cypertech pvt ltd</span>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </SwiperSlide>
                        </Swiper>

                        <div className="testimonial-style3__items-nav">
                            <div className="swiper-button-prev" id="testimonial-style3__items-nav__prev">
                                <i className="icon-right-arrow-1 left"></i> Prev
                            </div>
                            <div className="swiper-button-next" id="testimonial-style3__items-nav__next">
                                Next <i className="icon-right-arrow-1 right"></i>
                            </div>
                        </div>

                    </div>
                </div>
            </section>

        </>
    )
}
