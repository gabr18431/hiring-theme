'use client'
import React from 'react'
import Link from "next/link"
import { Autoplay, Navigation, Pagination } from "swiper/modules"
import { Swiper, SwiperSlide } from "swiper/react"
const swiperOptions = {
    modules: [Autoplay, Pagination, Navigation],
    slidesPerView: 1,
    spaceBetween: 30,
    autoplay: {
        delay: 5000,
        disableOnInteraction: false,
    },
    loop: true,

    // Navigation
    navigation: {
        nextEl: '.swiper-button-prev',
        prevEl: '.swiper-button-next',
    },

    breakpoints: {
        320: {
            slidesPerView: 1,
            spaceBetween: 30,
        },
        575: {
            slidesPerView: 1,
            spaceBetween: 30,
        },
        767: {
            slidesPerView: 2,
            spaceBetween: 30,
        },
        991: {
            slidesPerView: 2,
            spaceBetween: 30,
        },
        1199: {
            slidesPerView: 3,
            spaceBetween: 30,
        },
        1600: {
            slidesPerView: 3,
            spaceBetween: 30,
        },
    }
}

export default function Service_Two() {
    return (
        <> 

            <section className="service-style3">
                <div className="container">
                    <div className="sec-title">
                        <div className="sub-title">
                            <h4>Service Areas</h4>
                        </div>
                        <h2>Our Specialized Industries</h2>
                    </div>
                    <div className='service-three-content'>
                        <div className="row">
                            <div className="col-xl-12">
                                <Swiper {...swiperOptions} className="swiper-container service-style3-carousel">
                                    <SwiperSlide>
                                        <div className="service-style3__single text-center">
                                            <div className="service-style3__single-shape1">
                                                <img src="assets/images/shapes/service-v3__shape1.png" alt="shape"/>
                                            </div>
                                            <div className="service-style3__single-shape2">
                                                <img src="assets/images/shapes/service-v3__shape2.png" alt="shape"/>
                                            </div>
                                            <div className="category-box">
                                                <p>Industry 01</p>
                                            </div>
                                            <div className="title-box">
                                                <h3><Link href="/employers-overview">Accounting & Finance</Link></h3>
                                            </div>
                                            <div className="border-line"></div>
                                            <div className="text">
                                                <p>Cases are perfectly simple and easy to<br/>distinguish in a free hour.</p>
                                            </div>
                                            <div className="btn-box">
                                                <Link href="/employers-overview">
                                                    Explore More
                                                    <span className="icon-arrow-angle-pointing-to-right"></span>
                                                    <span className="icon-right-arrow-1 arrow-hover"></span>
                                                </Link>
                                            </div>
                                            <div className="icon-box">
                                                <img src="assets/images/icon/services/service-icon-3-1.png" alt="icon"/>
                                            </div>
                                        </div>
                                    </SwiperSlide>
                                    <SwiperSlide>
                                        <div className="service-style3__single text-center">
                                            <div className="service-style3__single-shape1">
                                                <img src="assets/images/shapes/service-v3__shape1.png" alt="shape"/>
                                            </div>
                                            <div className="service-style3__single-shape2">
                                                <img src="assets/images/shapes/service-v3__shape2.png" alt="shape"/>
                                            </div>
                                            <div className="category-box">
                                                <p>Industry 02</p>
                                            </div>
                                            <div className="title-box">
                                                <h3><Link href="/employers-overview">Digital Marketing</Link></h3>
                                            </div>
                                            <div className="border-line"></div>
                                            <div className="text">
                                                <p>Cases are perfectly simple and easy to<br/>distinguish in a free hour.</p>
                                            </div>
                                            <div className="btn-box">
                                                <Link href="/employers-overview">
                                                    Explore More
                                                    <span className="icon-arrow-angle-pointing-to-right"></span>
                                                    <span className="icon-right-arrow-1 arrow-hover"></span>
                                                </Link>
                                            </div>
                                            <div className="icon-box">
                                                <img src="assets/images/icon/services/service-icon-3-2.png" alt="icon"/>
                                            </div>
                                        </div>
                                    </SwiperSlide>
                                    <SwiperSlide>
                                        <div className="service-style3__single text-center">
                                            <div className="service-style3__single-shape1">
                                                <img src="assets/images/shapes/service-v3__shape1.png" alt="shape"/>
                                            </div>
                                            <div className="service-style3__single-shape2">
                                                <img src="assets/images/shapes/service-v3__shape2.png" alt="shape"/>
                                            </div>
                                            <div className="category-box">
                                                <p>Industry 03</p>
                                            </div>
                                            <div className="title-box">
                                                <h3><Link href="/employers-overview">Heathcare & Medical</Link></h3>
                                            </div>
                                            <div className="border-line"></div>
                                            <div className="text">
                                                <p>Cases are perfectly simple and easy to<br/>distinguish in a free hour.</p>
                                            </div>
                                            <div className="btn-box">
                                                <Link href="/employers-overview">
                                                    Explore More
                                                    <span className="icon-arrow-angle-pointing-to-right"></span>
                                                    <span className="icon-right-arrow-1 arrow-hover"></span>
                                                </Link>
                                            </div>
                                            <div className="icon-box">
                                                <img src="assets/images/icon/services/service-icon-3-3.png" alt="icon"/>
                                            </div>
                                        </div>
                                    </SwiperSlide>
                                    <SwiperSlide>
                                        <div className="service-style3__single text-center">
                                            <div className="service-style3__single-shape1">
                                                <img src="assets/images/shapes/service-v3__shape1.png" alt="shape"/>
                                            </div>
                                            <div className="service-style3__single-shape2">
                                                <img src="assets/images/shapes/service-v3__shape2.png" alt="shape"/>
                                            </div>
                                            <div className="category-box">
                                                <p>Industry 01</p>
                                            </div>
                                            <div className="title-box">
                                                <h3><Link href="/employers-overview">Accounting & Finance</Link></h3>
                                            </div>
                                            <div className="border-line"></div>
                                            <div className="text">
                                                <p>Cases are perfectly simple and easy to<br/>distinguish in a free hour.</p>
                                            </div>
                                            <div className="btn-box">
                                                <Link href="/employers-overview">
                                                    Explore More
                                                    <span className="icon-arrow-angle-pointing-to-right"></span>
                                                    <span className="icon-right-arrow-1 arrow-hover"></span>
                                                </Link>
                                            </div>
                                            <div className="icon-box">
                                                <img src="assets/images/icon/services/service-icon-3-1.png" alt="icon"/>
                                            </div>
                                        </div>
                                    </SwiperSlide>
                                    <SwiperSlide>
                                        <div className="service-style3__single text-center">
                                            <div className="service-style3__single-shape1">
                                                <img src="assets/images/shapes/service-v3__shape1.png" alt="shape"/>
                                            </div>
                                            <div className="service-style3__single-shape2">
                                                <img src="assets/images/shapes/service-v3__shape2.png" alt="shape"/>
                                            </div>
                                            <div className="category-box">
                                                <p>Industry 02</p>
                                            </div>
                                            <div className="title-box">
                                                <h3><Link href="/employers-overview">Digital Marketing</Link></h3>
                                            </div>
                                            <div className="border-line"></div>
                                            <div className="text">
                                                <p>Cases are perfectly simple and easy to<br/>distinguish in a free hour.</p>
                                            </div>
                                            <div className="btn-box">
                                                <Link href="/employers-overview">
                                                    Explore More
                                                    <span className="icon-arrow-angle-pointing-to-right"></span>
                                                    <span className="icon-right-arrow-1 arrow-hover"></span>
                                                </Link>
                                            </div>
                                            <div className="icon-box">
                                                <img src="assets/images/icon/services/service-icon-3-2.png" alt="icon"/>
                                            </div>
                                        </div>
                                    </SwiperSlide>
                                    <SwiperSlide>
                                        <div className="service-style3__single text-center">
                                            <div className="service-style3__single-shape1">
                                                <img src="assets/images/shapes/service-v3__shape1.png" alt="shape"/>
                                            </div>
                                            <div className="service-style3__single-shape2">
                                                <img src="assets/images/shapes/service-v3__shape2.png" alt="shape"/>
                                            </div>
                                            <div className="category-box">
                                                <p>Industry 03</p>
                                            </div>
                                            <div className="title-box">
                                                <h3><Link href="/employers-overview">Heathcare & Medical</Link></h3>
                                            </div>
                                            <div className="border-line"></div>
                                            <div className="text">
                                                <p>Cases are perfectly simple and easy to<br/>distinguish in a free hour.</p>
                                            </div>
                                            <div className="btn-box">
                                                <Link href="/employers-overview">
                                                    Explore More
                                                    <span className="icon-arrow-angle-pointing-to-right"></span>
                                                    <span className="icon-right-arrow-1 arrow-hover"></span>
                                                </Link>
                                            </div>
                                            <div className="icon-box">
                                                <img src="assets/images/icon/services/service-icon-3-3.png" alt="icon"/>
                                            </div>
                                        </div>
                                    </SwiperSlide>
                                </Swiper>

                                <div className="swiper-nav-style-one">
                                    <button className="swiper-button-prev">
                                        <span className="left icon-left-arrow-angle-big-gross-symbol"></span>
                                    </button>
                                    <button className="swiper-button-next">
                                        <span className="right icon-arrow-angle-pointing-to-right"></span>
                                    </button>
                                </div>
                            </div>

                        </div>
                    </div>
                </div>
            </section>

        </>
    )
}
