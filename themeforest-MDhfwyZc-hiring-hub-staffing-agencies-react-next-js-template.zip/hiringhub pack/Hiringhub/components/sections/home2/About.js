'use client'
import React from 'react'
import { useState } from "react"
import Link from "next/link"

export default function About() {
    const [activeIndex, setActiveIndex] = useState(1)
        const handleOnClick = (index) => {
            setActiveIndex(index)
        }
    return (
        <> 

            <section className="about-style2">
                <div className="container">
                    <div className="about-style2__tab">
                        <div className="row">
                            <div className="col-xl-5">
                                <div className="about-style2__content">
                                    <div className="sec-title withtext">
                                        <div className="sub-title">
                                            <h4>Principles & Purpose</h4>
                                        </div>
                                        <h2>Delivering High<br/>Impact Recruitment<br/>Solutions</h2>
                                        <div className="text">
                                            <p>
                                                Our being able to do what we like best every pleasure that<br/>but in certain
                                                circumstances.
                                            </p>
                                        </div>
                                    </div>

                                    <div className="about-style2__tab-btn">
                                        <ul className="tabs-button-box clearfix">
                                            <li onClick={() => handleOnClick(1)} className={activeIndex === 1 ? "tab-btn-item active-btn" : "tab-btn-item"}>
                                                <span>
                                                    Philosophy
                                                    <i className="icon-diagonal-arrow arrow-hover"></i>
                                                </span>
                                            </li>
                                            <li onClick={() => handleOnClick(2)} className={activeIndex === 2 ? "tab-btn-item active-btn" : "tab-btn-item"}>
                                                <span>
                                                    Our Milestones
                                                    <i className="icon-diagonal-arrow arrow-hover"></i>
                                                </span>
                                            </li>
                                            <li onClick={() => handleOnClick(3)} className={activeIndex === 3 ? "tab-btn-item active-btn" : "tab-btn-item"}>
                                                <span>
                                                    Our Statements
                                                    <i className="icon-diagonal-arrow arrow-hover"></i>
                                                </span>
                                            </li>
                                        </ul>
                                    </div>
                                    <div className="btn-box2">
                                        <Link href="/about">
                                            More about our Agency
                                            <i className="icon-arrow-angle-pointing-to-right"></i>
                                        </Link>
                                    </div>
                                </div>
                            </div>

                            <div className="col-xl-7">
                                <div className="tabs-content-box">
                                    
                                    <div className={activeIndex === 1 ? "tab-content-box-item active-tab" : "tab-content-box-item"}>

                                        <div className="about-style2-tab-content-box-item">
                                            <div className="about-style2__img clearfix">
                                                <div className="about-style2__shape1">
                                                    <img src="assets/images/shapes/about-v2-shape1.png" alt="shape"/>
                                                </div>
                                                <div className="about-style2__shape2">
                                                    <img src="assets/images/shapes/about-v2-shape2.png" alt="shape"/>
                                                </div>
                                                <div className="icon-box">
                                                    <img src="assets/images/icon/about/about-v2-icon-1.png" alt="icon"/>
                                                </div>
                                                <div className="img-box">
                                                    <img src="assets/images/about/about-v2-1.jpg" alt="image"/>
                                                </div>
                                                <div className="content-box">
                                                    <h3>Philosophy</h3>
                                                    <div className="line"></div>
                                                    <p>
                                                        Best every pleasure to welcomed<br/>every pain avoided but in
                                                        certain<br/>circumstances have be repudiate <br/>enjoy pleasure who
                                                        avoids a
                                                        pain<br/>that produces no resultant.
                                                    </p>
                                                    <div className="btn-box">
                                                        <Link href="/about">
                                                            Explore More
                                                            <i className="icon-arrow-angle-pointing-to-right"></i>
                                                        </Link>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>

                                    </div>
                                    
                                    <div className={activeIndex === 2 ? "tab-content-box-item active-tab" : "tab-content-box-item"}>
                                        <div className="about-style2-tab-content-box-item">
                                            <div className="about-style2__img clearfix">
                                                <div className="about-style2__shape1">
                                                    <img src="assets/images/shapes/about-v2-shape1.png" alt="shape"/>
                                                </div>
                                                <div className="about-style2__shape2">
                                                    <img src="assets/images/shapes/about-v2-shape2.png" alt="shape"/>
                                                </div>
                                                <div className="icon-box">
                                                    <img src="assets/images/icon/about/about-v2-icon-1.png" alt="icon"/>
                                                </div>
                                                <div className="img-box">
                                                    <img src="assets/images/about/about-v2-1.jpg" alt="image"/>
                                                </div>
                                                <div className="content-box">
                                                    <h3>Our Milestones</h3>
                                                    <div className="line"></div>
                                                    <p>
                                                        Best every pleasure to welcomed<br/>every pain avoided but in
                                                        certain<br/>circumstances have be repudiate <br/>enjoy pleasure who
                                                        avoids a
                                                        pain<br/>that produces no resultant.
                                                    </p>
                                                    <div className="btn-box">
                                                        <Link href="/about">
                                                            Explore More
                                                            <i className="icon-arrow-angle-pointing-to-right"></i>
                                                        </Link>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    
                                    <div className={activeIndex === 3 ? "tab-content-box-item active-tab" : "tab-content-box-item"}>
                                        <div className="about-style2-tab-content-box-item">
                                            <div className="about-style2__img clearfix">
                                                <div className="about-style2__shape1">
                                                    <img src="assets/images/shapes/about-v2-shape1.png" alt="shape"/>
                                                </div>
                                                <div className="about-style2__shape2">
                                                    <img src="assets/images/shapes/about-v2-shape2.png" alt="shape"/>
                                                </div>
                                                <div className="icon-box">
                                                    <img src="assets/images/icon/about/about-v2-icon-1.png" alt="icon"/>
                                                </div>
                                                <div className="img-box">
                                                    <img src="assets/images/about/about-v2-1.jpg" alt="image"/>
                                                </div>
                                                <div className="content-box">
                                                    <h3>Our Statements</h3>
                                                    <div className="line"></div>
                                                    <p>
                                                        Best every pleasure to welcomed<br/>every pain avoided but in
                                                        certain<br/>circumstances have be repudiate <br/>enjoy pleasure who
                                                        avoids a
                                                        pain<br/>that produces no resultant.
                                                    </p>
                                                    <div className="btn-box">
                                                        <Link href="/about">
                                                            Explore More
                                                            <i className="icon-arrow-angle-pointing-to-right"></i>
                                                        </Link>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                </div>

                            </div>
                        </div>

                    </div>
                </div>
            </section>

        </>
    )
}
