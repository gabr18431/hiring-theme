'use client'
import React from 'react'
import Link from "next/link"
import { Autoplay, Navigation, Pagination } from "swiper/modules"
import { Swiper, SwiperSlide } from "swiper/react"
const swiperOptions = {
    modules: [Autoplay, Pagination, Navigation],
    slidesPerView: 1,
    spaceBetween: 30,
    autoplay: {
        delay: 5000,
        disableOnInteraction: false,
    },
    loop: true,

    breakpoints: {
        320: {
            slidesPerView: 1,
            spaceBetween: 30,
        },
        575: {
            slidesPerView: 1,
            spaceBetween: 30,
        },
        767: {
            slidesPerView: 2,
            spaceBetween: 30,
        },
        991: {
            slidesPerView: 3,
            spaceBetween: 30,
        },
        1199: {
            slidesPerView: 4,
            spaceBetween: 30,
        },
        1600: {
            slidesPerView: 5,
            spaceBetween: 30,
        },
    }
}

export default function Case() {
    return (
        <> 

            <section className="case-style1">
                <div className="container">
                    <div className="sec-title withtext text-center">
                        <div className="sub-title">
                            <h4>Case Studies</h4>
                        </div>
                        <h2>Staffing Solutions in Action</h2>
                        <div className="text">
                            <p>
                                Long established fact that a reader will be distracted by the<br/>readable content of a page.
                            </p>
                        </div>
                    </div>
                    <div className="row">
                        <div className="col-xl-12">
                        <Swiper {...swiperOptions} className="swiper-container case-style1-carousel">
                            <SwiperSlide>
                                <div className="case-style1__single">
                                    <div className="img-box">
                                        <div className="inner">
                                            <img src="assets/images/resources/case-v1-1.jpg" alt="image"/>
                                            <div className="overlay-icon">
                                                <Link className="lightbox-image" data-fancybox="gallery"
                                                    href="assets/images/resources/case-v1-1.jpg">
                                                    <i className="icon-zoom-in"></i>
                                                </Link>
                                            </div>
                                        </div>
                                        <div className="overlay-content">
                                            <div className="category-box">
                                                <p>Management</p>
                                            </div>
                                            <div className="title-box">
                                                <h3><Link href="/case-single">Placements Driving Growth</Link></h3>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </SwiperSlide>
                            <SwiperSlide>
                                <div className="case-style1__single">
                                    <div className="img-box">
                                        <div className="inner">
                                            <img src="assets/images/resources/case-v1-2.jpg" alt="image"/>
                                            <div className="overlay-icon">
                                                <Link className="lightbox-image" data-fancybox="gallery"
                                                    href="assets/images/resources/case-v1-2.jpg">
                                                    <i className="icon-zoom-in"></i>
                                                </Link>
                                            </div>
                                        </div>
                                        <div className="overlay-content">
                                            <div className="category-box">
                                                <p>Industry Focus</p>
                                            </div>
                                            <div className="title-box">
                                                <h3><Link href="/case-single">Recuirtment & Selection Procedure</Link></h3>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </SwiperSlide>
                            <SwiperSlide>
                                <div className="case-style1__single">
                                    <div className="img-box">
                                        <div className="inner">
                                            <img src="assets/images/resources/case-v1-3.jpg" alt="image"/>
                                            <div className="overlay-icon">
                                                <Link className="lightbox-image" data-fancybox="gallery"
                                                    href="assets/images/resources/case-v1-3.jpg">
                                                    <i className="icon-zoom-in"></i>
                                                </Link>
                                            </div>
                                        </div>
                                        <div className="overlay-content">
                                            <div className="category-box">
                                                <p>Recruitment</p>
                                            </div>
                                            <div className="title-box">
                                                <h3><Link href="/case-single">Issues Faced by the Company</Link></h3>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </SwiperSlide>
                            <SwiperSlide>
                                <div className="case-style1__single">
                                    <div className="img-box">
                                        <div className="inner">
                                            <img src="assets/images/resources/case-v1-4.jpg" alt="image"/>
                                            <div className="overlay-icon">
                                                <Link className="lightbox-image" data-fancybox="gallery"
                                                    href="assets/images/resources/case-v1-4.jpg">
                                                    <i className="icon-zoom-in"></i>
                                                </Link>
                                            </div>
                                        </div>
                                        <div className="overlay-content">
                                            <div className="category-box">
                                                <p>Consulting</p>
                                            </div>
                                            <div className="title-box">
                                                <h3><Link href="/case-single">Recuirtment & Selection Procedure</Link></h3>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </SwiperSlide>
                            <SwiperSlide>
                                <div className="case-style1__single">
                                    <div className="img-box">
                                        <div className="inner">
                                            <img src="assets/images/resources/case-v1-5.jpg" alt="image"/>
                                            <div className="overlay-icon">
                                                <Link className="lightbox-image" data-fancybox="gallery"
                                                    href="assets/images/resources/case-v1-5.jpg">
                                                    <i className="icon-zoom-in"></i>
                                                </Link>
                                            </div>
                                        </div>
                                        <div className="overlay-content">
                                            <div className="category-box">
                                                <p>technology</p>
                                            </div>
                                            <div className="title-box">
                                                <h3><Link href="/case-single">Placements Driving Growth</Link></h3>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </SwiperSlide>
                        </Swiper>
                        </div>
                    </div>
                </div>
            </section>

        </>
    )
}
