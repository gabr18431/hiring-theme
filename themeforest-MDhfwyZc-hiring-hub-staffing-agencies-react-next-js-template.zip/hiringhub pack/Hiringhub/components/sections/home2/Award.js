'use client'
import React from 'react'
import Link from "next/link"

export default function Award() {
    return (
        <> 

            <section className="award-style1">
                <div className="container">
                    <div className="sec-title withtext text-center">
                        <div className="sub-title">
                            <h4>Awards & Achivements</h4>
                        </div>
                        <h2>Our Impressive Milestones</h2>
                        <div className="text">
                            <p>Long established fact that a reader will be distracted by the.</p>
                        </div>
                    </div>
                    <div className="row">
                        
                        <div className="col-xl-6 col-lg-6 col-md-6">
                            <div className="award-style1__single">
                                <div className="award-style1__single-shape1">
                                    <img src="assets/images/shapes/award-style1__shape1.png" alt="shape"/>
                                </div>
                                <div className="row">
                                    <div className="col-xl-6">
                                        <div className="award-style1__single-content">
                                            <div className="icon">
                                                <img src="assets/images/icon/award/award-v1-icon-1.png" alt="icon"/>
                                            </div>
                                            <div className="category-box">
                                                <p>mca’s awards</p>
                                            </div>
                                            <div className="title">
                                                <h3><Link href="/about">Best Personnel Service<br/>Provider.</Link></h3>
                                            </div>
                                            <div className="year">
                                                <h4>2025</h4>
                                            </div>
                                        </div>
                                    </div>
                                    <div className="col-xl-6">
                                        <div className="award-style1__single-img">
                                            <img src="assets/images/resources/award-v1-img1.jpg" alt="image"/>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        
                        <div className="col-xl-6 col-lg-6 col-md-6">
                            <div className="award-style1__single">
                                <div className="award-style1__single-shape1">
                                    <img src="assets/images/shapes/award-style1__shape1.png" alt="shape"/>
                                </div>
                                <div className="row">
                                    <div className="col-xl-6">
                                        <div className="award-style1__single-content">
                                            <div className="icon">
                                                <img src="assets/images/icon/award/award-v1-icon-1.png" alt="icon"/>
                                            </div>
                                            <div className="category-box">
                                                <p>Arup awards</p>
                                            </div>
                                            <div className="title">
                                                <h3><Link href="/about">Best Staffing Firm to<br/>Work For.</Link></h3>
                                            </div>
                                            <div className="year">
                                                <h4>2022</h4>
                                            </div>
                                        </div>
                                    </div>
                                    <div className="col-xl-6">
                                        <div className="award-style1__single-img">
                                            <img src="assets/images/resources/award-v1-img2.jpg" alt="image"/>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                    </div>
                </div>
            </section>

        </>
    )
}
