'use client'
import React from 'react'
import Link from "next/link"
import { Autoplay, Navigation, Pagination } from "swiper/modules"
import { Swiper, SwiperSlide } from "swiper/react"
const swiperOptions = {
    modules: [Autoplay, Pagination, Navigation],
    "effect": "fade",
    "speed": 2000,
    slidesPerView: 1,
    spaceBetween: 30,
    autoplay: {
        delay: 8000,
    },
    loop: true,

    // Navigation
    navigation: {
        nextEl: '.swiper-button-prev',
        prevEl: '.swiper-button-next',
    },

    // Pagination
    pagination: {
        el: '.swiper-pagination',
        clickable: true,
    },

    breakpoints: {
        320: {
            slidesPerView: 1,
            spaceBetween: 30,
        },
        575: {
            slidesPerView: 1,
            spaceBetween: 30,
        },
        767: {
            slidesPerView: 1,
            spaceBetween: 30,
        },
        991: {
            slidesPerView: 1,
            spaceBetween: 30,
        },
        1199: {
            slidesPerView: 1,
            spaceBetween: 30,
        },
        1350: {
            slidesPerView: 1,
            spaceBetween: 30,
        },
    }
}

export default function Banner() {
    return (
        <> 

        <section className="main-slider main-slider-style2">
            <div className='main-slider-style2__inner'>
                <div className='main-slider-style2__inner-container'>
                    <Swiper {...swiperOptions} className="swiper-container thm-swiper__slider">
                        <SwiperSlide className='swiper-slide'>
                            <div className="container">
                                <div className="row">
                                    <div className="col-xl-12">
                                        <div className="main-slider-content">
                                            <div className="main-slider-content__inner">
                                                <div className="sec-title">
                                                    <div className="sub-title">
                                                        <h4>Solutions we provide</h4>
                                                    </div>
                                                </div>
                                                <div className="big-title">
                                                    <h2>
                                                        Looking for the<br/>best employees? We<br/>have them.
                                                    </h2>
                                                </div>
                                                <div className="text">
                                                    <p>Trouble that are bound to ensue and equal that shrinking.</p>
                                                </div>
                                                <div className="btn-box">
                                                    <Link className="btn-one" href="/about">
                                                        <span className="txt">
                                                            Learn More
                                                        </span>
                                                    </Link>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div className="main-slider-style2__img-box">
                                <ul className="clearfix">
                                    <li>
                                        <div className="single-img-box">
                                            <img src="assets/images/slides/slide-v2-1.jpg" alt="image"/>
                                        </div>
                                    </li>
                                    <li className="last-child">
                                        <div className="single-img-box">
                                            <img src="assets/images/slides/slide-v2-2.jpg" alt="image"/>
                                        </div>
                                    </li>
                                </ul>
                            </div>
                        </SwiperSlide>
                        <SwiperSlide className='swiper-slide'>
                            <div className="container">
                                <div className="row">
                                    <div className="col-xl-12">
                                        <div className="main-slider-content">
                                            <div className="main-slider-content__inner">
                                                <div className="sec-title">
                                                    <div className="sub-title">
                                                        <h4>Solutions we provide</h4>
                                                    </div>
                                                </div>
                                                <div className="big-title">
                                                    <h2>
                                                        Find the right<br/> employer for you<br/> to thrive.
                                                    </h2>
                                                </div>
                                                <div className="text">
                                                    <p>Some advantage from it? But who has any right to find.</p>
                                                </div>
                                                <div className="btn-box">
                                                    <Link className="btn-one" href="/about">
                                                        <span className="txt">
                                                            Learn More
                                                        </span>
                                                    </Link>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div className="main-slider-style2__img-box">
                                <ul className="clearfix">
                                    <li>
                                        <div className="single-img-box">
                                            <img src="assets/images/slides/slide-v2-3.jpg" alt="image"/>
                                        </div>
                                    </li>
                                    <li className="last-child">
                                        <div className="single-img-box">
                                            <img src="assets/images/slides/slide-v2-4.jpg" alt="image"/>
                                        </div>
                                    </li>
                                </ul>
                            </div>
                        </SwiperSlide>
                        <SwiperSlide className='swiper-slide'>
                            <div className="container">
                                <div className="row">
                                    <div className="col-xl-12">
                                        <div className="main-slider-content">
                                            <div className="main-slider-content__inner">
                                                <div className="sec-title">
                                                    <div className="sub-title">
                                                        <h4>Solutions we provide</h4>
                                                    </div>
                                                </div>
                                                <div className="big-title">
                                                    <h2>
                                                        End the search<br/> for a new job, We<br/> are hiring.
                                                    </h2>
                                                </div>
                                                <div className="text">
                                                    <p>Some advantage from it? But who has any right to find.</p>
                                                </div>
                                                <div className="btn-box">
                                                    <Link className="btn-one" href="/about">
                                                        <span className="txt">
                                                            Learn More
                                                        </span>
                                                    </Link>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div className="main-slider-style2__img-box">
                                <ul className="clearfix">
                                    <li>
                                        <div className="single-img-box">
                                            <img src="assets/images/slides/slide-v2-5.jpg" alt="image"/>
                                        </div>
                                    </li>
                                    <li className="last-child">
                                        <div className="single-img-box">
                                            <img src="assets/images/slides/slide-v2-6.jpg" alt="image"/>
                                        </div>
                                    </li>
                                </ul>
                            </div>
                        </SwiperSlide>
                        
                        <div className="main-slider-scrooling-content">
                            <div className="container-inner">
                                <div className="container-inner__box">
                                    <div className="inner-title">
                                        <span className="icon-human-resources"></span>
                                        <h5>Immediate Hiring:</h5>
                                    </div>
                                    <div className="content-box">
                                        <ul className="clearfix marquee_mode">
                                            <li data-hover="Get updates">
                                                Business Development Manager, San Fransisco, CA.
                                                <Link href="/contact">
                                                    Explore More
                                                    <span className="icon-arrow-angle-pointing-to-right"></span>
                                                </Link>
                                            </li>
                                            <li data-hover="Get updates">
                                                15205 North Kierland Blvd. Suite 100
                                                <Link href="/contact">
                                                    Explore More
                                                    <span className="icon-arrow-angle-pointing-to-right"></span>
                                                </Link>
                                            </li>

                                        </ul>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div className="swiper-pagination" id="main-slider-pagination"></div>
                        <div className="main-slider__nav">
                            <div className="swiper-button-prev" id="main-slider__swiper-button-next">
                                <i className="icon-left-arrow-angle-big-gross-symbol left"></i>
                            </div>
                            <div className="swiper-button-next" id="main-slider__swiper-button-prev">
                                <i className="icon-arrow-angle-pointing-to-right right"></i>
                            </div>
                        </div>
                    </Swiper>
                </div>
            </div>
        </section>

        </>
    )
}
