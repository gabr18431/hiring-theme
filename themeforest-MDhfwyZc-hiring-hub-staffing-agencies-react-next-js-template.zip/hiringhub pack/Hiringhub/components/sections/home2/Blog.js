'use client'
import React from 'react'
import Link from "next/link"

export default function Blog() {
    return (
        <> 

            <section className="blog-style2">
                <div className="container">
                    <div className="row">

                        <div className="col-xl-4 col-lg-4">
                            <div className="blog-style2__title">
                                <div className="sec-title">
                                    <div className="sub-title">
                                        <h4>News & Updates</h4>
                                    </div>
                                    <h2>Discover the<br/>Latest from our<br/>Blog Post</h2>
                                </div>
                                <div className="border-line"></div>
                                <div className="newsletter-box">
                                    <h3>Newsletter</h3>
                                    <p>Subscribe us to receive news & updates.</p>
                                </div>
                                <div className="blog-style2__form">
                                    <form action="/" method="post">
                                        <div className="check-employer-box1">
                                            <ul>
                                                <li>
                                                    <input type="radio" id="employer-yes" name="employer"/>
                                                    <label for="employer-yes" data-amount="25">
                                                        <span></span>
                                                        i’m an Employer
                                                    </label>
                                                </li>
                                                <li>
                                                    <input type="radio" id="employer-no" name="employer"/>
                                                    <label for="employer-no" data-amount="50">
                                                        <span></span>
                                                        i’m an employee
                                                    </label>
                                                </li>
                                            </ul>
                                        </div>
                                        <div className="form-group">
                                            <input type="email" name="email" placeholder="Enter your email..." required=""/>
                                        </div>
                                        <div className="checked-box1">
                                            <input type="checkbox" name="skipper1" id="skipper"/>
                                            <label for="skipper">
                                                <span></span>I agree to the Privacy Policy.
                                            </label>
                                        </div>
                                        <div className="btn-box">
                                            <button className="submit btn-one">
                                                <span className="txt">Subscribe Us</span>
                                            </button>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>

                        <div className="col-xl-8 col-lg-8">
                            <ul className="blog-style2__inner">

                                <li className="blog-style2__single">
                                    <div className="row">
                                        <div className="col-xl-6">
                                            <div className="blog-style2__single-img">
                                                <img src="assets/images/blog/blog-v2-1.jpg" alt="image"/>
                                                <div className="category-box">
                                                    <p>News & Tips</p>
                                                </div>
                                            </div>
                                        </div>
                                        <div className="col-xl-6">
                                            <div className="blog-style2__single-content">
                                                <div className="author-info">
                                                    <div className="author-info__img">
                                                        <img src="assets/images/blog/blog-v1-author-info1.jpg" alt="image"/>
                                                    </div>
                                                    <div className="author-info__text">
                                                        <h5>Boone Gerardo</h5>
                                                        <ul className="clearfix">
                                                            <li>
                                                                <Link href="#">Nov 15, 2025</Link>
                                                            </li>
                                                            <li>
                                                                <Link href="#">2 Comments</Link>
                                                            </li>
                                                        </ul>
                                                    </div>
                                                </div>
                                                <div className="title-box">
                                                    <h3>
                                                        <Link href="/blog-single">
                                                            Unlocking Success:<br/>Top Five Tips for Leadership<br/>
                                                            Recruitment.
                                                        </Link>
                                                    </h3>
                                                </div>
                                                <div className="blog-style2__single-btn">
                                                    <p>2 Mins Read</p>
                                                    <Link href="/blog-single">
                                                        <span className="icon-right-arrow-1"></span>
                                                    </Link>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </li>

                                <li className="blog-style2__single">
                                    <div className="row">
                                        <div className="col-xl-6">
                                            <div className="blog-style2__single-img">
                                                <img src="assets/images/blog/blog-v2-2.jpg" alt="image"/>
                                                <div className="category-box">
                                                    <p>Job Seekers</p>
                                                </div>
                                            </div>
                                        </div>
                                        <div className="col-xl-6">
                                            <div className="blog-style2__single-content">
                                                <div className="author-info">
                                                    <div className="author-info__img">
                                                        <img src="assets/images/blog/blog-v1-author-info2.jpg" alt="image"/>
                                                    </div>
                                                    <div className="author-info__text">
                                                        <h5>Harley Reuban</h5>
                                                        <ul className="clearfix">
                                                            <li>
                                                                <Link href="#">Oct 24, 2025</Link>
                                                            </li>
                                                            <li>
                                                                <Link href="#">3 Comments</Link>
                                                            </li>
                                                        </ul>
                                                    </div>
                                                </div>
                                                <div className="title-box">
                                                    <h3>
                                                        <Link href="/blog-single">
                                                            Navigating Remote Work:<br/>Seven Tips for Employers
                                                            and<br/>Employees.
                                                        </Link>
                                                    </h3>
                                                </div>
                                                <div className="blog-style2__single-btn">
                                                    <p>3 Mins Read</p>
                                                    <Link href="/blog-single">
                                                        <span className="icon-right-arrow-1"></span>
                                                    </Link>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </li>

                            </ul>
                        </div>

                    </div>
                </div>
            </section>

        </>
    )
}
