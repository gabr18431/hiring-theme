'use client'
import React from 'react'
import Link from "next/link"

export default function Touch() {
    return (
        <> 

            <section className="get-in-touch-style1">
                <div className="get-in-touch-style1__shape1">
                    <img src="assets/images/shapes/get-in-touch-style1__shape1.png" alt="shape"/>
                </div>
                <div className="container">
                    <div className="sec-title withtext text-center">
                        <div className="sub-title">
                            <h4>Get In Touch</h4>
                        </div>
                        <h2>Reach Out Drop us a Line Here</h2>
                        <div className="text">
                            <p>
                                Long established fact that a reader will be distracted by the.
                            </p>
                        </div>
                    </div>

                    <div className="get-in-touch-style1__form">
                        <form id="get-in-touch-form" name="get-in-touch_form" action="/index-2" method="post">
                            <div className="row">
                                <div className="col-xl-6 col-lg-6 col-md-6">
                                    <div className="get-in-touch-style1__form-left">
                                        <div className="form-group">
                                            <div className="input-box">
                                                <input type="text" name="form_name" id="formName" placeholder="Your Name"
                                                    required=""/>
                                            </div>
                                        </div>
                                        <div className="form-group">
                                            <div className="input-box">
                                                <input type="email" name="form_email" id="formEmail"
                                                    placeholder="Email address" required=""/>
                                            </div>
                                        </div>
                                        <div className="form-group">
                                            <div className="input-box">
                                                <input type="text" name="form_phone" id="formPhone" placeholder="Phone"/>
                                            </div>
                                        </div>
                                        <div className="form-group">
                                            <div className="input-box">
                                                <input type="text" name="form_subject" id="formSubject"
                                                    placeholder="Subject"/>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div className="col-xl-6 col-lg-6 col-md-6">
                                    <div className="get-in-touch-style1__form-right">
                                        <div className="form-group">
                                            <div className="input-box">
                                                <textarea name="form_message" id="formMessage"
                                                    placeholder="Write Your Message Here..." required=""></textarea>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div className="row">
                                <div className="col-xl-12 text-center">
                                    <div className="button-box">
                                        <div className="checked-box2">
                                            <input type="checkbox" name="agree" id="iamagree"/>
                                            <label for="iamagree">
                                                <span></span>I agree the terms & Conditions
                                            </label>
                                        </div>
                                        <button className="btn-one" type="submit" data-loading-text="Please wait...">
                                            <span className="txt">
                                                Send Message
                                            </span>
                                        </button>
                                    </div>
                                </div>
                            </div>

                        </form>
                    </div>

                    <div className="employers-employee-phone-email-box">
                        <div className="row">
                            <div className="col-xl-6 col-lg-6 col-md-6">
                                <div className="single-box">
                                    <div className="title text-center">
                                        <h3>Employers</h3>
                                    </div>
                                    <ul>
                                        <li>
                                            <div className="icon">
                                                <span className="icon-mobile"></span>
                                            </div>
                                            <Link href="tel:123456789">(+41) 888.56.7890</Link>
                                        </li>
                                        <li>
                                            <div className="icon">
                                                <span className="icon-email"></span>
                                            </div>
                                            <Link href="mailto:info@templatepath.com">employer@hiringhub.com</Link>
                                        </li>
                                    </ul>
                                </div>
                            </div>

                            <div className="col-xl-6 col-lg-6 col-md-6">
                                <div className="single-box single-box-style2">
                                    <div className="title title2 text-center">
                                        <h3>employee</h3>
                                    </div>
                                    <ul>
                                        <li>
                                            <div className="icon">
                                                <span className="icon-mobile"></span>
                                            </div>
                                            <Link href="tel:123456789">(+41) 888.56.7890</Link>
                                        </li>
                                        <li>
                                            <div className="icon">
                                                <span className="icon-email"></span>
                                            </div>
                                            <Link href="mailto:info@templatepath.com">employer@hiringhub.com</Link>
                                        </li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>

                </div>
            </section>

        </>
    )
}
