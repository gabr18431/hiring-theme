'use client'
import React from 'react'
import Link from "next/link"

export default function Service() {
    return (
        <> 

            <section className="service-style2">
                <div className="container">
                    <div className="sec-title withtext text-center">
                        <div className="sub-title">
                            <h4>Solutions we provide</h4>
                        </div>
                        <h2>Innovative Solutions for Talents</h2>
                        <div className="text">
                            <p>
                                Long established fact that a reader will be distracted by the<br/>readable content of a page.
                            </p>
                        </div>
                    </div>
                    <ul className="row">

                        <li className="col-xl-3 col-lg-6 col-md-6">
                            <div className="service-style2__single">
                                <div className="title-box">
                                    <h3><Link href="/solution01-temporary-stafing">Temporary<br/> Staffing</Link></h3>
                                </div>
                                <div className="icon-box">
                                    <div className="icon">
                                        <img src="assets/images/icon/services/service-icon-2-1.png" alt="icon"/>
                                    </div>
                                    <div className="overlay-img">
                                        <img src="assets/images/services/service-v2-1.jpg" alt="image"/>
                                    </div>
                                </div>
                                <div className="text-box">
                                    <p>The wise man therefore<br/>always holds in these matters<br/>to this one...</p>
                                </div>
                                <div className="btn-box">
                                    <Link href="/solution01-temporary-stafing">
                                        Explore More
                                        <span className="icon-arrow-angle-pointing-to-right"></span>
                                        <span className="icon-right-arrow-1 arrow-hover"></span>
                                    </Link>
                                </div>
                            </div>
                        </li>
                        
                        <li className="col-xl-3 col-lg-6 col-md-6">
                            <div className="service-style2__single">
                                <div className="title-box">
                                    <h3><Link href="/solution02-contract-stafing">Contract<br/>Staffing</Link></h3>
                                </div>
                                <div className="icon-box">
                                    <div className="icon">
                                        <img src="assets/images/icon/services/service-icon-2-2.png" alt="icon"/>
                                    </div>
                                    <div className="overlay-img">
                                        <img src="assets/images/services/service-v2-1.jpg" alt="image"/>
                                    </div>
                                </div>
                                <div className="text-box">
                                    <p>Right to find fault with a man<br/>chooses annoying to be that<br/>consequences...</p>
                                </div>
                                <div className="btn-box">
                                    <Link href="/solution02-contract-stafing">
                                        Explore More
                                        <span className="icon-arrow-angle-pointing-to-right"></span>
                                        <span className="icon-right-arrow-1 arrow-hover"></span>
                                    </Link>
                                </div>
                            </div>
                        </li>
                        
                        <li className="col-xl-3 col-lg-6 col-md-6">
                            <div className="service-style2__single">
                                <div className="title-box">
                                    <h3><Link href="/solution03-project-based">Project<br/>Based Hiring</Link></h3>
                                </div>
                                <div className="icon-box">
                                    <div className="icon">
                                        <img src="assets/images/icon/services/service-icon-2-3.png" alt="icon"/>
                                    </div>
                                    <div className="overlay-img">
                                        <img src="assets/images/services/service-v2-1.jpg" alt="image"/>
                                    </div>
                                </div>
                                <div className="text-box">
                                    <p>Occasionally circumstances<br/>occur in painprocure some<br/>great content...</p>
                                </div>
                                <div className="btn-box">
                                    <Link href="/solution03-project-based">
                                        Explore More
                                        <span className="icon-arrow-angle-pointing-to-right"></span>
                                        <span className="icon-right-arrow-1 arrow-hover"></span>
                                    </Link>
                                </div>
                            </div>
                        </li>
                        
                        <li className="col-xl-3 col-lg-6 col-md-6">
                            <div className="service-style2__single">
                                <div className="title-box">
                                    <h3><Link href="/solution04-permanent-stafing">Permanent<br/>Staffing</Link></h3>
                                </div>
                                <div className="icon-box">
                                    <div className="icon">
                                        <img src="assets/images/icon/services/service-icon-2-4.png" alt="icon"/>
                                    </div>
                                    <div className="overlay-img">
                                        <img src="assets/images/services/service-v2-1.jpg" alt="image"/>
                                    </div>
                                </div>
                                <div className="text-box">
                                    <p>The claims off duty or the<br/>obligations of business it will<br/>frequently occur
                                        that...</p>
                                </div>
                                <div className="btn-box">
                                    <Link href="/solution04-permanent-stafing">
                                        Explore More
                                        <span className="icon-arrow-angle-pointing-to-right"></span>
                                        <span className="icon-right-arrow-1 arrow-hover"></span>
                                    </Link>
                                </div>
                            </div>
                        </li>

                    </ul>
                </div>
            </section>

        </>
    )
}
