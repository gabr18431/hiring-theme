'use client'
import React from 'react'
import Link from "next/link"
import { Autoplay, Navigation, Pagination } from "swiper/modules"
import { Swiper, SwiperSlide } from "swiper/react"
const swiperOptions = {
    modules: [Autoplay, Pagination, Navigation],
    slidesPerView: 1,
    spaceBetween: 30,
    autoplay: {
        delay: 5000,
        disableOnInteraction: false,
    },
    loop: true,

    // Navigation
    navigation: {
        nextEl: '.swiper-button-prev',
        prevEl: '.swiper-button-next',
    },

    breakpoints: {
        320: {
            slidesPerView: 1,
            spaceBetween: 30,
        },
        575: {
            slidesPerView: 1,
            spaceBetween: 30,
        },
        767: {
            slidesPerView: 2,
            spaceBetween: 30,
        },
        991: {
            slidesPerView: 2,
            spaceBetween: 30,
        },
        1199: {
            slidesPerView: 3,
            spaceBetween: 30,
        },
        1600: {
            slidesPerView: 3,
            spaceBetween: 30,
        },
    }
}

export default function Team() {
    return (
        <> 

            <section className="team-style1">
                <div className="container">
                    <div className="sec-title">
                        <div className="sub-title">
                            <h4>Team Behind Us</h4>
                        </div>
                        <h2>Our Recruitment Specialists</h2>
                    </div>
                    <div className='team-one-content'>
                        <div className="row">
                            <div className="col-xl-12">
                                <Swiper {...swiperOptions} className="swiper-container team-style1-carousel">
                                    <SwiperSlide>
                                        <div className="team-style1__single">
                                            <div className="img-box">
                                                <img src="assets/images/team/team-v1-1.jpg" alt="image"/>
                                                <div className="overlay-content">
                                                    <div className="title">
                                                        <h3><Link href="/team">Bertram Irvin</Link></h3>
                                                    </div>
                                                    <div className="border-line"></div>
                                                    <div className="sub-title">
                                                        <div className="text">
                                                            <p>Senior Recruiter</p>
                                                        </div>
                                                        <div className="social-share-box">
                                                            <span className="icon-share"></span>
                                                            <ul className="clearfix">
                                                                <li>
                                                                    <Link href="#">
                                                                        <i className="icon-facebook"></i>
                                                                    </Link>
                                                                </li>
                                                                <li>
                                                                    <Link href="#">
                                                                        <i className="icon-twitter"></i>
                                                                    </Link>
                                                                </li>
                                                                <li>
                                                                    <Link href="#">
                                                                        <i className="icon-instagram-logo"></i>
                                                                    </Link>
                                                                </li>
                                                            </ul>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </SwiperSlide>
                                    <SwiperSlide>
                                        <div className="team-style1__single">
                                            <div className="img-box">
                                                <img src="assets/images/team/team-v1-2.jpg" alt="image"/>
                                                <div className="overlay-content">
                                                    <div className="title">
                                                        <h3><Link href="/team">Michel Kyle</Link></h3>
                                                    </div>
                                                    <div className="border-line"></div>
                                                    <div className="sub-title">
                                                        <div className="text">
                                                            <p>Recruitment Manager</p>
                                                        </div>

                                                        <div className="social-share-box">
                                                            <span className="icon-share"></span>
                                                            <ul className="clearfix">
                                                                <li>
                                                                    <Link href="#">
                                                                        <i className="icon-facebook"></i>
                                                                    </Link>
                                                                </li>
                                                                <li>
                                                                    <Link href="#">
                                                                        <i className="icon-twitter"></i>
                                                                    </Link>
                                                                </li>
                                                                <li>
                                                                    <Link href="#">
                                                                        <i className="icon-instagram-logo"></i>
                                                                    </Link>
                                                                </li>
                                                            </ul>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </SwiperSlide>
                                    <SwiperSlide>
                                        <div className="team-style1__single">
                                            <div className="img-box">
                                                <img src="assets/images/team/team-v1-3.jpg" alt="image"/>
                                                <div className="overlay-content">
                                                    <div className="title">
                                                        <h3><Link href="/team">Nora Lillian</Link></h3>
                                                    </div>
                                                    <div className="border-line"></div>
                                                    <div className="sub-title">
                                                        <div className="text">
                                                            <p>IT Recruitment Specialist</p>
                                                        </div>

                                                        <div className="social-share-box">
                                                            <span className="icon-share"></span>
                                                            <ul className="clearfix">
                                                                <li>
                                                                    <Link href="#">
                                                                        <i className="icon-facebook"></i>
                                                                    </Link>
                                                                </li>
                                                                <li>
                                                                    <Link href="#">
                                                                        <i className="icon-twitter"></i>
                                                                    </Link>
                                                                </li>
                                                                <li>
                                                                    <Link href="#">
                                                                        <i className="icon-instagram-logo"></i>
                                                                    </Link>
                                                                </li>
                                                            </ul>
                                                        </div>

                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </SwiperSlide>
                                    <SwiperSlide>
                                        <div className="team-style1__single">
                                            <div className="img-box">
                                                <img src="assets/images/team/team-v1-1.jpg" alt="image"/>
                                                <div className="overlay-content">
                                                    <div className="title">
                                                        <h3><Link href="/team">Bertram Irvin</Link></h3>
                                                    </div>
                                                    <div className="border-line"></div>
                                                    <div className="sub-title">
                                                        <div className="text">
                                                            <p>Senior Recruiter</p>
                                                        </div>
                                                        <div className="social-share-box">
                                                            <span className="icon-share"></span>
                                                            <ul className="clearfix">
                                                                <li>
                                                                    <Link href="#">
                                                                        <i className="icon-facebook"></i>
                                                                    </Link>
                                                                </li>
                                                                <li>
                                                                    <Link href="#">
                                                                        <i className="icon-twitter"></i>
                                                                    </Link>
                                                                </li>
                                                                <li>
                                                                    <Link href="#">
                                                                        <i className="icon-instagram-logo"></i>
                                                                    </Link>
                                                                </li>
                                                            </ul>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </SwiperSlide>
                                    <SwiperSlide>
                                        <div className="team-style1__single">
                                            <div className="img-box">
                                                <img src="assets/images/team/team-v1-2.jpg" alt="image"/>
                                                <div className="overlay-content">
                                                    <div className="title">
                                                        <h3><Link href="/team">Michel Kyle</Link></h3>
                                                    </div>
                                                    <div className="border-line"></div>
                                                    <div className="sub-title">
                                                        <div className="text">
                                                            <p>Recruitment Manager</p>
                                                        </div>

                                                        <div className="social-share-box">
                                                            <span className="icon-share"></span>
                                                            <ul className="clearfix">
                                                                <li>
                                                                    <Link href="#">
                                                                        <i className="icon-facebook"></i>
                                                                    </Link>
                                                                </li>
                                                                <li>
                                                                    <Link href="#">
                                                                        <i className="icon-twitter"></i>
                                                                    </Link>
                                                                </li>
                                                                <li>
                                                                    <Link href="#">
                                                                        <i className="icon-instagram-logo"></i>
                                                                    </Link>
                                                                </li>
                                                            </ul>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </SwiperSlide>
                                    <SwiperSlide>
                                        <div className="team-style1__single">
                                            <div className="img-box">
                                                <img src="assets/images/team/team-v1-3.jpg" alt="image"/>
                                                <div className="overlay-content">
                                                    <div className="title">
                                                        <h3><Link href="/team">Nora Lillian</Link></h3>
                                                    </div>
                                                    <div className="border-line"></div>
                                                    <div className="sub-title">
                                                        <div className="text">
                                                            <p>IT Recruitment Specialist</p>
                                                        </div>

                                                        <div className="social-share-box">
                                                            <span className="icon-share"></span>
                                                            <ul className="clearfix">
                                                                <li>
                                                                    <Link href="#">
                                                                        <i className="icon-facebook"></i>
                                                                    </Link>
                                                                </li>
                                                                <li>
                                                                    <Link href="#">
                                                                        <i className="icon-twitter"></i>
                                                                    </Link>
                                                                </li>
                                                                <li>
                                                                    <Link href="#">
                                                                        <i className="icon-instagram-logo"></i>
                                                                    </Link>
                                                                </li>
                                                            </ul>
                                                        </div>

                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </SwiperSlide>
                                </Swiper>
                                <div className="swiper-nav-style-one">
                                    <button className="swiper-button-prev">
                                        <span className="left icon-left-arrow-angle-big-gross-symbol"></span>
                                    </button>
                                    <button className="swiper-button-next">
                                        <span className="right icon-arrow-angle-pointing-to-right"></span>
                                    </button>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div className="team-style1__btn">
                        <Link href="/team-2">
                            See all Members
                            <i className="icon-arrow-angle-pointing-to-right"></i>
                        </Link>
                    </div>

                </div>
            </section>

        </>
    )
}
