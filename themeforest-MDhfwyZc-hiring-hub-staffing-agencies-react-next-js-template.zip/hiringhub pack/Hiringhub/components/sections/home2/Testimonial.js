'use client'
import React from 'react'

export default function Testimonial() {
    return (
        <> 

            <section className="testimonial-style2">
                <div className="container">
                    <div className="row">

                        <div className="col-xl-4">
                            <div className="testimonial-style2__img">
                                <img src="assets/images/testimonial/testimonial-style2-img1.png" alt="image"/>
                                <div className="overlay-content text-center">
                                    <div className="rating-box">
                                        <ul>
                                            <li>
                                                <div className="icon">
                                                    <i className="icon-rate-star-button"></i>
                                                </div>
                                            </li>
                                            <li>
                                                <div className="icon">
                                                    <i className="icon-rate-star-button"></i>
                                                </div>
                                            </li>
                                        </ul>
                                        <div className="title">
                                            <h4>Excellent</h4>
                                        </div>
                                        <ul>
                                            <li>
                                                <div className="icon">
                                                    <i className="icon-rate-star-button"></i>
                                                </div>
                                            </li>
                                            <li>
                                                <div className="icon">
                                                    <i className="icon-rate-star-button"></i>
                                                </div>
                                            </li>
                                        </ul>
                                    </div>
                                    <div className="text">
                                        <p>Rated from 65k Employers & Employees.</p>
                                        <h4>4.9 out of 5</h4>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div className="col-xl-8">
                            <div className="testimonial-style2__content">
                                <div className="sec-title">
                                    <div className="sub-title">
                                        <h4>Testimonials</h4>
                                    </div>
                                    <h2>Leading in Client Satisfaction</h2>
                                </div>

                                <div className="testimonial-style2__single">
                                    <div className="img-box">
                                        <img src="assets/images/testimonial/testimonial-v2-1.png" alt="image"/>
                                    </div>
                                    <div className="testimonial-style2__single-inner">
                                        <div className="content-box">
                                            <div className="icon">
                                                <i className="icon-quote"></i>
                                            </div>
                                            <div className="title-box">
                                                <h3>Best Hiring Assistance</h3>
                                                <p>
                                                    I really appreciated the outstanding time, work & effort that
                                                    the entire staff put into finding me an excellent job.
                                                </p>
                                            </div>
                                        </div>
                                        <div className="customer-info">
                                            <h4>Eloise Juniper</h4>
                                            <p>Vice President, Daily News</p>
                                        </div>
                                    </div>
                                </div>

                                <div className="testimonial-style2__single">
                                    <div className="img-box">
                                        <img src="assets/images/testimonial/testimonial-v2-2.png" alt="image"/>
                                    </div>
                                    <div className="testimonial-style2__single-inner">
                                        <div className="content-box">
                                            <div className="icon">
                                                <i className="icon-quote"></i>
                                            </div>
                                            <div className="title-box">
                                                <h3>Career-Altering Guidance</h3>
                                                <p>
                                                    Staffy is very accurate when comes to helping you find a job and
                                                    if that job finishes, They help you.
                                                </p>
                                            </div>
                                        </div>
                                        <div className="customer-info">
                                            <h4>Nathan Felix</h4>
                                            <p>Manager, Cypertech pvt ltd</p>
                                        </div>
                                    </div>
                                </div>

                            </div>
                        </div>
                    </div>
                </div>
            </section>

        </>
    )
}
