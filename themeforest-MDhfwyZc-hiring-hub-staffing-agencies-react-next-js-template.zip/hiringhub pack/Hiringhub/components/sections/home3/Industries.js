'use client'
import React from 'react'
import Link from "next/link"

export default function Industries() {
    return (
        <> 

            <section className="industries-style2">
                <div className="container">
                    <div className="sec-title withtext text-center">
                        <div className="sub-title">
                            <h4>Service Areas</h4>
                        </div>
                        <h2>Our Specialized Industries</h2>
                        <div className="text">
                            <p>Long established fact that a reader will be distracted.</p>
                        </div>
                    </div>
                    <div className="industries-style2__content">
                        <ul>
                            <li className="cs-hover_tab active">
                                <div className="left">
                                    <p>Industry 01</p>
                                    <div className="title">
                                        <h3>
                                            <Link href="/employers-overview">Accounting & Finance</Link>
                                        </h3>
                                    </div>
                                </div>
                                <div className="right">
                                    <div className="title">
                                        <h6>
                                            <Link href="/employers-overview">Job openings & Talents</Link>
                                        </h6>
                                    </div>
                                    <div className="round-box"></div>
                                    <div className="icon-box">
                                        <Link href="/employers-overview">
                                            <i className="icon-arrow-angle-pointing-to-right"></i>
                                        </Link>
                                    </div>
                                </div>
                                <div className="industries-style2__content-single-overlay">
                                    <div className="industries-style2__content-single__overlay-bg"><img src='assets/images/resources/industries-v2-1.jpg' alt=""/></div>
                                </div>
                            </li>
                            <li className="cs-hover_tab">
                                <div className="left">
                                    <p>Industry 02</p>
                                    <div className="title">
                                        <h3>
                                            <Link href="/employers-overview">Digital Marketing</Link>
                                        </h3>
                                    </div>
                                </div>
                                <div className="right">
                                    <div className="title">
                                        <h6>
                                            <Link href="/employers-overview">Job openings & Talents</Link>
                                        </h6>
                                    </div>
                                    <div className="round-box"></div>
                                    <div className="icon-box">
                                        <Link href="/employers-overview">
                                            <i className="icon-arrow-angle-pointing-to-right"></i>
                                        </Link>
                                    </div>
                                </div>
                                <div className="industries-style2__content-single-overlay">
                                    <div className="industries-style2__content-single__overlay-bg"><img src='assets/images/resources/industries-v2-2.jpg' alt=""/></div>
                                </div>
                            </li>
                            <li className="cs-hover_tab">
                                <div className="left">
                                    <p>Industry 03</p>
                                    <div className="title">
                                        <h3>
                                            <Link href="/employers-overview">Heathcare & Medical</Link>
                                        </h3>
                                    </div>
                                </div>
                                <div className="right">
                                    <div className="title">
                                        <h6>
                                            <Link href="/employers-overview">Job openings & Talents</Link>
                                        </h6>
                                    </div>
                                    <div className="round-box"></div>
                                    <div className="icon-box">
                                        <Link href="/employers-overview">
                                            <i className="icon-arrow-angle-pointing-to-right"></i>
                                        </Link>
                                    </div>
                                </div>
                                <div className="industries-style2__content-single-overlay">
                                    <div className="industries-style2__content-single__overlay-bg"><img src='assets/images/resources/industries-v2-1.jpg' alt=""/></div>
                                </div>
                            </li>
                            <li className="cs-hover_tab">
                                <div className="left">
                                    <p>Industry 04</p>
                                    <div className="title">
                                        <h3>
                                            <Link href="/employers-overview">Information Technology</Link>
                                        </h3>
                                    </div>
                                </div>
                                <div className="right">
                                    <div className="title">
                                        <h6>
                                            <Link href="/employers-overview">Job openings & Talents</Link>
                                        </h6>
                                    </div>
                                    <div className="round-box"></div>
                                    <div className="icon-box">
                                        <Link href="/employers-overview">
                                            <i className="icon-arrow-angle-pointing-to-right"></i>
                                        </Link>
                                    </div>
                                </div>
                                <div className="industries-style2__content-single-overlay">
                                    <div className="industries-style2__content-single__overlay-bg"><img src='assets/images/resources/industries-v2-3.jpg' alt=""/></div>
                                </div>
                            </li>

                        </ul>
                    </div>

                </div>
            </section>

        </>
    )
}
