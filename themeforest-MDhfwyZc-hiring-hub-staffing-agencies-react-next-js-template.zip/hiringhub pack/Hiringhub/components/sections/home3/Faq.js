'use client'
import React from 'react'
import { useState } from "react"
import Link from "next/link"

export default function Faq() {
    const [isActive, setIsActive] = useState({
        status: false,
        key: 1,
    })

    const handleToggle = (key) => {
        if (isActive.key === key) {
            setIsActive({
                status: false,
            })
        } else {
            setIsActive({
                status: true,
                key,
            })
        }
    }
    return (
        <> 

            <section className="faq-style1">
                <div className="container">
                    <div className="sec-title withtext text-center">
                        <div className="sub-title">
                            <h4>Faq’s</h4>
                        </div>
                        <h2>Common Questions & Answers</h2>
                        <div className="text">
                            <p>
                                Long established fact that a reader will be distracted by the<br/>readable content of a page.
                            </p>
                        </div>
                    </div>
                    <div className="row">

                        <div className="col-xl-6">
                            <div className="faq-style1__img">
                                <div className="inner">
                                    <img src="assets/images/resources/faq-v1-img1.jpg" alt="image"/>
                                </div>
                                <div className="overlay-content">
                                    <a href="#" className="icon">
                                        <span className="icon-question"><span className="path1"></span><span
                                                className="path2"></span><span className="path3"></span></span>
                                    </a>
                                    <h3>Can't Find<br/>Your Answer?</h3>
                                    <p>Send you questions<br/>to our team, they’ll help you.</p>
                                    <div className="btn-box">
                                        <Link className="btn-one" href="/faq">
                                            <span className="txt">Send Now</span>
                                        </Link>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div className="col-xl-6">
                            <div className="faq-style1__content">
                                <ul className="accordion-box-style1">
                                    
                                    <li className="accordion accordion-block">
                                        <div className={isActive.key == 1 ? "accord-btn active" : "accord-btn"} onClick={() => handleToggle(1)}>
                                            <h4>
                                                What industries do you specialize in?
                                            </h4>
                                        </div>
                                        <div className={isActive.key == 1 ? "accord-content current" : "accord-content"}>
                                            <p>
                                                There are many variations passages of lorem ipsum available,
                                                but the majority have suffered alteration form injected humours
                                                randomises don't look even slightly.
                                            </p>
                                        </div>
                                    </li>
                                    
                                    <li className="accordion accordion-block">
                                        <div className={isActive.key == 2 ? "accord-btn active" : "accord-btn"} onClick={() => handleToggle(2)}>
                                            <h4>What types of jobs do you offer?</h4>
                                        </div>
                                        <div className={isActive.key == 2 ? "accord-content current" : "accord-content"}>
                                            <p>
                                                There are many variations passages of lorem ipsum available,
                                                but the majority have suffered alteration form injected humours
                                                randomises don't look even slightly.
                                            </p>
                                        </div>
                                    </li>
                                    
                                    <li className="accordion accordion-block">
                                        <div className={isActive.key == 3 ? "accord-btn active" : "accord-btn"} onClick={() => handleToggle(3)}>
                                            <h4>Are there fees for job seekers?</h4>
                                        </div>
                                        <div className={isActive.key == 3 ? "accord-content current" : "accord-content"}>
                                            <p>
                                                There are many variations passages of lorem ipsum available,
                                                but the majority have suffered alteration form injected humours
                                                randomises don't look even slightly.
                                            </p>
                                        </div>
                                    </li>
                                    
                                    <li className="accordion accordion-block">
                                        <div className={isActive.key == 4 ? "accord-btn active" : "accord-btn"} onClick={() => handleToggle(4)}>
                                            <h4>How long can temporary assignments last?</h4>
                                        </div>
                                        <div className={isActive.key == 4 ? "accord-content current" : "accord-content"}>
                                            <p>
                                                There are many variations passages of lorem ipsum available,
                                                but the majority have suffered alteration form injected humours
                                                randomises don't look even slightly.
                                            </p>
                                        </div>
                                    </li>
                                    
                                    <li className="accordion accordion-block">
                                        <div className={isActive.key == 5 ? "accord-btn active" : "accord-btn"} onClick={() => handleToggle(5)}>
                                            <h4>How is billing handled for staffing services?</h4>
                                        </div>
                                        <div className={isActive.key == 5 ? "accord-content current" : "accord-content"}>
                                            <p>
                                                There are many variations passages of lorem ipsum available,
                                                but the majority have suffered alteration form injected humours
                                                randomises don't look even slightly.
                                            </p>
                                        </div>
                                    </li>
                                    
                                </ul>
                                <div className="btn-box">
                                    <Link href="/faq">
                                        More Questions & Answers
                                        <i className="icon-arrow-angle-pointing-to-right"></i>
                                    </Link>
                                </div>
                            </div>
                        </div>

                    </div>
                </div>
            </section>

        </>
    )
}
