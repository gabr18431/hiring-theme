'use client'
import React from 'react'

export default function Job() {
    return (
        <> 

            <section className="find-job-candidate">
                <div className="find-job-candidate__bg"
                    style={{ backgroundImage: "url(assets/images/backgrounds/find-job-candidate-bg.jpg)" }}></div>
                <div className="container">
                    <div className="find-job-candidate__inner">
                        <form id="find-job-candidate-form" name="find-job-candidate_form" action="#" method="post">
                            <ul className="row">
                                <li className="col-xl-6">
                                    <div className="input-box">
                                        <input type="text" name="form_name" id="formName"
                                            placeholder="Job Title (or) Keyword" required=""/>
                                        <div className="icon-box">
                                            <span className="icon-description"></span>
                                        </div>
                                    </div>
                                </li>
                                <li className="col-xl-6">
                                    <div className="input-box">
                                        <input type="text" name="form_country-city" id="formCountryCity"
                                            placeholder="Country / City" required=""/>
                                        <div className="icon-box">
                                            <span className="icon-map"></span>
                                        </div>
                                    </div>
                                </li>
                            </ul>
                            <div className="btn-box">
                                <button className="btn-one" type="submit" data-loading-text="Please wait...">
                                    <span className="txt">
                                        Hire Candidate
                                    </span>
                                </button>
                                <button className="btn-one" type="submit" data-loading-text="Please wait...">
                                    <span className="txt">
                                        Find a Job
                                    </span>
                                </button>
                            </div>
                        </form>
                    </div>
                </div>
            </section>

        </>
    )
}
