'use client'
import React from 'react'
import CounterUp from "@/components/elements/CounterUp"

export default function About() {
    return (
        <> 

            <section className="about-style3">
                <div className="container">
                    <div className="row">
                        <div className="col-xl-6">
                            <div className="about-style3__img">
                                <div className="inner">
                                    <img src="assets/images/about/about-v3-1.jpg" alt="image"/>
                                </div>
                                <div className="overlay-box">
                                    <div className="overlay-box__shape1">
                                        <img src="assets/images/shapes/about-v3-shape1.png" alt="shape"/>
                                    </div>
                                    <div className="overlay-box__shape2">
                                        <img src="assets/images/shapes/about-v3-shape1.png" alt="shape"/>
                                    </div>
                                    <div className="fact-counter text-center">
                                        <div className="cercle-box"></div>
                                        <div className="counter-box">
                                            <h2>
                                                <span className="ziro">0</span>
                                                <span className="odometer"><CounterUp end={9} /></span>
                                                <span className="plus">+</span>
                                            </h2>
                                        </div>
                                        <p>Experience in Staffing<br/>Industry</p>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div className="col-xl-6">
                            <div className="about-style3__content">
                                <div className="sec-title withtext">
                                    <div className="sub-title">
                                        <h4>About our agency</h4>
                                    </div>
                                    <h2>Business Elevators and<br/>Career Crafters</h2>
                                    <div className="text">
                                        <p>Our being able to do what we like best, every pleasure is to be welcomed
                                            <br/>and every pain avoided but in certain circumstances.</p>
                                    </div>
                                </div>
                                <div className="list-item">
                                    <ul className="clearfix">
                                        <li>
                                            <div className="icon-box">
                                                <span className="icon-verify"><span className="path1"></span><span
                                                        className="path2"></span></span>
                                            </div>
                                            <div className="title-box">
                                                <h3>Certified</h3>
                                                <p>Protecting Your Home From Damaging Leaks.</p>
                                            </div>
                                        </li>
                                        <li>
                                            <div className="icon-box">
                                                <span className="icon-verify"><span className="path1"></span><span
                                                        className="path2"></span></span>
                                            </div>
                                            <div className="title-box">
                                                <h3>Quality Placements</h3>
                                                <p>The Roofing Company By Which All Others Are Measured.</p>
                                            </div>
                                        </li>
                                        <li>
                                            <div className="icon-box">
                                                <span className="icon-verify"><span className="path1"></span><span
                                                        className="path2"></span></span>
                                            </div>
                                            <div className="title-box">
                                                <h3>Global Reach</h3>
                                                <p>Roofing Is Our Heritage, Quality Is Our Tradition.</p>
                                            </div>
                                        </li>

                                    </ul>
                                </div>
                                <div className="customer-info">
                                    <div className="img-box">
                                        <img src="assets/images/about/about-v3-customer-info.jpg" alt="image"/>
                                    </div>
                                    <div className="title">
                                        <h4>Elliot Theodore</h4>
                                        <p>/ Founder</p>
                                    </div>
                                </div>
                            </div>
                        </div>

                    </div>
                </div>
            </section>

        </>
    )
}
