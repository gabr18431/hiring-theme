'use client'
import React from 'react'
import VideoPopup from "@/components/elements/VideoPopup"
import CircleText from "../../../components/elements/CircleText"

export default function Video() {
    return (
        <> 

            <section className="video-style1">
                <div className="video-style1__bg" style={{ backgroundImage: "url(assets/images/resources/video-v1-img-bg1.jpg)" }}>
                </div>
                <div className="container">
                    <div className="video-style1__inner">
                        <div className="video-style1__round-text-box">
                            <div className="inner">
                                <div className="video-style1__curved-circle-top">
                                    <CircleText text="Click to play video Click to play video" radius={80} />
                                </div>
                            </div>
                            <div className="overlay-video-btn">
                                <VideoPopup />
                            </div>
                        </div>
                        <div className="video-style1__title">
                            <h2>Skill Development Program<br/>by Hiring Hub</h2>
                            <div className="border-line"></div>
                            <p>Favor the more eloquent presidential days of yester year give ipsum.</p>
                        </div>
                    </div>
                </div>
            </section>

        </>
    )
}
