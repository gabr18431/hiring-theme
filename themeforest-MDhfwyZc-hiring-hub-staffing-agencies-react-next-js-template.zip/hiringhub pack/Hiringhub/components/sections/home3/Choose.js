'use client'
import React from 'react'
import Link from "next/link"
import { Autoplay, Navigation, Pagination } from "swiper/modules"
import { Swiper, SwiperSlide } from "swiper/react"
const swiperOptions = {
    modules: [Autoplay, Pagination, Navigation],
    slidesPerView: 1,
    spaceBetween: 30,
    autoplay: {
        delay: 5000,
        disableOnInteraction: false,
    },
    loop: true,

    // Navigation
    navigation: {
        nextEl: '.swiper-button-prev',
        prevEl: '.swiper-button-next',
    },

    // Pagination
    pagination: {
        el: '.swiper-pagination',
        clickable: true,
    },

    breakpoints: {
        320: {
            slidesPerView: 1,
            spaceBetween: 30,
        },
        575: {
            slidesPerView: 1,
            spaceBetween: 30,
        },
        767: {
            slidesPerView: 2,
            spaceBetween: 30,
        },
        991: {
            slidesPerView: 2,
            spaceBetween: 30,
        },
        1200: {
            slidesPerView: 3,
            spaceBetween: 30,
        },
        1800: {
            slidesPerView: 4,
            spaceBetween: 30,
        },
    }
}

export default function Choose() {
    return (
        <> 

            <section className="why-choose-style2">
                <div className="container">
                    <div className="sec-title">
                        <div className="sub-title">
                            <h4>Why Choose Us</h4>
                        </div>
                        <h2>Advantages of Working With Us</h2>
                    </div>
                </div>
                <div className="auto-container">
                    <div className="why-choose-style2__inner">
                        <ul>
                            <li></li>
                            <li></li>
                            <li></li>
                        </ul>
                    </div>
                    <div className='choose-style2-content'>
                        <Swiper {...swiperOptions} className="swiper-container choose-style2-carousel">
                            <SwiperSlide>
                                <div className="why-choose-style2__single">
                                    <div className="icon-box">
                                        <img src="assets/images/icon/why-choose/why-choose-v2-icon-1.png" alt="icon"/>
                                        <div className="count-text">
                                            <h2 data-hover="01">01</h2>
                                        </div>
                                    </div>
                                    <div className="content-box">
                                        <h3><Link href="/about">Reduce Hiring Risks</Link></h3>
                                        <p>Business it will frequently occur that<br/>pleasures have to be repudiated &
                                            annoyances accepted.</p>
                                    </div>
                                </div>
                            </SwiperSlide>
                            <SwiperSlide>
                                <div className="why-choose-style2__single">
                                    <div className="icon-box">
                                        <img src="assets/images/icon/why-choose/why-choose-v2-icon-2.png" alt="icon"/>
                                        <div className="count-text">
                                            <h2 data-hover="02">02</h2>
                                        </div>
                                    </div>
                                    <div className="content-box">
                                        <h3><Link href="/about">Increase Efficiencies</Link></h3>
                                        <p>Power of choice is untrammelled & when nothing prevents our being to do what we like
                                            best.</p>
                                    </div>
                                </div>
                            </SwiperSlide>
                            <SwiperSlide>
                                <div className="why-choose-style2__single">
                                    <div className="icon-box">
                                        <img src="assets/images/icon/why-choose/why-choose-v2-icon-3.png" alt="icon"/>
                                        <div className="count-text">
                                            <h2 data-hover="03">03</h2>
                                        </div>
                                    </div>
                                    <div className="content-box">
                                        <h3><Link href="/about">Great HR Image</Link></h3>
                                        <p>Obligations of business it will fail frequently occur that pleasures have repudiated &
                                            annoyances.</p>
                                    </div>
                                </div>
                            </SwiperSlide>
                            <SwiperSlide>
                                <div className="why-choose-style2__single">
                                    <div className="icon-box">
                                        <img src="assets/images/icon/why-choose/why-choose-v2-icon-4.png" alt="icon"/>
                                        <div className="count-text">
                                            <h2 data-hover="04">04</h2>
                                        </div>
                                    </div>
                                    <div className="content-box">
                                        <h3><Link href="/about">Rich Field Depth</Link></h3>
                                        <p>The wise man therefore always get holds in these matters this secure other greater
                                            pleasures.</p>
                                    </div>
                                </div>
                            </SwiperSlide>
                        </Swiper>
                        <div className="swiper-nav-style-one">
                            <button className="swiper-button-prev">
                                <span className="left icon-left-arrow-angle-big-gross-symbol"></span>
                            </button>
                            <button className="swiper-button-next">
                                <span className="right icon-arrow-angle-pointing-to-right"></span>
                            </button>
                        </div>
                    </div>
                </div>
            </section>

        </>
    )
}
