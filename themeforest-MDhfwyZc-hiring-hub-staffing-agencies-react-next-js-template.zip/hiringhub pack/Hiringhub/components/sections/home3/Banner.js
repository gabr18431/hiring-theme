'use client'
import React from 'react'
import { useState } from "react"
import Link from "next/link"

export default function Banner() {
    const [activeIndex, setActiveIndex] = useState(1)
        const handleOnClick = (index) => {
            setActiveIndex(index)
        }
    return (
        <> 

            <section className="banner-style1">
                <div className="banner-style1__content-social-links">
                    <ul>
                        <li>
                            <Link href="https://www.facebook.com/">
                                <span className="icon-facebook"></span>
                            </Link>
                        </li>
                        <li>
                            <Link href="https://x.com/i/flow/login">
                                <span className="icon-twitter"></span>
                            </Link>
                        </li>
                        <li>
                            <Link href="https://www.instagram.com/accounts/login/?hl=en">
                                <span className="icon-instagram-logo"></span>
                            </Link>
                        </li>
                        <li>
                            <Link href="https://www.youtube.com/">
                                <span className="icon-youtube"></span>
                            </Link>
                        </li>
                    </ul>
                </div>

                <div className="container">
                    <div className="banner-style1__tab">

                        <div className="banner-style1-tab__button">
                            <div className="title-box">
                                <h2>I’am an</h2>
                            </div>
                            <ul className="tabs-button-box clearfix">
                                <li onClick={() => handleOnClick(1)} className={activeIndex === 1 ? "tab-btn-item active-btn" : "tab-btn-item"}>
                                    <span>
                                        Employee
                                        <i className="icon-right-arrow-1 arrow-hover"></i>
                                    </span>
                                </li>
                                <li onClick={() => handleOnClick(2)} className={activeIndex === 2 ? "tab-btn-item active-btn" : "tab-btn-item"}>
                                    <span>
                                        Employer
                                        <i className="icon-right-arrow-1 arrow-hover"></i>
                                    </span>
                                </li>
                            </ul>
                        </div>

                        <div className="tabs-content-box">

                            <div className={activeIndex === 1 ? "tab-content-box-item active-tab" : "tab-content-box-item"}>
                                <div className="banner-style1-tab-content-box-item">
                                    <div className="title">
                                        <h2>Finding a job?<br/>End the search today</h2>
                                    </div>
                                    <div className="border-line"></div>
                                    <div className="text">
                                        <p>
                                            Beguiled and demoralized by the charms of pleasure moment<br/>
                                            can not foresee the pain and trouble.
                                        </p>
                                    </div>
                                    <div className="btn-box">
                                        <Link href="/about">
                                            Explore More
                                            <i className="icon-arrow-angle-pointing-to-right arrow-hover"></i>
                                        </Link>
                                    </div>
                                </div>
                            </div>


                            <div className={activeIndex === 2 ? "tab-content-box-item active-tab" : "tab-content-box-item"}>
                                <div className="banner-style1-tab-content-box-item">
                                    <div className="title">
                                        <h2>We Can Help You<br/> Elevate Your Company</h2>
                                    </div>
                                    <div className="border-line"></div>
                                    <div className="text">
                                        <p>
                                            Except to obtain some advantage from it? But who has any right<br/>
                                            to find fault with a man who chooses.
                                        </p>
                                    </div>
                                    <div className="btn-box">
                                        <Link href="/about">
                                            Explore More
                                            <i className="icon-arrow-angle-pointing-to-right arrow-hover"></i>
                                        </Link>
                                    </div>
                                </div>
                            </div>

                        </div>
                    </div>
                </div>
            </section>

        </>
    )
}
