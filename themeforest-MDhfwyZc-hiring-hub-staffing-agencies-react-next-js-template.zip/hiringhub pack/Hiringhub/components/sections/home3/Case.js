'use client'
import React from 'react'
import Link from "next/link"

export default function Case() {
    return (
        <> 

            <section className="case-style2">
                <div className="container">
                    <div className="sec-title withtext text-center">
                        <div className="sub-title">
                            <h4>Case Studies</h4>
                        </div>
                        <h2>Staffing Solutions in Action</h2>
                        <div className="text">
                            <p>
                                Long established fact that a reader will be distracted by the<br/>readable content of a page.
                            </p>
                        </div>
                    </div>
                    <div className="row">


                        <div className="col-xl-4 col-lg-4 col-md-6">
                            <div className="case-style2__single">
                                <div className="img-box">
                                    <div className="inner">
                                        <img src="assets/images/resources/case-v2-1.jpg" alt="image"/>
                                    </div>
                                    <div className="overlay-content">
                                        <div className="category-box">
                                            <p>Management</p>
                                        </div>
                                        <div className="title-box">
                                            <h3><Link href="/case-single">Placements Driving <br/> Growth</Link></h3>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        
                        <div className="col-xl-4 col-lg-4 col-md-6">
                            <div className="case-style2__single">
                                <div className="img-box">
                                    <div className="inner">
                                        <img src="assets/images/resources/case-v2-2.jpg" alt="image"/>
                                    </div>
                                    <div className="overlay-content">
                                        <div className="category-box">
                                            <p>Industry Focus</p>
                                        </div>
                                        <div className="title-box">
                                            <h3><Link href="/case-single">Recuirtment & Selection <br/>Procedure</Link></h3>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        
                        <div className="col-xl-4 col-lg-4 col-md-6">
                            <div className="case-style2__single">
                                <div className="img-box">
                                    <div className="inner">
                                        <img src="assets/images/resources/case-v2-3.jpg" alt="image"/>
                                    </div>
                                    <div className="overlay-content">
                                        <div className="category-box">
                                            <p>Recruitment</p>
                                        </div>
                                        <div className="title-box">
                                            <h3><Link href="/case-single">Issues Faced by the <br/>Company</Link></h3>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                    </div>
                    <div className="case-style2__btn text-center">
                        <Link href="/case-masonry">
                            Explore More
                            <i className="icon-arrow-angle-pointing-to-right"></i>
                        </Link>
                    </div>
                </div>
            </section>

        </>
    )
}
