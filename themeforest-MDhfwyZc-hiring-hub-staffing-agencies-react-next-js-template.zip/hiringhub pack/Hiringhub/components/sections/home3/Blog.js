'use client'
import React from 'react'
import Link from "next/link"
import { Autoplay, Navigation, Pagination } from "swiper/modules"
import { Swiper, SwiperSlide } from "swiper/react"
const swiperOptions = {
    modules: [Autoplay, Pagination, Navigation],
    slidesPerView: 1,
    spaceBetween: 30,
    autoplay: {
        delay: 5000,
        disableOnInteraction: false,
    },
    loop: true,

    breakpoints: {
        320: {
            slidesPerView: 1,
            spaceBetween: 30,
        },
        575: {
            slidesPerView: 1,
            spaceBetween: 30,
        },
        767: {
            slidesPerView: 2,
            spaceBetween: 30,
        },
        991: {
            slidesPerView: 3,
            spaceBetween: 30,
        },
        1199: {
            slidesPerView: 4,
            spaceBetween: 30,
        },
        1900: {
            slidesPerView: 5,
            spaceBetween: 30,
        },
    }
}

export default function Blog() {
    return (
        <> 

            <section className="blog-style3">
                <div className="container">
                    <div className="sec-title withtext text-center">
                        <div className="sub-title">
                            <h4>News & Updates</h4>
                        </div>
                        <h2>Latest from our Blog Post</h2>
                        <div className="text">
                            <p>Long established fact that a reader will be distracted by the.</p>
                        </div>
                    </div>
                    <div className="row">
                        <div className="col-xl-12">
                        <Swiper {...swiperOptions} className="swiper-container case-style2-carousel">
                            <SwiperSlide>
                                <div className="blog-style3__single">
                                    <div className="author-info">
                                        <div className="author-info__img">
                                            <img src="assets/images/blog/blog-v1-author-info1.jpg" alt="image"/>
                                        </div>
                                        <div className="author-info__text">
                                            <h5>Boone Gerardo</h5>
                                            <ul className="clearfix">
                                                <li>
                                                    <Link href="#">Nov 15, 2025</Link>
                                                </li>
                                                <li>
                                                    <Link href="#">2 Comments</Link>
                                                </li>
                                            </ul>
                                        </div>
                                    </div>
                                    <div className="category-box">
                                        <p>News & Tips</p>
                                    </div>
                                    <div className="title-box">
                                        <h3>
                                            <Link href="/blog-single">
                                                Unlocking Success: Top<br/>Eight Tips for Leadership<br/>Recruitment.
                                            </Link>
                                        </h3>
                                    </div>
                                    <div className="text">
                                        <p>Cases are perfectly simple and easy to<br/>distinguish in a free hour...</p>
                                    </div>
                                    <div className="blog-style3__single-btn">
                                        <div className="left">
                                            <p>2 Mins Read</p>
                                        </div>
                                        <div className="right">
                                            <Link href="/blog-single"><span className="icon-right-arrow-1"></span></Link>
                                            <div className="overlay-btn">
                                                <Link href="/blog-single">Read More
                                                    <span className="icon-arrow-angle-pointing-to-right"></span>
                                                </Link>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </SwiperSlide>
                            <SwiperSlide>
                                <div className="blog-style3__single">
                                    <div className="author-info">
                                        <div className="author-info__img">
                                            <img src="assets/images/blog/blog-v1-author-info2.jpg" alt="image"/>
                                        </div>
                                        <div className="author-info__text">
                                            <h5>Harley Reuban</h5>
                                            <ul className="clearfix">
                                                <li>
                                                    <Link href="#">Oct 24, 2025</Link>
                                                </li>
                                                <li>
                                                    <Link href="#">3 Comments</Link>
                                                </li>
                                            </ul>
                                        </div>
                                    </div>
                                    <div className="category-box">
                                        <p>Job Seekers</p>
                                    </div>
                                    <div className="title-box">
                                        <h3>
                                            <Link href="/blog-single">
                                                Navigating Remote Work:<br/>Six Tips for Employers &<br/>Employees.
                                            </Link>
                                        </h3>
                                    </div>
                                    <div className="text">
                                        <p>Choice is untrammelled when nothing to<br/>able to do what we like best...</p>
                                    </div>
                                    <div className="blog-style3__single-btn">
                                        <div className="left">
                                            <p>3 Mins Read</p>
                                        </div>
                                        <div className="right">
                                            <Link href="/blog-single"><span className="icon-right-arrow-1"></span></Link>
                                            <div className="overlay-btn">
                                                <Link href="/blog-single">Read More
                                                    <span className="icon-arrow-angle-pointing-to-right"></span>
                                                </Link>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </SwiperSlide>
                            <SwiperSlide>
                                <div className="blog-style3__single">
                                    <div className="author-info">
                                        <div className="author-info__img">
                                            <img src="assets/images/blog/blog-v1-author-info3.jpg" alt="image"/>
                                        </div>
                                        <div className="author-info__text">
                                            <h5>Dahlia Bianca</h5>
                                            <ul className="clearfix">
                                                <li>
                                                    <Link href="#">Oct 10, 2025</Link>
                                                </li>
                                                <li>
                                                    <Link href="#">8 Comments</Link>
                                                </li>
                                            </ul>
                                        </div>
                                    </div>
                                    <div className="category-box">
                                        <p>Human Resource</p>
                                    </div>
                                    <div className="title-box">
                                        <h3>
                                            <Link href="/blog-single">
                                                Hiringhub Chosen for<br/>Crown Commercial's Staff-<br/>ing Services.
                                            </Link>
                                        </h3>
                                    </div>
                                    <div className="text">
                                        <p>Duty or the obligations of business it will<br/>frequently occur...</p>
                                    </div>
                                    <div className="blog-style3__single-btn">
                                        <div className="left">
                                            <p>5 Mins Read</p>
                                        </div>
                                        <div className="right">
                                            <Link href="/blog-single"><span className="icon-right-arrow-1"></span></Link>
                                            <div className="overlay-btn">
                                                <Link href="/blog-single">Read More
                                                    <span className="icon-arrow-angle-pointing-to-right"></span>
                                                </Link>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </SwiperSlide>
                            <SwiperSlide>
                                <div className="blog-style3__single">
                                    <div className="author-info">
                                        <div className="author-info__img">
                                            <img src="assets/images/blog/blog-v1-author-info3.jpg" alt="image"/>
                                        </div>
                                        <div className="author-info__text">
                                            <h5>Dahlia Bianca</h5>
                                            <ul className="clearfix">
                                                <li>
                                                    <Link href="#">Sep 12, 2025 </Link>
                                                </li>
                                                <li>
                                                    <Link href="#">4 Comments</Link>
                                                </li>
                                            </ul>
                                        </div>
                                    </div>
                                    <div className="category-box">
                                        <p>Human Resource</p>
                                    </div>
                                    <div className="title-box">
                                        <h3>
                                            <Link href="/blog-single">
                                                Utilizing Technology in the<br/>Hiring Process.
                                            </Link>
                                        </h3>
                                    </div>
                                    <div className="text text-style2">
                                        <p>Holds in these matters to this principle of<br/>selection rejects pleasures...</p>
                                    </div>
                                    <div className="blog-style3__single-btn">
                                        <div className="left">
                                            <p>5 Mins Read</p>
                                        </div>
                                        <div className="right">
                                            <Link href="/blog-single"><span className="icon-right-arrow-1"></span></Link>
                                            <div className="overlay-btn">
                                                <Link href="/blog-single">Read More
                                                    <span className="icon-arrow-angle-pointing-to-right"></span>
                                                </Link>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </SwiperSlide>
                            <SwiperSlide>
                                <div className="blog-style3__single">
                                    <div className="author-info">
                                        <div className="author-info__img">
                                            <img src="assets/images/blog/blog-v1-author-info1.jpg" alt="image"/>
                                        </div>
                                        <div className="author-info__text">
                                            <h5>Boone Gerardo</h5>
                                            <ul className="clearfix">
                                                <li>
                                                    <Link href="#">Aug 28, 2025</Link>
                                                </li>
                                                <li>
                                                    <Link href="#">2 Comments</Link>
                                                </li>
                                            </ul>
                                        </div>
                                    </div>
                                    <div className="category-box">
                                        <p>News & Tips</p>
                                    </div>
                                    <div className="title-box">
                                        <h3>
                                            <Link href="/blog-single">
                                                Navigating Legalities in<br/>Staffing and Hiring
                                            </Link>
                                        </h3>
                                    </div>
                                    <div className="text text-style2">
                                        <p>Those who fail in their duty through<br/>weakness of will, which is the same...
                                        </p>
                                    </div>
                                    <div className="blog-style3__single-btn">
                                        <div className="left">
                                            <p>2 Mins Read</p>
                                        </div>
                                        <div className="right">
                                            <Link href="/blog-single"><span className="icon-right-arrow-1"></span></Link>
                                            <div className="overlay-btn">
                                                <Link href="/blog-single">Read More
                                                    <span className="icon-arrow-angle-pointing-to-right"></span>
                                                </Link>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </SwiperSlide>
                            <SwiperSlide>
                                <div className="blog-style3__single">
                                    <div className="author-info">
                                        <div className="author-info__img">
                                            <img src="assets/images/blog/blog-v1-author-info1.jpg" alt="image"/>
                                        </div>
                                        <div className="author-info__text">
                                            <h5>Boone Gerardo</h5>
                                            <ul className="clearfix">
                                                <li>
                                                    <Link href="#">Nov 15, 2025</Link>
                                                </li>
                                                <li>
                                                    <Link href="#">2 Comments</Link>
                                                </li>
                                            </ul>
                                        </div>
                                    </div>
                                    <div className="category-box">
                                        <p>News & Tips</p>
                                    </div>
                                    <div className="title-box">
                                        <h3>
                                            <Link href="/blog-single">
                                                Unlocking Success: Top<br/>Eight Tips for Leadership<br/>Recruitment.
                                            </Link>
                                        </h3>
                                    </div>
                                    <div className="text">
                                        <p>Cases are perfectly simple and easy to<br/>distinguish in a free hour...</p>
                                    </div>
                                    <div className="blog-style3__single-btn">
                                        <div className="left">
                                            <p>2 Mins Read</p>
                                        </div>
                                        <div className="right">
                                            <Link href="/blog-single"><span className="icon-right-arrow-1"></span></Link>
                                            <div className="overlay-btn">
                                                <Link href="/blog-single">Read More
                                                    <span className="icon-arrow-angle-pointing-to-right"></span>
                                                </Link>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </SwiperSlide>
                            <SwiperSlide>
                                <div className="blog-style3__single">
                                    <div className="author-info">
                                        <div className="author-info__img">
                                            <img src="assets/images/blog/blog-v1-author-info2.jpg" alt="image"/>
                                        </div>
                                        <div className="author-info__text">
                                            <h5>Harley Reuban</h5>
                                            <ul className="clearfix">
                                                <li>
                                                    <Link href="#">Oct 24, 2025</Link>
                                                </li>
                                                <li>
                                                    <Link href="#">3 Comments</Link>
                                                </li>
                                            </ul>
                                        </div>
                                    </div>
                                    <div className="category-box">
                                        <p>Job Seekers</p>
                                    </div>
                                    <div className="title-box">
                                        <h3>
                                            <Link href="/blog-single">
                                                Navigating Remote Work:<br/>Six Tips for Employers &<br/>Employees.
                                            </Link>
                                        </h3>
                                    </div>
                                    <div className="text">
                                        <p>Choice is untrammelled when nothing to<br/>able to do what we like best...</p>
                                    </div>
                                    <div className="blog-style3__single-btn">
                                        <div className="left">
                                            <p>3 Mins Read</p>
                                        </div>
                                        <div className="right">
                                            <Link href="/blog-single"><span className="icon-right-arrow-1"></span></Link>
                                            <div className="overlay-btn">
                                                <Link href="/blog-single">Read More
                                                    <span className="icon-arrow-angle-pointing-to-right"></span>
                                                </Link>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </SwiperSlide>
                            <SwiperSlide>
                                <div className="blog-style3__single">
                                    <div className="author-info">
                                        <div className="author-info__img">
                                            <img src="assets/images/blog/blog-v1-author-info3.jpg" alt="image"/>
                                        </div>
                                        <div className="author-info__text">
                                            <h5>Dahlia Bianca</h5>
                                            <ul className="clearfix">
                                                <li>
                                                    <Link href="#">Oct 10, 2025</Link>
                                                </li>
                                                <li>
                                                    <Link href="#">8 Comments</Link>
                                                </li>
                                            </ul>
                                        </div>
                                    </div>
                                    <div className="category-box">
                                        <p>Human Resource</p>
                                    </div>
                                    <div className="title-box">
                                        <h3>
                                            <Link href="/blog-single">
                                                Hiringhub Chosen for<br/>Crown Commercial's Staff-<br/>ing Services.
                                            </Link>
                                        </h3>
                                    </div>
                                    <div className="text">
                                        <p>Duty or the obligations of business it will<br/>frequently occur...</p>
                                    </div>
                                    <div className="blog-style3__single-btn">
                                        <div className="left">
                                            <p>5 Mins Read</p>
                                        </div>
                                        <div className="right">
                                            <Link href="/blog-single"><span className="icon-right-arrow-1"></span></Link>
                                            <div className="overlay-btn">
                                                <Link href="/blog-single">Read More
                                                    <span className="icon-arrow-angle-pointing-to-right"></span>
                                                </Link>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </SwiperSlide>
                            <SwiperSlide>
                                <div className="blog-style3__single">
                                    <div className="author-info">
                                        <div className="author-info__img">
                                            <img src="assets/images/blog/blog-v1-author-info3.jpg" alt="image"/>
                                        </div>
                                        <div className="author-info__text">
                                            <h5>Dahlia Bianca</h5>
                                            <ul className="clearfix">
                                                <li>
                                                    <Link href="#">Sep 12, 2025 </Link>
                                                </li>
                                                <li>
                                                    <Link href="#">4 Comments</Link>
                                                </li>
                                            </ul>
                                        </div>
                                    </div>
                                    <div className="category-box">
                                        <p>Human Resource</p>
                                    </div>
                                    <div className="title-box">
                                        <h3>
                                            <Link href="/blog-single">
                                                Utilizing Technology in the<br/>Hiring Process.
                                            </Link>
                                        </h3>
                                    </div>
                                    <div className="text text-style2">
                                        <p>Holds in these matters to this principle of<br/>selection rejects pleasures...</p>
                                    </div>
                                    <div className="blog-style3__single-btn">
                                        <div className="left">
                                            <p>5 Mins Read</p>
                                        </div>
                                        <div className="right">
                                            <Link href="/blog-single"><span className="icon-right-arrow-1"></span></Link>
                                            <div className="overlay-btn">
                                                <Link href="/blog-single">Read More
                                                    <span className="icon-arrow-angle-pointing-to-right"></span>
                                                </Link>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </SwiperSlide>
                            <SwiperSlide>
                                <div className="blog-style3__single">
                                    <div className="author-info">
                                        <div className="author-info__img">
                                            <img src="assets/images/blog/blog-v1-author-info1.jpg" alt="image"/>
                                        </div>
                                        <div className="author-info__text">
                                            <h5>Boone Gerardo</h5>
                                            <ul className="clearfix">
                                                <li>
                                                    <Link href="#">Aug 28, 2025</Link>
                                                </li>
                                                <li>
                                                    <Link href="#">2 Comments</Link>
                                                </li>
                                            </ul>
                                        </div>
                                    </div>
                                    <div className="category-box">
                                        <p>News & Tips</p>
                                    </div>
                                    <div className="title-box">
                                        <h3>
                                            <Link href="/blog-single">
                                                Navigating Legalities in<br/>Staffing and Hiring
                                            </Link>
                                        </h3>
                                    </div>
                                    <div className="text text-style2">
                                        <p>Those who fail in their duty through<br/>weakness of will, which is the same...
                                        </p>
                                    </div>
                                    <div className="blog-style3__single-btn">
                                        <div className="left">
                                            <p>2 Mins Read</p>
                                        </div>
                                        <div className="right">
                                            <Link href="/blog-single"><span className="icon-right-arrow-1"></span></Link>
                                            <div className="overlay-btn">
                                                <Link href="/blog-single">Read More
                                                    <span className="icon-arrow-angle-pointing-to-right"></span>
                                                </Link>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </SwiperSlide>
                        </Swiper>
                        </div>
                    </div>
                </div>
            </section>

        </>
    )
}
