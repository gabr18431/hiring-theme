'use client'
import React from 'react'
import { useState } from "react"

export default function Featurs() {
    const [activeIndex, setActiveIndex] = useState(1)
        const handleOnClick = (index) => {
            setActiveIndex(index)
        }
    return (
        <> 

            <section className="featurs-style1">
                <div className="container">
                    <div className="sec-title withtext text-center">
                        <div className="sub-title">
                            <h4>Working With Us</h4>
                        </div>
                        <h2>We Know The Way To Success</h2>
                        <div className="text">
                            <p>Long established fact that a reader will be distracted</p>
                        </div>
                    </div>
                    <div className="features-style1__inner tab-box-style1">

                        <div className="features-style1-tab__button">
                            <ul className="tabs-button-box clearfix">
                                <li onClick={() => handleOnClick(1)} className={activeIndex === 1 ? "tab-btn-item active-btn" : "tab-btn-item"}>
                                    <span>01.Benefits</span>
                                </li>
                                <li onClick={() => handleOnClick(2)} className={activeIndex === 2 ? "tab-btn-item active-btn" : "tab-btn-item"}>
                                    <span>02. HR Advice</span>
                                </li>
                                <li onClick={() => handleOnClick(3)} className={activeIndex === 3 ? "tab-btn-item active-btn" : "tab-btn-item"}>
                                    <span>03. HR Audit</span>
                                </li>
                            </ul>
                        </div>

                        <div className="tabs-content-box">
                            <div className="row">
                                <div className="col-xl-12">

                                    
                                    <div className={activeIndex === 1 ? "tab-content-box-item active-tab" : "tab-content-box-item"}>
                                        <div className="features-style1__content-tab-item">
                                            <div className="features-style1__single">
                                                <div className="row">
                                                    <div className="col-xl-6">
                                                        <div className="features-style1__img-tab-item">
                                                            <img src="assets/images/resources/features-v1-img1.jpg"
                                                                alt="image"/>
                                                        </div>
                                                    </div>

                                                    <div className="col-xl-6">
                                                        <div className="content-box">
                                                            <div className="title-box">
                                                                <h2>Empowering Businesses to<br/>Greater Heights</h2>
                                                                <p>
                                                                    Every pleasure is to be welcomed and every pain avoided.
                                                                    But in certain circumstances and owing.
                                                                </p>
                                                            </div>
                                                            <div className="list-item">
                                                                <ul className="clearfix">
                                                                    <li>
                                                                        <div className="icon">
                                                                            <i className="icon-check"></i>
                                                                        </div>
                                                                        <div className="text">
                                                                            <p>Cost-Effective Services</p>
                                                                        </div>
                                                                    </li>
                                                                    <li>
                                                                        <div className="icon">
                                                                            <i className="icon-check"></i>
                                                                        </div>
                                                                        <div className="text">
                                                                            <p>Helps Reduce Business Risks</p>
                                                                        </div>
                                                                    </li>
                                                                    <li>
                                                                        <div className="icon">
                                                                            <i className="icon-check"></i>
                                                                        </div>
                                                                        <div className="text">
                                                                            <p>Management of Employee Performance</p>
                                                                        </div>
                                                                    </li>
                                                                    <li>
                                                                        <div className="icon">
                                                                            <i className="icon-check"></i>
                                                                        </div>
                                                                        <div className="text">
                                                                            <p>Increasing Company’s Agility</p>
                                                                        </div>
                                                                    </li>
                                                                </ul>
                                                            </div>
                                                            <div className="btn-box">
                                                                <a className="btn-one" href="about.html">
                                                                    <span className="txt">Learn More</span>
                                                                </a>
                                                            </div>

                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                    
                                    <div className={activeIndex === 2 ? "tab-content-box-item active-tab" : "tab-content-box-item"}>
                                        <div className="features-style1__content-tab-item">
                                            <div className="features-style1__single">
                                                <div className="row">
                                                    <div className="col-xl-6">
                                                        <div className="features-style1__img-tab-item">
                                                            <img src="assets/images/resources/features-v1-img2.jpg"
                                                                alt="image"/>
                                                        </div>
                                                    </div>

                                                    <div className="col-xl-6">
                                                        <div className="content-box">
                                                            <div className="title-box">
                                                                <h2>Empowering Businesses to<br/>Greater Heights</h2>
                                                                <p>
                                                                    Every pleasure is to be welcomed and every pain avoided.
                                                                    But in certain circumstances and owing.
                                                                </p>
                                                            </div>
                                                            <div className="list-item">
                                                                <ul className="clearfix">
                                                                    <li>
                                                                        <div className="icon">
                                                                            <i className="icon-check"></i>
                                                                        </div>
                                                                        <div className="text">
                                                                            <p>Cost-Effective Services</p>
                                                                        </div>
                                                                    </li>
                                                                    <li>
                                                                        <div className="icon">
                                                                            <i className="icon-check"></i>
                                                                        </div>
                                                                        <div className="text">
                                                                            <p>Helps Reduce Business Risks</p>
                                                                        </div>
                                                                    </li>
                                                                    <li>
                                                                        <div className="icon">
                                                                            <i className="icon-check"></i>
                                                                        </div>
                                                                        <div className="text">
                                                                            <p>Management of Employee Performance</p>
                                                                        </div>
                                                                    </li>
                                                                    <li>
                                                                        <div className="icon">
                                                                            <i className="icon-check"></i>
                                                                        </div>
                                                                        <div className="text">
                                                                            <p>Increasing Company’s Agility</p>
                                                                        </div>
                                                                    </li>
                                                                </ul>
                                                            </div>
                                                            <div className="btn-box">
                                                                <a className="btn-one" href="about.html">
                                                                    <span className="txt">Learn More</span>
                                                                </a>
                                                            </div>

                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                    
                                    <div className={activeIndex === 3 ? "tab-content-box-item active-tab" : "tab-content-box-item"}>
                                        <div className="features-style1__content-tab-item">
                                            <div className="features-style1__single">
                                                <div className="row">
                                                    <div className="col-xl-6">
                                                        <div className="features-style1__img-tab-item">
                                                            <img src="assets/images/resources/features-v1-img3.jpg"
                                                                alt="image"/>
                                                        </div>
                                                    </div>
                                                    <div className="col-xl-6">
                                                        <div className="content-box">
                                                            <div className="title-box">
                                                                <h2>Empowering Businesses to<br/>Greater Heights</h2>
                                                                <p>
                                                                    Every pleasure is to be welcomed and every pain avoided.
                                                                    But in certain circumstances and owing.
                                                                </p>
                                                            </div>
                                                            <div className="list-item">
                                                                <ul className="clearfix">
                                                                    <li>
                                                                        <div className="icon">
                                                                            <i className="icon-check"></i>
                                                                        </div>
                                                                        <div className="text">
                                                                            <p>Cost-Effective Services</p>
                                                                        </div>
                                                                    </li>
                                                                    <li>
                                                                        <div className="icon">
                                                                            <i className="icon-check"></i>
                                                                        </div>
                                                                        <div className="text">
                                                                            <p>Helps Reduce Business Risks</p>
                                                                        </div>
                                                                    </li>
                                                                    <li>
                                                                        <div className="icon">
                                                                            <i className="icon-check"></i>
                                                                        </div>
                                                                        <div className="text">
                                                                            <p>Management of Employee Performance</p>
                                                                        </div>
                                                                    </li>
                                                                    <li>
                                                                        <div className="icon">
                                                                            <i className="icon-check"></i>
                                                                        </div>
                                                                        <div className="text">
                                                                            <p>Increasing Company’s Agility</p>
                                                                        </div>
                                                                    </li>
                                                                </ul>
                                                            </div>
                                                            <div className="btn-box">
                                                                <a className="btn-one" href="about.html">
                                                                    <span className="txt">Learn More</span>
                                                                </a>
                                                            </div>

                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                </div>
                            </div>
                        </div>

                    </div>
                </div>
            </section>

        </>
    )
}
