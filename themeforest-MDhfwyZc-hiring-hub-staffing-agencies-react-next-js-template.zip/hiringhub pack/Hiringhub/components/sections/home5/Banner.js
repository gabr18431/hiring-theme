'use client'
import React from 'react'
import Link from "next/link"
import { Autoplay, Navigation, Pagination } from "swiper/modules"
import { Swiper, SwiperSlide } from "swiper/react"
const swiperOptions = {
    modules: [Autoplay, Pagination, Navigation],
    slidesPerView: 1,
    spaceBetween: 30,
    autoplay: {
        delay: 5000,
        disableOnInteraction: false,
    },
    loop: true,

    // Navigation
    navigation: {
        nextEl: '.swiper-button-prev',
        prevEl: '.swiper-button-next',
    },

    // Pagination
    pagination: {
        el: '.swiper-pagination',
        clickable: true,
    },

    breakpoints: {
        320: {
            slidesPerView: 1,
            spaceBetween: 30,
        },
        575: {
            slidesPerView: 1,
            spaceBetween: 30,
        },
        767: {
            slidesPerView: 1,
            spaceBetween: 30,
        },
        991: {
            slidesPerView: 1,
            spaceBetween: 30,
        },
        1199: {
            slidesPerView: 1,
            spaceBetween: 30,
        },
        1350: {
            slidesPerView: 1,
            spaceBetween: 30,
        },
    }
}

export default function Banner() {
    return (
        <> 

            <section className="main-slider main-slider-style3">
            <Swiper {...swiperOptions} className="swiper-container thm-swiper__slider">
                <SwiperSlide>
                    <div className="swiper-slide">
                        <div className="image-layer" style={{ backgroundImage: "url(assets/images/slides/slide-v3-1.jpg)" }}>
                        </div>
                        <div className="main-slider-style3__bg"
                            style={{ backgroundImage: "url(assets/images/shapes/main-slider-style3-bg.png)" }}></div>
                        <div className="container">
                            <div className="main-slider-content">
                                <div className="main-slider-content__inner">
                                    <div className="big-title">
                                        <h2>
                                            Finding the Right<br/> Person For the Right Job
                                        </h2>
                                    </div>
                                    <div className="text">
                                        <p>
                                            Trouble that are bound to ensue and equal that shrinking.
                                        </p>
                                    </div>
                                    <div className="btn-box-right">
                                        <Link href="/about"><i className="icon-right-arrow"></i></Link>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </SwiperSlide>
                <SwiperSlide>
                    <div className="swiper-slide">
                        <div className="image-layer" style={{ backgroundImage: "url(assets/images/slides/slide-v3-2.jpg)" }}>
                        </div>
                        <div className="main-slider-style3__bg"
                            style={{ backgroundImage: "url(assets/images/shapes/main-slider-style3-bg.png)" }}></div>
                        <div className="container">
                            <div className="main-slider-content">
                                <div className="main-slider-content__inner">
                                    <div className="big-title">
                                        <h2>
                                            Hiring Competent<br/> People For The Workplace
                                        </h2>
                                    </div>
                                    <div className="text">
                                        <p>
                                            Charms of pleasure of the moment, so blinded by desire.
                                        </p>
                                    </div>
                                    <div className="btn-box-right">
                                        <Link href="/about"><i className="icon-right-arrow"></i></Link>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </SwiperSlide>
                <SwiperSlide>
                    <div className="swiper-slide">
                        <div className="image-layer" style={{ backgroundImage: "url(assets/images/slides/slide-v3-3.jpg)" }}>
                        </div>
                        <div className="main-slider-style3__bg"
                            style={{ backgroundImage: "url(assets/images/shapes/main-slider-style3-bg.png)" }}></div>
                        <div className="container">
                            <div className="main-slider-content">
                                <div className="main-slider-content__inner">
                                    <div className="big-title">
                                        <h2>
                                            The Right Candidate<br/> Should Send Their Resume
                                        </h2>
                                    </div>
                                    <div className="text">
                                        <p>
                                            Trouble that are bound to ensue and equal that shrinking.
                                        </p>
                                    </div>
                                    <div className="btn-box-right">
                                        <Link href="/about"><i className="icon-right-arrow"></i></Link>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </SwiperSlide>

                <div className="swiper-pagination" id="main-slider-pagination"></div>
                <div className="main-slider__nav">
                    <div className="swiper-button-prev" id="main-slider__swiper-button-next">
                        <i className="icon-left-arrow-angle-big-gross-symbol left"></i>
                    </div>
                    <div className="swiper-button-next" id="main-slider__swiper-button-prev">
                        <i className="icon-arrow-angle-pointing-to-right right"></i>
                    </div>
                </div>

                <div className="slider-style3-highlights">
                    <div className="container">
                        <div className="row">

                            <div className="col-xl-4 col-lg-4 col-md-6">
                                <div className="slider-style3-highlights-single">
                                    <div className="icon-box">
                                        <img src="assets/images/icon/highlights/slider-style3-highlights-icon-1.png"
                                            alt="icon"/>
                                    </div>
                                    <div className="title-box">
                                        <h3><Link href="/about">Reduce Hiring <br/>Risks</Link></h3>
                                    </div>
                                    <div className="text">
                                        <p>Denounce with righteous indignation & men who are so beguiled.</p>
                                    </div>
                                    <div className="count-box">
                                        01
                                    </div>
                                </div>
                            </div>
                            
                            <div className="col-xl-4 col-lg-4 col-md-6">
                                <div className="slider-style3-highlights-single">
                                    <div className="icon-box">
                                        <img src="assets/images/icon/highlights/slider-style3-highlights-icon-2.png"
                                            alt="icon"/>
                                    </div>
                                    <div className="title-box">
                                        <h3><Link href="/about">Increase <br/>Efficiencies</Link></h3>
                                    </div>
                                    <div className="text">
                                        <p>Power of choice is untrammelled when nothing prevents our being to do.</p>
                                    </div>
                                    <div className="count-box">
                                        02
                                    </div>
                                </div>
                            </div>
                            
                            <div className="col-xl-4 col-lg-4 col-md-6">
                                <div className="slider-style3-highlights-single">
                                    <div className="icon-box">
                                        <img src="assets/images/icon/highlights/slider-style3-highlights-icon-3.png"
                                            alt="icon"/>
                                    </div>
                                    <div className="title-box">
                                        <h3><Link href="/about">Deeper Talent <br/>Pools</Link></h3>
                                    </div>
                                    <div className="text">
                                        <p>Obligations business will fail frequently occur that pleasures.</p>
                                    </div>
                                    <div className="count-box">
                                        03
                                    </div>
                                </div>
                            </div>

                        </div>
                    </div>
                </div>
            </Swiper>
            </section>

        </>
    )
}
