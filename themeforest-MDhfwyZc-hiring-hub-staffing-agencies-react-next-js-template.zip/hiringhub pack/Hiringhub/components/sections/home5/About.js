'use client'
import React from 'react'
import { useState } from "react"
import Link from "next/link"

export default function About() {
    const [activeIndex, setActiveIndex] = useState(1)
        const handleOnClick = (index) => {
            setActiveIndex(index)
        }
    return (
        <> 

            <section className="about-style4">
                <div className="container">
                    <div className="about-style4__inner">
                        <div className="about-style4__inner-bg"
                            style={{ backgroundImage: "url(assets/images/backgrounds/about-v4-img1.jpg)" }}></div>


                        <div className="about-style4__tab">

                            <div className="about-style4-tab__button">
                                <ul className="tabs-button-box clearfix">
                                    <li onClick={() => handleOnClick(1)} className={activeIndex === 1 ? "tab-btn-item active-btn" : "tab-btn-item"}>
                                        <h4>Story <span className="icon-right-arrow-1"></span></h4>
                                    </li>
                                    <li onClick={() => handleOnClick(2)} className={activeIndex === 2 ? "tab-btn-item active-btn" : "tab-btn-item"}>
                                        <h4>Statements <span className="icon-right-arrow-1"></span></h4>
                                    </li>
                                    <li onClick={() => handleOnClick(3)} className={activeIndex === 3 ? "tab-btn-item active-btn" : "tab-btn-item"}>
                                        <h4>Leadership <span className="icon-right-arrow-1"></span></h4>
                                    </li>
                                    <li onClick={() => handleOnClick(4)} className={activeIndex === 4 ? "tab-btn-item active-btn" : "tab-btn-item"}>
                                        <h4>Awards <span className="icon-right-arrow-1"></span></h4>
                                    </li>
                                    <li onClick={() => handleOnClick(5)} className={activeIndex === 5 ? "tab-btn-item active-btn" : "tab-btn-item"}>
                                        <h4>Our Partners <span className="icon-right-arrow-1"></span></h4>
                                    </li>
                                </ul>
                                <div className="years-experience">
                                    <div className="left">09+</div>
                                    <div className="right">
                                        <p>Years<br/> Experience</p>
                                    </div>
                                </div>
                            </div>

                            <div className="tabs-content-box">
                                <div className="about-style4__shape"
                                    style={{ backgroundImage: "url(assets/images/shapes/about-v4-shape1.png)" }}>
                                </div>


                                
                                <div className={activeIndex === 1 ? "tab-content-box-item active-tab" : "tab-content-box-item"}>
                                    <div className="about-style4__content-tab-item">
                                        <div className="about-style4__content-tab-item__inner">
                                            <div className="title-box">
                                                <h3>Our Story</h3>
                                                <p>
                                                    Must explain too you how all this mistaken idea of denouncing pleasures
                                                    praising pain was born complete account of the system.
                                                </p>
                                            </div>
                                            <div className="btn-box">
                                                <Link href="/about">
                                                    Explore More
                                                    <i className="icon-arrow-angle-pointing-to-right"></i>
                                                </Link>
                                            </div>
                                        </div>
                                    </div>
                                </div>


                                <div className={activeIndex === 2 ? "tab-content-box-item active-tab" : "tab-content-box-item"}>
                                    <div className="about-style4__content-tab-item">
                                        <div className="about-style4__content-tab-item__inner">
                                            <div className="title-box">
                                                <h3>Statements</h3>
                                                <p>
                                                    Must explain too you how all this mistaken idea of denouncing pleasures
                                                    praising pain was born complete account of the system.
                                                </p>
                                            </div>
                                            <div className="btn-box">
                                                <Link href="/about">
                                                    Explore More
                                                    <i className="icon-arrow-angle-pointing-to-right"></i>
                                                </Link>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                              
                                <div className={activeIndex === 3 ? "tab-content-box-item active-tab" : "tab-content-box-item"}>
                                    <div className="about-style4__content-tab-item">
                                        <div className="about-style4__content-tab-item__inner">
                                            <div className="title-box">
                                                <h3>Leadership</h3>
                                                <p>
                                                    Must explain too you how all this mistaken idea of denouncing pleasures
                                                    praising pain was born complete account of the system.
                                                </p>
                                            </div>
                                            <div className="btn-box">
                                                <Link href="/about">
                                                    Explore More
                                                    <i className="icon-arrow-angle-pointing-to-right"></i>
                                                </Link>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                
                                <div className={activeIndex === 4 ? "tab-content-box-item active-tab" : "tab-content-box-item"}>
                                    <div className="about-style4__content-tab-item">
                                        <div className="about-style4__content-tab-item__inner">
                                            <div className="title-box">
                                                <h3>Awards</h3>
                                                <p>
                                                    Must explain too you how all this mistaken idea of denouncing pleasures
                                                    praising pain was born complete account of the system.
                                                </p>
                                            </div>
                                            <div className="btn-box">
                                                <Link href="/about">
                                                    Explore More
                                                    <i className="icon-arrow-angle-pointing-to-right"></i>
                                                </Link>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                
                                <div className={activeIndex === 5 ? "tab-content-box-item active-tab" : "tab-content-box-item"}>
                                    <div className="about-style4__content-tab-item">
                                        <div className="about-style4__content-tab-item__inner">
                                            <div className="title-box">
                                                <h3>Our Partners</h3>
                                                <p>
                                                    Must explain too you how all this mistaken idea of denouncing pleasures
                                                    praising pain was born complete account of the system.
                                                </p>
                                            </div>
                                            <div className="btn-box">
                                                <Link href="/about">
                                                    Explore More
                                                    <i className="icon-arrow-angle-pointing-to-right"></i>
                                                </Link>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                            </div>
                        </div>

                    </div>
                </div>
            </section>

        </>
    )
}
