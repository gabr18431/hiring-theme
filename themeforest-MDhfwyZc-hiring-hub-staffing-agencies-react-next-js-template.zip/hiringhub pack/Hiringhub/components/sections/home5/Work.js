'use client'
import React from 'react'
import Link from "next/link"

export default function Work() {
    return (
        <> 

            <section className="how-its-work-style2">
                <div className="container">

                    <div className="sec-title withtext text-center">
                        <div className="sub-title">
                            <h4>How It’s Possible</h4>
                        </div>
                        <h2>Important Three Steps of Staffy</h2>
                        <div className="text">
                            <p>
                                Long established fact that a reader will be distracted by the<br/> readable content of a
                                page.
                            </p>
                        </div>
                    </div>

                    <ul className="row">

                        <li className="col-xl-4 col-lg-4 col-md-6">
                            <div className="how-its-work-style2__single text-center">
                                <div className="how-its-work-style2__single-shape1">
                                    <img src="assets/images/shapes/how-its-work-v2-shape1.png" alt="shape"/>
                                </div>
                                <div className="icon-box">
                                    <img src="assets/images/icon/how-its-work/how-its-work-v2-icon1.png" alt="icon"/>
                                </div>
                                <div className="count-box">
                                    <h4>01</h4>
                                </div>
                                <div className="title-box">
                                    <h3><Link href="/solution01-temporary-stafing">Job Analysis</Link></h3>
                                    <p>That they cannot foresee the pain<br/>trouble that are bound ensue equal blame<br/>of
                                        business .</p>
                                </div>
                            </div>
                        </li>
                        
                        <li className="col-xl-4 col-lg-4 col-md-6">
                            <div className="how-its-work-style2__single text-center">
                                <div className="how-its-work-style2__single-shape2">
                                    <img src="assets/images/shapes/how-its-work-v2-shape2.png" alt="shape"/>
                                </div>
                                <div className="icon-box">
                                    <img src="assets/images/icon/how-its-work/how-its-work-v2-icon2.png" alt="icon"/>
                                </div>
                                <div className="count-box count-box2">
                                    <h4>02</h4>
                                </div>
                                <div className="title-box">
                                    <h3><Link href="/solution01-temporary-stafing">Applicant Review</Link></h3>
                                    <p>Power of choiced is untrammelled<br/>when nothing prevents claims off duty or
                                        the<br/>it will frequently occur that.</p>
                                </div>
                            </div>
                        </li>
                        
                        <li className="col-xl-4 col-lg-4 col-md-6">
                            <div className="how-its-work-style2__single text-center">
                                <div className="icon-box">
                                    <img src="assets/images/icon/how-its-work/how-its-work-v2-icon3.png" alt="icon"/>
                                </div>
                                <div className="count-box">
                                    <h4>03</h4>
                                </div>
                                <div className="title-box">
                                    <h3><Link href="/solution01-temporary-stafing">Job Place & Check</Link></h3>
                                    <p>Have to be repudiated & annoyances<br/>accepted. The wise man therefore
                                        always<br/>holds in these matters.</p>
                                </div>
                            </div>
                        </li>

                    </ul>
                </div>
            </section>

        </>
    )
}
