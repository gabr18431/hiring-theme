'use client'
import React from 'react'
import Link from "next/link"
import CounterUp from "@/components/elements/CounterUp"
import { Autoplay, Navigation, Pagination } from "swiper/modules"
import { Swiper, SwiperSlide } from "swiper/react"
const swiperOptions = {
    modules: [Autoplay, Pagination, Navigation],
    slidesPerView: 1,
    spaceBetween: 30,
    autoplay: {
        delay: 5000,
        disableOnInteraction: false,
    },
    loop: true,

    // Navigation
    navigation: {
        nextEl: '.swiper-button-prev',
        prevEl: '.swiper-button-next',
    },

    breakpoints: {
        320: {
            slidesPerView: 1,
            spaceBetween: 30,
        },
        575: {
            slidesPerView: 1,
            spaceBetween: 30,
        },
        767: {
            slidesPerView: 1,
            spaceBetween: 30,
        },
        991: {
            slidesPerView: 1,
            spaceBetween: 30,
        },
        1199: {
            slidesPerView: 2,
            spaceBetween: 30,
        },
        1350: {
            slidesPerView: 2,
            spaceBetween: 30,
        },
    }
}

export default function Testimonials() {
    return (
        <> 

            <section className="testimonial-style1">
                <div className="container">
                    <div className="sec-title">
                        <div className="sub-title">
                            <h4>Testimonials</h4>
                        </div>
                        <h2>Leading in Client Satisfaction</h2>
                    </div>
                    <div className='testimonial-content'>
                        <div className="row">
                            <div className="col-xl-12">
                                <Swiper {...swiperOptions} className="swiper-container testimonial-style1-carousel">
                                    <SwiperSlide>
                                        <div className="testimonial-style1__single">
                                            <div className="overlay-icon">
                                                <span className="icon-quote"></span>
                                            </div>
                                            <div className="testimonial-style1__single-img">
                                                <img src="assets/images/testimonial/testimonial-v1-1.png" alt="image"/>
                                            </div>
                                            <div className="testimonial-style1__single-content">
                                                <div className="title-box">
                                                    <h3>Career-Altering Guidance</h3>
                                                    <p>
                                                        Staffy is very accurate when comes to helping you
                                                        find a job and if that job finishes, They help you to find
                                                        an another job placement!.
                                                    </p>
                                                </div>
                                                <div className="customer-info">
                                                    <div className="rating-box">
                                                        <div className="icon-box">
                                                            <span className="icon-rate-star-button"></span>
                                                        </div>
                                                        <div className="rating-number">
                                                            <h3>4.9</h3>
                                                        </div>
                                                    </div>
                                                    <div className="company-name">
                                                        <h3>Nathan Felix</h3>
                                                        <span>Manager, Cypertech pvt ltd</span>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </SwiperSlide>
                                    <SwiperSlide>
                                        <div className="testimonial-style1__single">
                                            <div className="overlay-icon">
                                                <span className="icon-quote"></span>
                                            </div>
                                            <div className="testimonial-style1__single-img">
                                                <img src="assets/images/testimonial/testimonial-v1-2.png" alt="image"/>
                                            </div>
                                            <div className="testimonial-style1__single-content">
                                                <div className="title-box">
                                                    <h3>Best Hiring Assistance</h3>
                                                    <p>
                                                        I really appreciated the outstanding time, work & effort that the entire
                                                        staff
                                                        put into finding me an excellent job placement, Thank you so much.
                                                    </p>
                                                </div>
                                                <div className="customer-info">
                                                    <div className="rating-box">
                                                        <div className="icon-box">
                                                            <span className="icon-rate-star-button"></span>
                                                        </div>
                                                        <div className="rating-number">
                                                            <h3>5.0</h3>
                                                        </div>
                                                    </div>
                                                    <div className="company-name">
                                                        <h3>Eloise Juniper</h3>
                                                        <span>Vice president, Daily News</span>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </SwiperSlide>
                                    <SwiperSlide>
                                        <div className="testimonial-style1__single">
                                            <div className="overlay-icon">
                                                <span className="icon-quote"></span>
                                            </div>
                                            <div className="testimonial-style1__single-img">
                                                <img src="assets/images/testimonial/testimonial-v1-1.png" alt="image"/>
                                            </div>
                                            <div className="testimonial-style1__single-content">
                                                <div className="title-box">
                                                    <h3>Career-Altering Guidance</h3>
                                                    <p>
                                                        Staffy is very accurate when comes to helping you
                                                        find a job and if that job finishes, They help you to find
                                                        an another job placement!.
                                                    </p>
                                                </div>
                                                <div className="customer-info">
                                                    <div className="rating-box">
                                                        <div className="icon-box">
                                                            <span className="icon-rate-star-button"></span>
                                                        </div>
                                                        <div className="rating-number">
                                                            <h3>4.9</h3>
                                                        </div>
                                                    </div>
                                                    <div className="company-name">
                                                        <h3>Nathan Felix</h3>
                                                        <span>Manager, Cypertech pvt ltd</span>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </SwiperSlide>
                                    <SwiperSlide>
                                        <div className="testimonial-style1__single">
                                            <div className="overlay-icon">
                                                <span className="icon-quote"></span>
                                            </div>
                                            <div className="testimonial-style1__single-img">
                                                <img src="assets/images/testimonial/testimonial-v1-2.png" alt="image"/>
                                            </div>
                                            <div className="testimonial-style1__single-content">
                                                <div className="title-box">
                                                    <h3>Best Hiring Assistance</h3>
                                                    <p>
                                                        I really appreciated the outstanding time, work & effort that the entire
                                                        staff
                                                        put into finding me an excellent job placement, Thank you so much.
                                                    </p>
                                                </div>
                                                <div className="customer-info">
                                                    <div className="rating-box">
                                                        <div className="icon-box">
                                                            <span className="icon-rate-star-button"></span>
                                                        </div>
                                                        <div className="rating-number">
                                                            <h3>5.0</h3>
                                                        </div>
                                                    </div>
                                                    <div className="company-name">
                                                        <h3>Eloise Juniper</h3>
                                                        <span>Vice president, Daily News</span>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </SwiperSlide>
                                </Swiper>

                                <div className="swiper-nav-style-one">
                                    <button className="swiper-button-prev">
                                        <span className="left icon-left-arrow-angle-big-gross-symbol"></span>
                                    </button>
                                    <button className="swiper-button-next">
                                        <span className="right icon-arrow-angle-pointing-to-right"></span>
                                    </button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>

        </>
    )
}
