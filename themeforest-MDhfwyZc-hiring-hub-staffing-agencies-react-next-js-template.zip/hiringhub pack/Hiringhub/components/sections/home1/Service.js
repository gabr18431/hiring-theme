'use client'
import React from 'react'
import Link from "next/link"
import { Autoplay, Navigation, Pagination } from "swiper/modules"
import { Swiper, SwiperSlide } from "swiper/react"
const swiperOptions = {
    modules: [Autoplay, Pagination, Navigation],
    slidesPerView: 1,
    spaceBetween: 30,
    autoplay: {
        delay: 5000,
        disableOnInteraction: false,
    },
    loop: true,

    // Pagination
    pagination: {
        el: '.swiper-dot-style1',
        clickable: true,
    },

    breakpoints: {
        320: {
            slidesPerView: 1,
            spaceBetween: 30,
        },
        575: {
            slidesPerView: 1,
            spaceBetween: 30,
        },
        767: {
            slidesPerView: 2,
            spaceBetween: 30,
        },
        991: {
            slidesPerView: 2,
            spaceBetween: 30,
        },
        1199: {
            slidesPerView: 3,
            spaceBetween: 30,
        },
        1350: {
            slidesPerView: 3,
            spaceBetween: 30,
        },
    }
}

export default function Service() {
    return (
        <> 

            <section className="service-style1">
                <div className="container">
                    <div className="sec-title withtext text-center">
                        <div className="sub-title">
                            <h4>Solutions we provide</h4>
                        </div>
                        <h2>Innovative Solutions for Talents</h2>
                        <div className="text">
                            <p>
                                Long established fact that a reader will be distracted by the<br/>readable content of a page.
                            </p>
                        </div>
                    </div>

                    <Swiper {...swiperOptions} className="swiper-container service-style1-carousel">
                        <SwiperSlide>
                            <div className="service-style1__single">
                                <div className="title-box">
                                    <h3><Link href="solution01-temporary-stafing.html">Temporary Staffing</Link></h3>
                                </div>
                                <div className="service-style1__single-img">
                                    <div className="overlay-icon">
                                        <img src="assets/images/icon/services/service-icon-1-1.png" alt=""/>
                                    </div>
                                    <div className="img-box">
                                        <img src="assets/images/services/service-v1-1.jpg" alt="images"/>
                                    </div>
                                </div>
                                <div className="overlay-text">
                                    <p>The wise man therefore always holds<br/>in these matters to this...</p>
                                </div>
                                <div className="btn-box">
                                    <Link href="solution01-temporary-stafing.html">
                                        Explore More
                                        <span className="icon-arrow-angle-pointing-to-right"></span>
                                        <span className="icon-right-arrow-1 arrow-hover"></span>
                                    </Link>
                                </div>
                            </div>
                        </SwiperSlide>
                        <SwiperSlide>
                            <div className="service-style1__single">
                                <div className="title-box">
                                    <h3><Link href="solution02-contract-stafing.html">Contract Staffing</Link></h3>
                                </div>
                                <div className="service-style1__single-img">
                                    <div className="overlay-icon">
                                        <img src="assets/images/icon/services/service-icon-1-2.png" alt=""/>
                                    </div>
                                    <div className="img-box">
                                        <img src="assets/images/services/service-v1-2.jpg" alt="images"/>
                                    </div>
                                </div>
                                <div className="overlay-text">
                                    <p>Right to find fault with a man chooses<br/>annoying consequences...</p>
                                </div>
                                <div className="btn-box">
                                    <Link href="solution02-contract-stafing.html">
                                        Explore More
                                        <span className="icon-arrow-angle-pointing-to-right"></span>
                                        <span className="icon-right-arrow-1 arrow-hover"></span>
                                    </Link>
                                </div>
                            </div>
                        </SwiperSlide>
                        <SwiperSlide>
                            <div className="service-style1__single">
                                <div className="title-box">
                                    <h3><Link href="solution03-project-based.html">Project-Based Hiring</Link></h3>
                                </div>
                                <div className="service-style1__single-img">
                                    <div className="overlay-icon">
                                        <img src="assets/images/icon/services/service-icon-1-3.png" alt=""/>
                                    </div>
                                    <div className="img-box">
                                        <img src="assets/images/services/service-v1-3.jpg" alt="images"/>
                                    </div>
                                </div>
                                <div className="overlay-text">
                                    <p>Occasionally circumstances occur in<br/>pain can procure some great...</p>
                                </div>
                                <div className="btn-box">
                                    <Link href="solution03-project-based.html">
                                        Explore More
                                        <span className="icon-arrow-angle-pointing-to-right"></span>
                                        <span className="icon-right-arrow-1 arrow-hover"></span>
                                    </Link>
                                </div>
                            </div>
                        </SwiperSlide>
                    </Swiper>

                    <div className="swiper-dot-style1"></div>
                </div>
            </section>

        </>
    )
}
