'use client'
import React from 'react'
import Link from "next/link"

export default function Choose() {
    return (
        <> 

            <section className="why-choose-style1">
                <div className="container">
                    <div className="sec-title withtext text-center">
                        <div className="sub-title">
                            <h4>Why Choose Us</h4>
                        </div>
                        <h2>Advantages of Working With Us</h2>
                        <div className="text">
                            <p>
                                Long established fact that a reader will be distracted by the<br/>readable content of a page.
                            </p>
                        </div>
                    </div>
                    <div className="row">
                        <div className="col-xl-4 col-lg-4">
                            <div className="why-choose-style1__inner why-choose-style1__inner--2">
                                <ul>

                                    <li>
                                        <div className="why-choose-style1__list">
                                            <div className="number-box">
                                                <h2>01</h2>
                                            </div>
                                            <div className="content-box">
                                                <div className="title">
                                                    <h4>Reduce Hiring Risks</h4>
                                                </div>
                                                <div className="btn-box">
                                                    <Link href="/about">
                                                        <i className="icon-diagonal-arrow-1 arrow1"></i>
                                                    </Link>
                                                </div>
                                            </div>
                                        </div>
                                    </li>
                                    <li>
                                        <div className="why-choose-style1__list">
                                            <div className="content-box">
                                                <div className="title">
                                                    <h4>Deeper Talent Pools</h4>
                                                </div>
                                                <div className="btn-box">
                                                    <Link href="/about">
                                                        <i className="icon-diagonal-arrow-1 arrow2"></i>
                                                    </Link>
                                                </div>
                                            </div>
                                            <div className="number-box box1">
                                                <h2>03</h2>
                                            </div>
                                        </div>
                                    </li>
                                    <li>
                                        <div className="why-choose-style1__list">
                                            <div className="number-box">
                                                <h2>05</h2>
                                            </div>
                                            <div className="content-box">
                                                <div className="title">
                                                    <h4>Employer Branding</h4>
                                                </div>
                                                <div className="btn-box">
                                                    <Link href="/about">
                                                        <i className="icon-diagonal-arrow-1"></i>
                                                    </Link>
                                                </div>
                                            </div>
                                        </div>
                                    </li>
                                </ul>
                            </div>
                        </div>

                        <div className="col-xl-4 col-lg-4">
                            <div className="why-choose-style1__img">
                                <div className="inner">
                                    <img src="assets/images/resources/why-choose-v1-1.png" alt="image"/>
                                </div>
                            </div>
                        </div>

                        <div className="col-xl-4 col-lg-4">
                            <div className="why-choose-style1__inner why-choose-style1__inner--3">
                                <ul>
                                    <li>
                                        <div className="why-choose-style1__list">
                                            <div className="content-box box1">
                                                <div className="btn-box box1">
                                                    <Link href="/about">
                                                        <i className="icon-diagonal-arrow-1 arrow3"></i>
                                                    </Link>
                                                </div>
                                                <div className="title">
                                                    <h4>Increase Efficiencies</h4>
                                                </div>
                                            </div>
                                            <div className="number-box box1">
                                                <h2>02</h2>
                                            </div>
                                        </div>
                                    </li>
                                    <li>
                                        <div className="why-choose-style1__list">
                                            <div className="number-box">
                                                <h2>04</h2>
                                            </div>
                                            <div className="content-box box1">
                                                <div className="btn-box box1">
                                                    <Link href="/about">
                                                        <i className="icon-diagonal-arrow-1 arrow2 arrow4"></i>
                                                    </Link>
                                                </div>
                                                <div className="title">
                                                    <h4>Onboarding Support</h4>
                                                </div>
                                            </div>
                                        </div>
                                    </li>
                                    <li>
                                        <div className="why-choose-style1__list">
                                            <div className="content-box box1">
                                                <div className="btn-box box1">
                                                    <Link href="/about">
                                                        <i className="icon-diagonal-arrow-1 arrow5"></i>
                                                    </Link>
                                                </div>
                                                <div className="title">
                                                    <h4>Industry Knowledge</h4>
                                                </div>
                                            </div>
                                            <div className="number-box box1">
                                                <h2>06</h2>
                                            </div>
                                        </div>
                                    </li>
                                </ul>
                            </div>
                        </div>

                    </div>
                </div>
            </section>

        </>
    )
}
