'use client'
import React from 'react'
import Link from "next/link"

export default function About() {
    return (
        <> 

            <section className="about-style1">
                <div className="container">
                    <div className="row">

                        <div className="col-xl-6">
                            <div className="about-style1__img">
                                <img src="assets/images/about/about-style1_1.jpg" alt="image"/>
                            </div>
                        </div>

                        <div className="col-xl-6">
                            <div className="about-style1__content">
                                <div className="sec-title">
                                    <div className="sub-title">
                                        <h4>About our agency</h4>
                                    </div>
                                    <h2>Business Elevators and<br/>Career Crafters</h2>
                                </div>
                                <div className="started-year-box">
                                    <div className="title">
                                        <h5>Since</h5>
                                        <h3><span>2014,</span> Provide staffing services. </h3>
                                    </div>
                                    <div className="btn-box">
                                        <Link href="/about" className="icon-diagonal-arrow-1"></Link>
                                    </div>
                                </div>
                                <div className="text1">
                                    <p>Our being able to do what we like best, every pleasure is to be welcomed
                                        and every pain avoided but in certain circumstances and owing to the
                                        claims of duty or the obligations.</p>
                                </div>
                                <div className="about-awards-box">
                                    <div className="about-awards-box__img">
                                        <img src="assets/images/about/about-style1_2.jpg" alt="image"/>
                                    </div>
                                    <div className="about-awards-box__content">
                                        <h5>Our Awards</h5>
                                        <h3>Best Personnel Service Provider 2022"<br/>in Switzerland.</h3>
                                        <span>by Staffing Industry Analysts (SIA).</span>
                                    </div>
                                </div>
                                <div className="text2">
                                    <p>Every pleasure is to be welcomedand every pain avoided but in certain
                                        circumstances and owing to the claims of duty.</p>
                                </div>
                                <div className="about-style1__btn-box">
                                    <a className="btn-one" href="/about">
                                        <span className="txt">More About Us</span>
                                    </a>
                                </div>
                            </div>
                        </div>

                    </div>
                </div>
            </section>

        </>
    )
}
