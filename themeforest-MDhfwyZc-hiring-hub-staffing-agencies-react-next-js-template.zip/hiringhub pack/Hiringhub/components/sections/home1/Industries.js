'use client'
import React from 'react'
import Link from "next/link"

export default function Industries() {
    return (
        <> 

            <section className="industries-serve-style1">
                <div className="industries-serve-style1-bg"
                    style={{ backgroundImage: "url(assets/images/backgrounds/industries-serve-style1-bg.jpg)" }}>
                </div>
                <div className="container">
                    <div className="sec-title withtext">
                        <div className="sub-title">
                            <h4>Service areas</h4>
                        </div>
                        <h2>Our Specialized Industries</h2>
                        <div className="text">
                            <p>
                                Effortlessly tap into skilled remote talent with our simplified hiring.
                            </p>
                        </div>
                    </div>
                    <div className="row">

                        <div className="col-xl-8">
                            <div className="industries-serve-style1__content">
                                <div className="industries-serve-style1__content-list">
                                    <ul className="clearfix">

                                        <li>
                                            <div className="icon-box">
                                                <span className="icon-budget"><span className="path1"></span><span
                                                        className="path2"></span><span className="path3"></span><span
                                                        className="path4"></span><span className="path5"></span><span
                                                        className="path6"></span><span className="path7"></span><span
                                                        className="path8"></span><span className="path9"></span><span
                                                        className="path10"></span><span className="path11"></span><span
                                                        className="path12"></span><span className="path13"></span><span
                                                        className="path14"></span><span className="path15"></span><span
                                                        className="path16"></span><span className="path17"></span><span
                                                        className="path18"></span>
                                                </span>
                                            </div>
                                            <div className="title-box">
                                                <h3><Link href="/employers-overview">Accounting & Finance</Link></h3>
                                                <p>Attain Wellness Through Premier Healthcare Solutions.</p>
                                            </div>
                                            <div className="btn-box">
                                                <Link href="/employers-overview">
                                                    <span className="icon-down-right-arrow"></span>
                                                </Link>
                                            </div>
                                        </li>

                                        <li>
                                            <div className="icon-box">
                                                <span className="icon-megaphone"><span className="path1"></span><span
                                                        className="path2"></span><span className="path3"></span><span
                                                        className="path4"></span><span className="path5"></span><span
                                                        className="path6"></span>
                                                </span>
                                            </div>
                                            <div className="title-box">
                                                <h3><Link href="/employers-overview">Digital Marketing</Link></h3>
                                                <p>Opportunities in Dynamic Digital Marketing Roles.</p>
                                            </div>
                                            <div className="btn-box">
                                                <Link href="/employers-overview">
                                                    <span className="icon-down-right-arrow"></span>
                                                </Link>
                                            </div>
                                        </li>

                                        <li>
                                            <div className="icon-box">
                                                <span className="icon-medicine"><span className="path1"></span><span
                                                        className="path2"></span><span className="path3"></span>
                                                </span>
                                            </div>
                                            <div className="title-box">
                                                <h3><Link href="/employers-overview">Health Care & Medical</Link></h3>
                                                <p>Healing lives, caring professions, changing futures.</p>
                                            </div>
                                            <div className="btn-box">
                                                <Link href="/employers-overview">
                                                    <span className="icon-down-right-arrow"></span>
                                                </Link>
                                            </div>
                                        </li>
                                        <li>
                                            <div className="icon-box">
                                                <span className="icon-cloud-server"><span className="path1"></span><span
                                                        className="path2"></span>
                                                </span>
                                            </div>
                                            <div className="title-box">
                                                <h3><Link href="/employers-overview">Information Technology</Link></h3>
                                                <p>Involve managing digital systems and networks.</p>
                                            </div>
                                            <div className="btn-box">
                                                <Link href="/employers-overview">
                                                    <span className="icon-down-right-arrow"></span>
                                                </Link>
                                            </div>
                                        </li>

                                    </ul>
                                </div>
                            </div>
                        </div>

                        <div className="col-xl-4">
                            <div className="industries-serve-style1__highlight">
                                <div className="title">
                                    <h3>Highlight:</h3>
                                </div>
                                <ul>
                                    <li>
                                        <div className="text">
                                            <p>Job Offered</p>
                                        </div>
                                        <div className="number">
                                            <h4>2593</h4>
                                        </div>
                                    </li>
                                    <li>
                                        <div className="text">
                                            <p>Industry Companies</p>
                                        </div>
                                        <div className="number">
                                            <h4>26</h4>
                                        </div>
                                    </li>
                                    <li>
                                        <div className="text">
                                            <p>Job Opening</p>
                                        </div>
                                        <div className="number">
                                            <h4>126</h4>
                                        </div>
                                    </li>
                                </ul>
                                <div className="btn-box">
                                    <a className="btn-one" href="/employers-overview">
                                        <span className="txt">Share what you need</span>
                                    </a>
                                </div>
                            </div>
                        </div>

                    </div>
                </div>
            </section>

        </>
    )
}
