'use client'
import React from 'react'
import { useState } from "react"
import Link from "next/link"

export default function Pricing() {
    const [activeIndex, setActiveIndex] = useState(1)
        const handleOnClick = (index) => {
            setActiveIndex(index)
        }
    return (
        <> 

            <section className="pricing-style1">
                <div className="container">
                    <div className="sec-title">
                        <div className="sub-title">
                            <h4>Pricing & Plan</h4>
                        </div>
                        <h2>Tailored Pricing Solutions</h2>
                    </div>

                    <div className="switcher-tabs-box">

                        <div className="tab-btn-box-style2">
                            <ul className="tab-btns tab-buttons clearfix">
                                <li onClick={() => handleOnClick(1)} className={activeIndex === 1 ? "tab-btn active-btn" : "tab-btn"}>Standard</li>
                                <li onClick={() => handleOnClick(2)} className={activeIndex === 2 ? "tab-btn active-btn" : "tab-btn"}>Premium</li>
                            </ul>
                        </div>

                        <div className="tabs-content">

                            <div className={activeIndex === 1 ? "tab active-tab" : "tab"}>
                                <div className="row">
                                    <div className="col-xl-4 col-lg-4 col-md-6">
                                        <div className="pricing-style1__single">
                                            <div className="value-box">
                                                <h2>
                                                    <sup>$</sup>6.8<sup>k</sup>
                                                    <sub>/ Monthly</sub>
                                                </h2>
                                            </div>
                                            <div className="title-box">
                                                <h3>Temporary</h3>
                                                <div className="icon">
                                                    <span className="icon-busy"><span className="path1"></span><span
                                                            className="path2"></span><span className="path3"></span><span
                                                            className="path4"></span><span className="path5"></span><span
                                                            className="path6"></span><span className="path7"></span><span
                                                            className="path8"></span>
                                                    </span>
                                                </div>
                                            </div>
                                            <div className="list-item">
                                                <ul>
                                                    <li>
                                                        <div className="text">
                                                            <p>Candidate Sourcing</p>
                                                        </div>
                                                        <div className="icon-box">
                                                            <span className="icon-check"></span>
                                                        </div>
                                                    </li>
                                                    <li>
                                                        <div className="text">
                                                            <p>Resume Management</p>
                                                        </div>
                                                        <div className="icon-box">
                                                            <span className="icon-check"></span>
                                                        </div>
                                                    </li>
                                                    <li>
                                                        <div className="text">
                                                            <p>Candidate Tracking</p>
                                                        </div>
                                                        <div className="icon-box">
                                                            <span className="icon-check"></span>
                                                        </div>
                                                    </li>
                                                    <li>
                                                        <div className="text">
                                                            <p>Integrations</p>
                                                        </div>
                                                        <div className="icon-box">
                                                            <span className="icon-check"></span>
                                                        </div>
                                                    </li>
                                                </ul>
                                                <div className="btn-box">
                                                    <Link href="/solution01-temporary-stafing">
                                                        Explore More
                                                        <span className="icon-arrow-angle-pointing-to-right"></span>
                                                    </Link>
                                                </div>
                                            </div>
                                            <div className="bottom-text">
                                                <p><sup>*</sup>Highlight something here</p>
                                            </div>
                                        </div>
                                    </div>
                                    
                                    <div className="col-xl-4 col-lg-4 col-md-6">
                                        <div className="pricing-style1__single">
                                            <div className="value-box">
                                                <h2>
                                                    <sup>$</sup>9.5<sup>k</sup>
                                                    <sub>/ Monthly</sub>
                                                </h2>
                                            </div>
                                            <div className="title-box">
                                                <h3>Contract</h3>
                                                <div className="icon">
                                                    <span className="icon-writing"><span className="path1"></span><span
                                                            className="path2"></span><span className="path3"></span><span
                                                            className="path4"></span><span className="path5"></span><span
                                                            className="path6"></span><span className="path7"></span><span
                                                            className="path8"></span>
                                                    </span>
                                                </div>
                                            </div>
                                            <div className="list-item">
                                                <ul>
                                                    <li>
                                                        <div className="text">
                                                            <p>Candidate Matching</p>
                                                        </div>
                                                        <div className="icon-box">
                                                            <span className="icon-check"></span>
                                                        </div>
                                                    </li>
                                                    <li>
                                                        <div className="text">
                                                            <p>Security Control</p>
                                                        </div>
                                                        <div className="icon-box">
                                                            <span className="icon-check"></span>
                                                        </div>
                                                    </li>
                                                    <li>
                                                        <div className="text">
                                                            <p>Portal Management</p>
                                                        </div>
                                                        <div className="icon-box">
                                                            <span className="icon-check"></span>
                                                        </div>
                                                    </li>
                                                    <li>
                                                        <div className="text">
                                                            <p>Assessments</p>
                                                        </div>
                                                        <div className="icon-box">
                                                            <span className="icon-check"></span>
                                                        </div>
                                                    </li>
                                                </ul>
                                                <div className="btn-box">
                                                    <Link href="/solution02-contract-stafing">
                                                        Explore More
                                                        <span className="icon-arrow-angle-pointing-to-right"></span>
                                                    </Link>
                                                </div>
                                            </div>
                                            <div className="bottom-text">
                                                <p><sup>*</sup>Highlight something here</p>
                                            </div>
                                        </div>
                                    </div>
                                    
                                    <div className="col-xl-4 col-lg-4 col-md-6">
                                        <div className="pricing-style1__single">
                                            <div className="value-box">
                                                <h2>
                                                    <sup>$</sup>12<sup>k</sup>
                                                    <sub>/ Monthly</sub>
                                                </h2>
                                            </div>
                                            <div className="title-box">
                                                <h3>Project Based</h3>
                                                <div className="icon">
                                                    <span className="icon-curriculum-vitae"><span className="path1"></span><span
                                                            className="path2"></span><span className="path3"></span><span
                                                            className="path4"></span><span className="path5"></span><span
                                                            className="path6"></span><span className="path7"></span><span
                                                            className="path8"></span>
                                                    </span>
                                                </div>
                                            </div>
                                            <div className="list-item">
                                                <ul>
                                                    <li>
                                                        <div className="text">
                                                            <p>Candidate Sourcing</p>
                                                        </div>
                                                        <div className="icon-box">
                                                            <span className="icon-check"></span>
                                                        </div>
                                                    </li>
                                                    <li>
                                                        <div className="text">
                                                            <p>Resume Management</p>
                                                        </div>
                                                        <div className="icon-box">
                                                            <span className="icon-check"></span>
                                                        </div>
                                                    </li>
                                                    <li>
                                                        <div className="text">
                                                            <p>Candidate Tracking</p>
                                                        </div>
                                                        <div className="icon-box">
                                                            <span className="icon-check"></span>
                                                        </div>
                                                    </li>
                                                    <li>
                                                        <div className="text">
                                                            <p>Integrations</p>
                                                        </div>
                                                        <div className="icon-box">
                                                            <span className="icon-check"></span>
                                                        </div>
                                                    </li>
                                                </ul>
                                                <div className="btn-box">
                                                    <Link href="/solution03-project-based">
                                                        Explore More
                                                        <span className="icon-arrow-angle-pointing-to-right"></span>
                                                    </Link>
                                                </div>
                                            </div>
                                            <div className="bottom-text">
                                                <p><sup>*</sup>Highlight something here</p>
                                            </div>
                                        </div>
                                    </div>
                                    
                                </div>
                            </div>

                            <div className={activeIndex === 2 ? "tab active-tab" : "tab"}>
                                <div className="row">
                                    
                                    <div className="col-xl-4 col-lg-4 col-md-6">
                                        <div className="pricing-style1__single">
                                            <div className="value-box">
                                                <h2>
                                                    <sup>$</sup>16.8<sup>k</sup>
                                                    <sub>/ Monthly</sub>
                                                </h2>
                                            </div>
                                            <div className="title-box">
                                                <h3>Temporary</h3>
                                                <div className="icon">
                                                    <span className="icon-busy"><span className="path1"></span><span
                                                            className="path2"></span><span className="path3"></span><span
                                                            className="path4"></span><span className="path5"></span><span
                                                            className="path6"></span><span className="path7"></span><span
                                                            className="path8"></span>
                                                    </span>
                                                </div>
                                            </div>
                                            <div className="list-item">
                                                <ul>
                                                    <li>
                                                        <div className="text">
                                                            <p>Candidate Sourcing</p>
                                                        </div>
                                                        <div className="icon-box">
                                                            <span className="icon-check"></span>
                                                        </div>
                                                    </li>
                                                    <li>
                                                        <div className="text">
                                                            <p>Resume Management</p>
                                                        </div>
                                                        <div className="icon-box">
                                                            <span className="icon-check"></span>
                                                        </div>
                                                    </li>
                                                    <li>
                                                        <div className="text">
                                                            <p>Candidate Tracking</p>
                                                        </div>
                                                        <div className="icon-box">
                                                            <span className="icon-check"></span>
                                                        </div>
                                                    </li>
                                                    <li>
                                                        <div className="text">
                                                            <p>Integrations</p>
                                                        </div>
                                                        <div className="icon-box">
                                                            <span className="icon-check"></span>
                                                        </div>
                                                    </li>
                                                </ul>
                                                <div className="btn-box">
                                                    <Link href="/solution01-temporary-stafing">
                                                        Explore More
                                                        <span className="icon-arrow-angle-pointing-to-right"></span>
                                                    </Link>
                                                </div>
                                            </div>
                                            <div className="bottom-text">
                                                <p><sup>*</sup>Highlight something here</p>
                                            </div>
                                        </div>
                                    </div>
                                    
                                    <div className="col-xl-4 col-lg-4 col-md-6">
                                        <div className="pricing-style1__single">
                                            <div className="value-box">
                                                <h2>
                                                    <sup>$</sup>99.5<sup>k</sup>
                                                    <sub>/ Monthly</sub>
                                                </h2>
                                            </div>
                                            <div className="title-box">
                                                <h3>Contract</h3>
                                                <div className="icon">
                                                    <span className="icon-writing"><span className="path1"></span><span
                                                            className="path2"></span><span className="path3"></span><span
                                                            className="path4"></span><span className="path5"></span><span
                                                            className="path6"></span><span className="path7"></span><span
                                                            className="path8"></span>
                                                    </span>
                                                </div>
                                            </div>
                                            <div className="list-item">
                                                <ul>
                                                    <li>
                                                        <div className="text">
                                                            <p>Candidate Matching</p>
                                                        </div>
                                                        <div className="icon-box">
                                                            <span className="icon-check"></span>
                                                        </div>
                                                    </li>
                                                    <li>
                                                        <div className="text">
                                                            <p>Security Control</p>
                                                        </div>
                                                        <div className="icon-box">
                                                            <span className="icon-check"></span>
                                                        </div>
                                                    </li>
                                                    <li>
                                                        <div className="text">
                                                            <p>Portal Management</p>
                                                        </div>
                                                        <div className="icon-box">
                                                            <span className="icon-check"></span>
                                                        </div>
                                                    </li>
                                                    <li>
                                                        <div className="text">
                                                            <p>Assessments</p>
                                                        </div>
                                                        <div className="icon-box">
                                                            <span className="icon-check"></span>
                                                        </div>
                                                    </li>
                                                </ul>
                                                <div className="btn-box">
                                                    <Link href="/solution02-contract-stafing">
                                                        Explore More
                                                        <span className="icon-arrow-angle-pointing-to-right"></span>
                                                    </Link>
                                                </div>
                                            </div>
                                            <div className="bottom-text">
                                                <p><sup>*</sup>Highlight something here</p>
                                            </div>
                                        </div>
                                    </div>
                                    
                                    <div className="col-xl-4 col-lg-4 col-md-6">
                                        <div className="pricing-style1__single">
                                            <div className="value-box">
                                                <h2>
                                                    <sup>$</sup>35<sup>k</sup>
                                                    <sub>/ Monthly</sub>
                                                </h2>
                                            </div>
                                            <div className="title-box">
                                                <h3>Project Based</h3>
                                                <div className="icon">
                                                    <span className="icon-curriculum-vitae"><span className="path1"></span><span
                                                            className="path2"></span><span className="path3"></span><span
                                                            className="path4"></span><span className="path5"></span><span
                                                            className="path6"></span><span className="path7"></span><span
                                                            className="path8"></span>
                                                    </span>
                                                </div>
                                            </div>
                                            <div className="list-item">
                                                <ul>
                                                    <li>
                                                        <div className="text">
                                                            <p>Candidate Sourcing</p>
                                                        </div>
                                                        <div className="icon-box">
                                                            <span className="icon-check"></span>
                                                        </div>
                                                    </li>
                                                    <li>
                                                        <div className="text">
                                                            <p>Resume Management</p>
                                                        </div>
                                                        <div className="icon-box">
                                                            <span className="icon-check"></span>
                                                        </div>
                                                    </li>
                                                    <li>
                                                        <div className="text">
                                                            <p>Candidate Tracking</p>
                                                        </div>
                                                        <div className="icon-box">
                                                            <span className="icon-check"></span>
                                                        </div>
                                                    </li>
                                                    <li>
                                                        <div className="text">
                                                            <p>Integrations</p>
                                                        </div>
                                                        <div className="icon-box">
                                                            <span className="icon-check"></span>
                                                        </div>
                                                    </li>
                                                </ul>
                                                <div className="btn-box">
                                                    <Link href="/solution03-project-based">
                                                        Explore More
                                                        <span className="icon-arrow-angle-pointing-to-right"></span>
                                                    </Link>
                                                </div>
                                            </div>
                                            <div className="bottom-text">
                                                <p><sup>*</sup>Highlight something here</p>
                                            </div>
                                        </div>
                                    </div>
                                    
                                </div>
                            </div>

                        </div>
                    </div>
                </div>
            </section>

        </>
    )
}
