'use client'
import React from 'react'
import Link from "next/link"

export default function Partner() {
    return (
        <> 

            <section className="partner-style1">
                <div className="container">
                    <div className="sec-title withtext text-center">
                        <div className="sub-title">
                            <h4>Partners</h4>
                        </div>
                        <h2>Trusted Staffing Partnerships</h2>
                        <div className="text">
                            <p>Long established fact that a reader will be distracted by the.</p>
                        </div>
                    </div>
                    <div className="row">
                        
                        <div className="col-xl-3 col-lg-3 col-md-4">
                            <div className="partner-style1__single">
                                <Link href="#">
                                    <img src="assets/images/brand/brand-1-1.png" alt="brand"/>
                                    <img className="" src="assets/images/brand/brand-1__overlay-1.png" alt="brand"/>
                                </Link>
                            </div>
                        </div>
                        
                        <div className="col-xl-3 col-lg-3 col-md-4">
                            <div className="partner-style1__single">
                                <Link href="#">
                                    <img src="assets/images/brand/brand-1-2.png" alt="brand"/>
                                    <img className="" src="assets/images/brand/brand-1__overlay-2.png" alt="brand"/>
                                </Link>
                            </div>
                        </div>
                        
                        <div className="col-xl-3 col-lg-3 col-md-4">
                            <div className="partner-style1__single">
                                <Link href="#">
                                    <img src="assets/images/brand/brand-1-3.png" alt="brand"/>
                                    <img className="" src="assets/images/brand/brand-1__overlay-3.png" alt="brand"/>
                                </Link>
                            </div>
                        </div>
                        
                        <div className="col-xl-3 col-lg-3 col-md-4">
                            <div className="partner-style1__single">
                                <Link href="#">
                                    <img src="assets/images/brand/brand-1-4.png" alt="brand"/>
                                    <img className="" src="assets/images/brand/brand-1__overlay-4.png" alt="brand"/>
                                </Link>
                            </div>
                        </div>
                        
                        <div className="col-xl-3 col-lg-3 col-md-4">
                            <div className="partner-style1__single">
                                <Link href="#">
                                    <img src="assets/images/brand/brand-1-5.png" alt="brand"/>
                                    <img className="" src="assets/images/brand/brand-1__overlay-5.png" alt="brand"/>
                                </Link>
                            </div>
                        </div>
                        
                        <div className="col-xl-3 col-lg-3 col-md-4">
                            <div className="partner-style1__single">
                                <Link href="#">
                                    <img src="assets/images/brand/brand-1-6.png" alt="brand"/>
                                    <img className="" src="assets/images/brand/brand-1__overlay-6.png" alt="brand"/>
                                </Link>
                            </div>
                        </div>
                        
                        <div className="col-xl-3 col-lg-3 col-md-4">
                            <div className="partner-style1__single">
                                <Link href="#">
                                    <img src="assets/images/brand/brand-1-7.png" alt="brand"/>
                                    <img className="" src="assets/images/brand/brand-1__overlay-7.png" alt="brand"/>
                                </Link>
                            </div>
                        </div>
                        
                        <div className="col-xl-3 col-lg-3 col-md-4">
                            <div className="partner-style1__single">
                                <Link href="#">
                                    <img src="assets/images/brand/brand-1-8.png" alt="brand"/>
                                    <img className="" src="assets/images/brand/brand-1__overlay-8.png" alt="brand"/>
                                </Link>
                            </div>
                        </div>
                        

                    </div>
                    <div className="partner-style1__btn text-center">
                        <Link href="#">See all Partners <span className="icon-arrow-angle-pointing-to-right"></span></Link>
                    </div>
                </div>
            </section>

        </>
    )
}
