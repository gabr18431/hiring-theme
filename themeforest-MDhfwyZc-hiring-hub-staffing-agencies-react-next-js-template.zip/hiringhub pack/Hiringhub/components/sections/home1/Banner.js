'use client'
import React from 'react'
import Link from "next/link"
import CounterUp from "@/components/elements/CounterUp"
import { Autoplay, Navigation, Pagination } from "swiper/modules"
import { Swiper, SwiperSlide } from "swiper/react"
const swiperOptions = {
    modules: [Autoplay, Pagination, Navigation],
    slidesPerView: 1,
    spaceBetween: 30,
    autoplay: {
        delay: 5000,
        disableOnInteraction: false,
    },
    loop: true,

    // Navigation
    navigation: {
        nextEl: '.swiper-button-prev',
        prevEl: '.swiper-button-next',
    },

    // Pagination
    pagination: {
        el: '.swiper-pagination',
        clickable: true,
    },

    breakpoints: {
        320: {
            slidesPerView: 1,
            spaceBetween: 30,
        },
        575: {
            slidesPerView: 1,
            spaceBetween: 30,
        },
        767: {
            slidesPerView: 1,
            spaceBetween: 30,
        },
        991: {
            slidesPerView: 1,
            spaceBetween: 30,
        },
        1199: {
            slidesPerView: 1,
            spaceBetween: 30,
        },
        1350: {
            slidesPerView: 1,
            spaceBetween: 30,
        },
    }
}

export default function Banner() {
    return (
        <> 

        <section className="main-slider main-slider-style1">

        <div className="main-slider-fact-counter-box">
                <ul>
                    
                    <li className="slide-single-fact-counter">
                        <div className="dot-box"></div>
                        <div className="outer-box">
                            <div className="count-outer count-box">
                                <span className="count-text"><CounterUp end={24} /></span>
                                <i className="k">k</i>
                            </div>
                            <div className="title">
                                <p>Employees hired in<br/> last year</p>
                            </div>
                        </div>
                    </li>

                    <li className="slide-single-fact-counter">
                        <div className="dot-box"></div>
                        <div className="outer-box">
                            <div className="count-outer count-box">
                                <span className="count-text"><CounterUp end={839} /></span>
                            </div>
                            <div className="title">
                                <p>Employers formed in<br/> last year</p>
                            </div>
                        </div>
                    </li>
                </ul>
            </div>

            <Swiper {...swiperOptions} className="swiper-container banner-slider">
                <SwiperSlide>
                    <div className="swiper-slide">
                        <div className="image-layer" style={{ backgroundImage: "url(assets/images/slides/slide-v1-1.jpg)" }}></div>
                        <div className="container">
                            <div className="row">
                                <div className="col-xl-12">
                                    <div className="main-slider-content">
                                        <div className="main-slider-content__inner">
                                            <div className="big-title">
                                                <h2>
                                                    Matching Talent with Ideal<br/> Opportunities.
                                                </h2>
                                            </div>
                                            <div className="bottom-box">
                                                <div className="left"></div>
                                                <div className="right">
                                                    <div className="text">
                                                        <p>
                                                            Trouble that are bound to ensue and equal that<br/> shrinking
                                                            from toil and pain.
                                                        </p>
                                                    </div>
                                                    <div className="btn-box">
                                                        <Link className="btn-one" href="/about">
                                                            <span className="txt">
                                                                Learn More
                                                            </span>
                                                        </Link>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>

                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </SwiperSlide>
                <SwiperSlide>
                    <div className="swiper-slide">
                        <div className="image-layer" style={{ backgroundImage: "url(assets/images/slides/slide-v1-2.jpg)" }}></div>
                        <div className="container">
                            <div className="row">
                                <div className="col-xl-12">
                                    <div className="main-slider-content">
                                        <div className="main-slider-content__inner">
                                            <div className="big-title">
                                                <h2>
                                                    Finding Solutions To Your<br/> Staffing Problems.
                                                </h2>
                                            </div>
                                            <div className="bottom-box">
                                                <div className="left"></div>
                                                <div className="right">
                                                    <div className="text">
                                                        <p>
                                                            Except to obtain some advantage from it who<br/> has find
                                                            with a man who chooses to enjoy.
                                                        </p>
                                                    </div>
                                                    <div className="btn-box">
                                                        <Link className="btn-one" href="/about">
                                                            <span className="txt">
                                                                Learn More
                                                            </span>
                                                        </Link>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>

                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </SwiperSlide>
                <SwiperSlide>
                    <div className="swiper-slide">
                        <div className="image-layer" style={{ backgroundImage: "url(assets/images/slides/slide-v1-3.jpg)" }}></div>
                        <div className="container">
                            <div className="row">
                                <div className="col-xl-12">
                                    <div className="main-slider-content">
                                        <div className="main-slider-content__inner">
                                            <div className="big-title">
                                                <h2>
                                                    Hiring The Best Makes Us<br/> Proud & Joy.
                                                </h2>
                                            </div>
                                            <div className="bottom-box">
                                                <div className="left"></div>
                                                <div className="right">
                                                    <div className="text">
                                                        <p>
                                                            Rationally encounter consequences all extremely<br/> nor
                                                            again is there anyone loves.
                                                        </p>
                                                    </div>
                                                    <div className="btn-box">
                                                        <Link className="btn-one" href="/about">
                                                            <span className="txt">
                                                                Learn More
                                                            </span>
                                                        </Link>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>

                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </SwiperSlide>
                <div className="swiper-pagination" id="main-slider-pagination"></div>
                <div className="main-slider__nav">
                    <div className="swiper-button-prev" id="main-slider__swiper-button-next">
                        <i className="icon-left-arrow-angle-big-gross-symbol left"></i>
                    </div>
                    <div className="swiper-button-next" id="main-slider__swiper-button-prev">
                        <i className="icon-arrow-angle-pointing-to-right right"></i>
                    </div>
                </div>
            </Swiper>
        </section>

        </>
    )
}
