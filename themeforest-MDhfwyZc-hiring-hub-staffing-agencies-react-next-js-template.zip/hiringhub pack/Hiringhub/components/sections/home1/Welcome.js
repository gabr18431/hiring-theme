'use client'
import React from 'react'
import Link from "next/link"

export default function Welcome() {
    return (
        <> 

            <section className="welcome-style1">
                <div className="container">
                    <div className="welcome-style1__top-title">
                        <div className="sec-title">
                            <div className="sub-title">
                                <h4>Welcome to Hiringhub</h4>
                            </div>
                            <h2>Navigating Career Paths</h2>
                        </div>
                        <div className="text">
                            <p>Long established fact that a reader distracted by the readable content<br/>beguiled and
                                demoralized by the charms.</p>
                        </div>
                    </div>
                    <div className="row">

                        <div className="col-xl-8">
                            <div className="welcome-style1__img">
                                <div className="row">
                                    <div className="col-xl-6 col-lg-6 col-md-6">
                                        <div className="welcome-style1__img-single">
                                            <img src="assets/images/resources/welcome-style1-img-1.jpg" alt=""/>
                                            <div className="overlay-btn">
                                                <Link href="/about">
                                                    Employers
                                                    <span className="icon-right-arrow"></span>
                                                </Link>
                                            </div>
                                        </div>
                                    </div>
                                    <div className="col-xl-6 col-lg-6 col-md-6">
                                        <div className="welcome-style1__img-single">
                                            <img src="assets/images/resources/welcome-style1-img-2.jpg" alt=""/>
                                            <div className="overlay-btn">
                                                <Link href="/about">
                                                    employees
                                                    <span className="icon-right-arrow"></span>
                                                </Link>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div className="col-xl-4">
                            <div className="welcome-style1__content">
                                <div className="big-round"></div>
                                <div className="sec-title">
                                    <div className="sub-title">
                                        <h4>For Employers</h4>
                                    </div>
                                    <h2>Discover Career Options</h2>
                                </div>
                                <div className="text">
                                    <p>
                                        We like best every pleasure to be welcomed andevery pain avoided but in certain
                                        circumstances have to be repudiated.
                                    </p>
                                </div>
                                <div className="list-item">
                                    <ul>
                                        <li>
                                            <div className="round-box"></div>
                                            <Link href="#">
                                                Contract Talent
                                                <i className="icon-arrow-angle-pointing-to-right"></i>
                                                <i className="icon-arrow-angle-pointing-to-right arrow-hover"></i>
                                            </Link>
                                        </li>
                                        <li>
                                            <div className="round-box"></div>
                                            <Link href="#">
                                                Permanent Placement
                                                <i className="icon-arrow-angle-pointing-to-right"></i>
                                                <i className="icon-arrow-angle-pointing-to-right arrow-hover"></i>
                                            </Link>
                                        </li>
                                    </ul>
                                </div>
                                <div className="icon-box">
                                    <span className="icon-leader"><span className="path1"></span><span className="path2"></span><span
                                            className="path3"></span><span className="path4"></span></span>
                                </div>
                            </div>
                        </div>

                    </div>
                </div>
            </section>

        </>
    )
}
