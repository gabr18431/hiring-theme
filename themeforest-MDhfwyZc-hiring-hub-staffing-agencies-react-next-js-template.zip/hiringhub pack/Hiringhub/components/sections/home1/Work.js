'use client'
import React from 'react'
import Link from "next/link"

export default function Work() {
    return (
        <> 

            <section className="how-its-work-style1">
                <div className="container">
                    <div className="sec-title withtext text-center">
                        <div className="sub-title">
                            <h4>How It’s Possible</h4>
                        </div>
                        <h2>Simple Staffing Procedures</h2>
                        <div className="text">
                            <p>
                                Long established fact that a reader will be distracted by the<br/>readable content of a page.
                            </p>
                        </div>
                    </div>
                    <div className="row">
                        
                        <div className="col-xl-4 col-lg-4 col-md-6">
                            <div className="how-its-work-style1__single">
                                <div className="img-box">
                                    <div className="icon-box">
                                        <span className="icon-conversation"><span className="path1"></span><span
                                                className="path2"></span><span className="path3"></span><span
                                                className="path4"></span><span className="path5"></span><span
                                                className="path6"></span><span className="path7"></span><span
                                                className="path8"></span></span>
                                    </div>
                                    <div className="inner">
                                        <img src="assets/images/resources/how-its-work-1-1.jpg" alt="image"/>
                                        <div className="count-box">
                                            <h3>01</h3>
                                        </div>
                                    </div>
                                </div>
                                <div className="content-box text-center">
                                    <h3><Link href="/solution01-temporary-stafing">Job Analysis</Link></h3>
                                    <p>
                                        That they cannot foresee the pain trouble that are bound ensue equal blame of
                                        business .
                                    </p>
                                </div>
                            </div>
                        </div>
                        
                        <div className="col-xl-4 col-lg-4 col-md-6">
                            <div className="how-its-work-style1__single">
                                <div className="img-box">
                                    <div className="icon-box">
                                        <span className="icon-resume"><span className="path1"></span><span
                                                className="path2"></span><span className="path3"></span><span
                                                className="path4"></span><span className="path5"></span><span
                                                className="path6"></span></span>
                                    </div>
                                    <div className="inner">
                                        <img src="assets/images/resources/how-its-work-1-2.jpg" alt="image"/>
                                        <div className="count-box">
                                            <h3>02</h3>
                                        </div>
                                    </div>
                                </div>
                                <div className="content-box text-center">
                                    <h3><Link href="/solution01-temporary-stafing">Applicant Review</Link></h3>
                                    <p>
                                        Power of choiced is untrammelled when nothing prevents claims off duty or the it
                                        will frequently occur that.
                                    </p>
                                </div>
                            </div>
                        </div>
                        
                        <div className="col-xl-4 col-lg-4 col-md-6">
                            <div className="how-its-work-style1__single">
                                <div className="img-box">
                                    <div className="icon-box">
                                        <span className="icon-candidates"><span className="path1"></span><span
                                                className="path2"></span><span className="path3"></span><span
                                                className="path4"></span><span className="path5"></span><span
                                                className="path6"></span></span>
                                    </div>
                                    <div className="inner">
                                        <img src="assets/images/resources/how-its-work-1-3.jpg" alt="image"/>
                                        <div className="count-box">
                                            <h3>03</h3>
                                        </div>
                                    </div>
                                </div>
                                <div className="content-box text-center">
                                    <h3><Link href="/solution01-temporary-stafing">Job Place & Check</Link></h3>
                                    <p>
                                        Have to be repudiated & annoyances accepted. The wise man therefore always holds in
                                        these matters.
                                    </p>
                                </div>
                            </div>
                        </div>
                        
                    </div>

                    <div className="row">
                        <div className="col-xl-12">
                            <div className="how-its-work-style1__consult text-center">
                                <div className="text">
                                    <p>Empower Your Team with Our Staffing Solutions.</p>
                                </div>
                                <div className="btn-box">
                                    <Link className="btn-one" href="/contact">
                                        <span className="txt">Consult Now</span>
                                    </Link>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>

        </>
    )
}
