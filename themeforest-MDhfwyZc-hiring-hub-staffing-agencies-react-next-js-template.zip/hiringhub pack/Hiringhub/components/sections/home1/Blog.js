'use client'
import React from 'react'
import Link from "next/link"

export default function Blog() {
    return (
        <> 

            <section className="blog-style1">
                <div className="container">

                    <div className="sec-title withtext text-center">
                        <div className="sub-title">
                            <h4>News & Updates</h4>
                        </div>
                        <h2>Latest from our Blog Post</h2>
                        <div className="text">
                            <p>Long established fact that a reader will be distracted by the.</p>
                        </div>
                    </div>

                    <div className="row">
                        
                        <div className="col-xl-4 col-lg-4 col-md-6">
                            <div className="blog-style1__single">
                                <div className="author-info">
                                    <div className="author-info__img">
                                        <img src="assets/images/blog/blog-v1-author-info1.jpg" alt="image"/>
                                    </div>
                                    <div className="author-info__text">
                                        <h5>Boone Gerardo</h5>
                                        <ul className="clearfix">
                                            <li>
                                                <Link href="#">Nov 15, 2025</Link>
                                            </li>
                                            <li>
                                                <Link href="#">2 Comments</Link>
                                            </li>
                                        </ul>
                                    </div>
                                </div>
                                <div className="blog-style1__single-img">
                                    <div className="category-box">
                                        <p>News & Tips</p>
                                    </div>
                                    <img src="assets/images/blog/blog-v1-1.jpg" alt="image"/>
                                </div>
                                <div className="blog-style1__single-title">
                                    <h3>
                                        <Link href="/blog-single">
                                            Unlocking Success: Top <br/>Eight Tips for
                                            Leadership <br/>Recruitment.
                                        </Link>
                                    </h3>
                                </div>
                                <div className="blog-style1__single-btn">
                                    <div className="left">
                                        <p>2 Mins Read</p>
                                    </div>
                                    <div className="right">
                                        <Link href="/blog-single"><span className="icon-right-arrow-1"></span></Link>
                                        <div className="overlay-btn">
                                            <Link href="/blog-single">Read More
                                                <span className="icon-arrow-angle-pointing-to-right"></span>
                                            </Link>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        
                        <div className="col-xl-4 col-lg-4 col-md-6">
                            <div className="blog-style1__single">
                                <div className="author-info">
                                    <div className="author-info__img">
                                        <img src="assets/images/blog/blog-v1-author-info2.jpg" alt="image"/>
                                    </div>
                                    <div className="author-info__text">
                                        <h5>Harley Reuban</h5>
                                        <ul className="clearfix">
                                            <li>
                                                <Link href="#">Oct 24, 2025 </Link>
                                            </li>
                                            <li>
                                                <Link href="#">3 Comments</Link>
                                            </li>
                                        </ul>
                                    </div>
                                </div>
                                <div className="blog-style1__single-img">
                                    <div className="category-box">
                                        <p>Job Seekers</p>
                                    </div>
                                    <img src="assets/images/blog/blog-v1-2.jpg" alt="image"/>
                                </div>
                                <div className="blog-style1__single-title">
                                    <h3>
                                        <Link href="/blog-single">
                                            Navigating Remote Work: <br/>Six Tips for Employers & <br/>Employees.
                                        </Link>
                                    </h3>
                                </div>
                                <div className="blog-style1__single-btn">
                                    <div className="left">
                                        <p>3 Mins Read</p>
                                    </div>
                                    <div className="right">
                                        <Link href="/blog-single"><span className="icon-right-arrow-1"></span></Link>
                                        <div className="overlay-btn">
                                            <Link href="/blog-single">Read More
                                                <span className="icon-arrow-angle-pointing-to-right"></span>
                                            </Link>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        
                        <div className="col-xl-4 col-lg-4 col-md-6">
                            <div className="blog-style1__single">
                                <div className="author-info">
                                    <div className="author-info__img">
                                        <img src="assets/images/blog/blog-v1-author-info3.jpg" alt="image"/>
                                    </div>
                                    <div className="author-info__text">
                                        <h5>Dahlia Bianca</h5>
                                        <ul className="clearfix">
                                            <li>
                                                <Link href="#">Oct 10, 2025</Link>
                                            </li>
                                            <li>
                                                <Link href="#">8 Comments</Link>
                                            </li>
                                        </ul>
                                    </div>
                                </div>
                                <div className="blog-style1__single-img">
                                    <div className="category-box">
                                        <p>Human Resource</p>
                                    </div>
                                    <img src="assets/images/blog/blog-v1-3.jpg" alt="image"/>
                                </div>
                                <div className="blog-style1__single-title">
                                    <h3>
                                        <Link href="/blog-single">
                                            Hiringhub Chosen for <br/>Crown Commercial's Staff- <br/>ing Services.
                                        </Link>
                                    </h3>
                                </div>
                                <div className="blog-style1__single-btn">
                                    <div className="left">
                                        <p>5 Mins Read</p>
                                    </div>
                                    <div className="right">
                                        <Link href="/blog-single"><span className="icon-right-arrow-1"></span></Link>
                                        <div className="overlay-btn">
                                            <Link href="/blog-single">Read More
                                                <span className="icon-arrow-angle-pointing-to-right"></span>
                                            </Link>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        

                    </div>
                </div>
            </section>

        </>
    )
}
