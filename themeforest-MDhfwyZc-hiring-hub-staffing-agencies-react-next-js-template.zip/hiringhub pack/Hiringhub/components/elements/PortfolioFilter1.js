'use client'
import Isotope from "isotope-layout"
import Link from "next/link"
import { useCallback, useEffect, useRef, useState } from "react"

export default function PortfolioFilter1() {

    const isotope = useRef()
    const [filterKey, setFilterKey] = useState("*")
    useEffect(() => {
        setTimeout(() => {
            isotope.current = new Isotope(".filter-layout", {
                itemSelector: ".filter-item",
                // layoutMode: "fitRows",
                percentPosition: true,
                masonry: {
                    columnWidth: ".filter-item",
                },
                animationOptions: {
                    duration: 750,
                    easing: "linear",
                    queue: false,
                },
            })
        }, 1000)
    }, [])
    useEffect(() => {
        if (isotope.current) {
            filterKey === "*"
                ? isotope.current.arrange({ filter: `*` })
                : isotope.current.arrange({ filter: `.${filterKey}` })
        }
    }, [filterKey])
    const handleFilterKeyChange = useCallback((key) => () => {
        setFilterKey(key)
    },
        []
    )

    const activeBtn = (value) => (value === filterKey ? "filter active" : "filter")



    return (
        <>

            <section className="case-page-one">
                <div className="container">
                    <div className="project-menu-box">
                        <ul className="project-filter text-center clearfix post-filter has-dynamic-filters-counter">
                            <li className={activeBtn("*")} onClick={handleFilterKeyChange("*")}><span className="filter-text">View All</span></li>
                            <li className={activeBtn("consulting")} onClick={handleFilterKeyChange("consulting")}><span className="filter-text">Consulting</span></li>
                            <li className={activeBtn("technology")} onClick={handleFilterKeyChange("technology")}><span className="filter-text">technology</span></li>
                            <li className={activeBtn("industry")} onClick={handleFilterKeyChange("industry")}><span className="filter-text">Industry Focus</span></li>
                            <li className={activeBtn("management")} onClick={handleFilterKeyChange("management")}><span className="filter-text">Management</span></li>
                            <li className={activeBtn("recruitment")} onClick={handleFilterKeyChange("recruitment")}><span className="filter-text">Recruitment</span></li>
                        </ul>
                    </div>

                    <div className="row filter-layout masonary-layout">
                        
                        <div className="col-xl-4 col-lg-4 col-md-6 filter-item consulting industry">
                            <div className="case-style1__single">
                                <div className="img-box">
                                    <div className="inner">
                                        <img src="assets/images/resources/case-v1-1.jpg" alt="image"/>
                                        <div className="overlay-icon">
                                            <Link className="lightbox-image" data-fancybox="gallery"
                                                href="assets/images/resources/case-v1-1.jpg">
                                                <i className="icon-zoom-in"></i>
                                            </Link>
                                        </div>
                                    </div>
                                    <div className="overlay-content">
                                        <div className="category-box">
                                            <p>Management</p>
                                        </div>
                                        <div className="title-box">
                                            <h3><Link href="/case-single">Placements Driving Growth</Link></h3>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        
                        <div className="col-xl-4 col-lg-4 col-md-6 filter-item technology management">
                            <div className="case-style1__single">
                                <div className="img-box">
                                    <div className="inner">
                                        <img src="assets/images/resources/case-v1-2.jpg" alt="image"/>
                                        <div className="overlay-icon">
                                            <Link className="lightbox-image" data-fancybox="gallery"
                                                href="assets/images/resources/case-v1-2.jpg">
                                                <i className="icon-zoom-in"></i>
                                            </Link>
                                        </div>
                                    </div>
                                    <div className="overlay-content">
                                        <div className="category-box">
                                            <p>Industry Focus</p>
                                        </div>
                                        <div className="title-box">
                                            <h3><Link href="/case-single">Recuirtment &amp; Selection Procedure</Link></h3>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        
                        <div className="col-xl-4 col-lg-4 col-md-6 filter-item recruitment consulting">
                            <div className="case-style1__single">
                                <div className="img-box">
                                    <div className="inner">
                                        <img src="assets/images/resources/case-v1-3.jpg" alt="image"/>
                                        <div className="overlay-icon">
                                            <Link className="lightbox-image" data-fancybox="gallery"
                                                href="assets/images/resources/case-v1-3.jpg">
                                                <i className="icon-zoom-in"></i>
                                            </Link>
                                        </div>
                                    </div>
                                    <div className="overlay-content">
                                        <div className="category-box">
                                            <p>Recruitment</p>
                                        </div>
                                        <div className="title-box">
                                            <h3><Link href="/case-single">Issues Faced by the Company</Link></h3>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        
                        <div className="col-xl-4 col-lg-4 col-md-6 filter-item consulting industry">
                            <div className="case-style1__single">
                                <div className="img-box">
                                    <div className="inner">
                                        <img src="assets/images/resources/case-v1-4.jpg" alt="image"/>
                                        <div className="overlay-icon">
                                            <Link className="lightbox-image" data-fancybox="gallery"
                                                href="assets/images/resources/case-v1-4.jpg">
                                                <i className="icon-zoom-in"></i>
                                            </Link>
                                        </div>
                                    </div>
                                    <div className="overlay-content">
                                        <div className="category-box">
                                            <p>Recruitment</p>
                                        </div>
                                        <div className="title-box">
                                            <h3><Link href="/case-single">Recuirtment &amp; Selection Procedure</Link></h3>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        
                        <div className="col-xl-4 col-lg-4 col-md-6 filter-item technology management">
                            <div className="case-style1__single">
                                <div className="img-box">
                                    <div className="inner">
                                        <img src="assets/images/resources/case-v1-5.jpg" alt="image"/>
                                        <div className="overlay-icon">
                                            <Link className="lightbox-image" data-fancybox="gallery"
                                                href="assets/images/resources/case-v1-5.jpg">
                                                <i className="icon-zoom-in"></i>
                                            </Link>
                                        </div>
                                    </div>
                                    <div className="overlay-content">
                                        <div className="category-box">
                                            <p>Management</p>
                                        </div>
                                        <div className="title-box">
                                            <h3><Link href="/case-single">Placements Driving Growth</Link></h3>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        
                        <div className="col-xl-4 col-lg-4 col-md-6 filter-item recruitment consulting">
                            <div className="case-style1__single">
                                <div className="img-box">
                                    <div className="inner">
                                        <img src="assets/images/resources/case-v1-6.jpg" alt="image"/>
                                        <div className="overlay-icon">
                                            <Link className="lightbox-image" data-fancybox="gallery"
                                                href="assets/images/resources/case-v1-6.jpg">
                                                <i className="icon-zoom-in"></i>
                                            </Link>
                                        </div>
                                    </div>
                                    <div className="overlay-content">
                                        <div className="category-box">
                                            <p>Industry Focus</p>
                                        </div>
                                        <div className="title-box">
                                            <h3><Link href="/case-single">Issues Faced by the Company</Link></h3>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        
                        <div className="col-xl-4 col-lg-4 col-md-6 filter-item consulting industry">
                            <div className="case-style1__single">
                                <div className="img-box">
                                    <div className="inner">
                                        <img src="assets/images/resources/case-v1-7.jpg" alt="image"/>
                                        <div className="overlay-icon">
                                            <Link className="lightbox-image" data-fancybox="gallery"
                                                href="assets/images/resources/case-v1-7.jpg">
                                                <i className="icon-zoom-in"></i>
                                            </Link>
                                        </div>
                                    </div>
                                    <div className="overlay-content">
                                        <div className="category-box">
                                            <p>Industry Focus</p>
                                        </div>
                                        <div className="title-box">
                                            <h3><Link href="/case-single">Issues Faced by the Company</Link></h3>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        
                        <div className="col-xl-4 col-lg-4 col-md-6 filter-item technology management">
                            <div className="case-style1__single">
                                <div className="img-box">
                                    <div className="inner">
                                        <img src="assets/images/resources/case-v1-8.jpg" alt="image"/>
                                        <div className="overlay-icon">
                                            <Link className="lightbox-image" data-fancybox="gallery"
                                                href="assets/images/resources/case-v1-8.jpg">
                                                <i className="icon-zoom-in"></i>
                                            </Link>
                                        </div>
                                    </div>
                                    <div className="overlay-content">
                                        <div className="category-box">
                                            <p>Recuirtment</p>
                                        </div>
                                        <div className="title-box">
                                            <h3><Link href="/case-single">Recuirtment & Selection Procedure</Link></h3>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        
                        <div className="col-xl-4 col-lg-4 col-md-6 filter-item recruitment consulting">
                            <div className="case-style1__single">
                                <div className="img-box">
                                    <div className="inner">
                                        <img src="assets/images/resources/case-v1-9.jpg" alt="image"/>
                                        <div className="overlay-icon">
                                            <Link className="lightbox-image" data-fancybox="gallery"
                                                href="assets/images/resources/case-v1-9.jpg">
                                                <i className="icon-zoom-in"></i>
                                            </Link>
                                        </div>
                                    </div>
                                    <div className="overlay-content">
                                        <div className="category-box">
                                            <p>Management</p>
                                        </div>
                                        <div className="title-box">
                                            <h3><Link href="/case-single">Placements Driving Growth</Link></h3>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div className="row">
                        <div className="col-xl-12">
                            <ul className="styled-pagination clearfix text-center">
                                <li className="arrow prev">
                                    <Link href="#"><span className="icon-left-arrow-angle-big-gross-symbol left"></span></Link>
                                </li>
                                <li className="active"><Link href="#">01</Link></li>
                                <li><Link href="#">02</Link></li>
                                <li><Link href="#">03</Link></li>
                                <li className="arrow next">
                                    <Link href="#"><span className="icon-arrow-angle-pointing-to-right right"></span></Link>
                                </li>
                            </ul>
                        </div>
                    </div>

                </div>
            </section>
        </>
    )
}
