import Link from "next/link"

export default function Menu() {

    return (
        <>

            <ul className="main-menu__list">
                <li className="dropdown"><Link href="/">Home</Link>
                    <ul>
                        <li><Link href="/">Home Page 01</Link></li>
                        <li><Link href="/index-2">Home Page 02</Link></li>
                        <li><Link href="/index-3">Home Page 03</Link></li>
                        <li><Link href="/index-4">Home Page 04</Link></li>
                        <li><Link href="/index-5">Home Page 05</Link></li>
                    </ul>
                </li>
                <li className="dropdown"><Link href="#">About</Link>
                    <ul>
                        <li><Link href="/about">About Us</Link></li>
                        <li className="dropdown">
                            <Link href="#">Team Members</Link>
                            <ul>
                                <li><Link href="/team">Team Members 01</Link></li>
                                <li><Link href="/team-2">Team Members 02</Link></li>
                            </ul>
                        </li>
                        <li className="dropdown">
                            <Link href="#">Blog</Link>
                            <ul>
                                <li><Link href="/blog">Blog Grid 01</Link></li>
                                <li><Link href="/blog-2">Blog Grid 02</Link></li>
                                <li><Link href="/blog-3">Blog List 01</Link></li>
                                <li><Link href="/blog-4">Blog List 02</Link></li>
                                <li><Link href="/blog-single">Blog Single Post</Link></li>
                            </ul>
                        </li>
                        <li className="dropdown">
                            <Link href="#">Case Studies</Link>
                            <ul>
                                <li><Link href="/case">Case Grid 01</Link></li>
                                <li><Link href="/case-2">Case Grid 02</Link></li>
                                <li><Link href="/case-3">Case Grid 03</Link></li>
                                <li><Link href="/case-masonry">Case Masonry</Link></li>
                                <li><Link href="/case-single">Case Single Post</Link></li>
                            </ul>
                        </li>
                        <li><Link href="/404">404</Link></li>
                        <li><Link href="/coming-soon">Coming Soon</Link></li>
                    </ul>
                </li>
                <li className="dropdown"><Link href="#">Employers</Link>
                    <ul>
                        <li><Link href="/employers-overview">Employers Overview</Link></li>
                        <li>
                            <Link href="/job">Place Your Job</Link>
                        </li>
                        <li><Link href="/testimonials">Testimonials</Link></li>
                        <li><Link href="/faq">Faq’s</Link></li>
                    </ul>
                </li>
                <li className="dropdown"><Link href="#">Solutions</Link>
                    <ul>
                        <li><Link href="/solutions-1">Solutions 01</Link></li>
                        <li><Link href="/solutions-2">Solutions 02</Link></li>
                        <li>
                            <Link href="/solution01-temporary-stafing">
                                Temporary Stafing
                            </Link>
                        </li>
                        <li>
                            <Link href="/solution02-contract-stafing">
                                Contract Staffing
                            </Link>
                        </li>
                        <li>
                            <Link href="/solution03-project-based">
                                Project-Based Hiring
                            </Link>
                        </li>
                        <li>
                            <Link href="/solution04-permanent-stafing">
                                Permanent Staffing
                            </Link>
                        </li>
                        <li>
                            <Link href="/solution05-payrolling">
                                Payrolling
                            </Link>
                        </li>
                        <li>
                            <Link href="/solution06-outsourcing">
                                Outsourcing
                            </Link>
                        </li>
                    </ul>
                </li> 
                <li className="dropdown"><Link href="#">Job Seekers</Link>
                    <ul>
                        <li>
                            <Link href="/job-seekers-overview">Job Seekers Overview</Link>
                        </li>
                        <li>
                            <Link href="/job-openings">Job Openings</Link>
                        </li>
                        <li>
                            <Link href="/job-details">Job Details</Link>
                        </li>
                        <li>
                            <Link href="/apply-now">Apply Now</Link>
                        </li>
                    </ul>
                </li> 
                <li><Link href="/contact">Contact</Link></li>
            </ul>
        </>
    )
}
