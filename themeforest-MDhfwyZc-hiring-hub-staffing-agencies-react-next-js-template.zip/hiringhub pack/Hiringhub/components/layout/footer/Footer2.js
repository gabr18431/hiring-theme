import Link from "next/link"

export default function Footer2() {
    return (
        <>
        
            <footer className="footer-style2">
                <div className="footer-main">
                    <div className="container">
                        <div className="row">
                            <div className="col-xl-4 col-lg-6 col-md-6">
                                <div className="single-footer-widget mr60">
                                    <div className="footer-widget-info-box">
                                        <div className="logo-box">
                                            <Link href="#">
                                                <img src="assets/images/resources/footer-v2-logo1.png" alt="logo"/>
                                            </Link>
                                        </div>
                                        <div className="text-box">
                                            <p>
                                                Have to be repudiated & annoyances<br/>accepted. The wise man therefore
                                                always<br/>holds in these matters.
                                            </p>
                                        </div>
                                        <div className="social-links">
                                            <ul>
                                                <li>
                                                    <Link href="https://www.facebook.com/">
                                                        <span className="icon-facebook"></span>
                                                    </Link>
                                                </li>
                                                <li>
                                                    <Link href="https://x.com/i/flow/login">
                                                        <span className="icon-twitter"></span>
                                                    </Link>
                                                </li>
                                                <li>
                                                    <Link href="https://www.instagram.com/accounts/login/?hl=en">
                                                        <span className="icon-instagram-logo"></span>
                                                    </Link>
                                                </li>
                                                <li>
                                                    <Link href="https://www.youtube.com/">
                                                        <span className="icon-youtube"></span>
                                                    </Link>
                                                </li>
                                            </ul>
                                        </div>
                                        <div className="copyright-text copyright-text__style2">
                                            <p>
                                                <Link href="/index-2">© {new Date().getFullYear()} Hiringhub</Link> Recruiters, All <br/>
                                                Rights Reserved.
                                            </p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            
                            <div className="col-xl-4 col-lg-6 col-md-6 single-widget">
                                <div className="single-footer-widget single-footer-widget-link-box">
                                    <div className="title">
                                        <h3>Useful Links</h3>
                                    </div>

                                    <div className="row">
                                        <div className="col-xl-6">

                                            <div className="footer-widget-links">
                                                <ul>
                                                    <li>
                                                        <Link href="/job-seekers-overview">
                                                            Benefits
                                                            <i className="icon-arrow-angle-pointing-to-right arrow-hover"></i>
                                                        </Link>
                                                    </li>
                                                    <li>
                                                        <Link href="/solution06-outsourcing">
                                                            Resources
                                                            <i className="icon-arrow-angle-pointing-to-right arrow-hover"></i>
                                                        </Link>
                                                    </li>
                                                    <li>
                                                        <Link href="/job-openings">
                                                            Opportunities
                                                            <i className="icon-arrow-angle-pointing-to-right arrow-hover"></i>
                                                        </Link>
                                                    </li>
                                                    <li>
                                                        <Link href="/apply-now">
                                                            Portal
                                                            <i className="icon-arrow-angle-pointing-to-right arrow-hover"></i>
                                                        </Link>
                                                    </li>
                                                    <li>
                                                        <Link href="/testimonials">
                                                            Testimonials
                                                            <i className="icon-arrow-angle-pointing-to-right arrow-hover"></i>
                                                        </Link>
                                                    </li>
                                                    <li>
                                                        <Link href="/employers-overview">
                                                            Training
                                                            <i className="icon-arrow-angle-pointing-to-right arrow-hover"></i>
                                                        </Link>
                                                    </li>
                                                    <li>
                                                        <Link href="/faq">
                                                            Faq’s
                                                            <i className="icon-arrow-angle-pointing-to-right arrow-hover"></i>
                                                        </Link>
                                                    </li>
                                                </ul>
                                            </div>
                                        </div>

                                        <div className="col-xl-6">
                                            <div className="footer-widget-links">
                                                <ul>
                                                    <li>
                                                        <Link href="/about">
                                                            About Us
                                                            <i className="icon-arrow-angle-pointing-to-right arrow-hover">
                                                            </i>
                                                        </Link>
                                                    </li>
                                                    <li>
                                                        <Link href="/team">
                                                            Leaderships
                                                            <i className="icon-arrow-angle-pointing-to-right arrow-hover">
                                                            </i>
                                                        </Link>
                                                    </li>
                                                    <li>
                                                        <Link href="/solutions-1">
                                                            Services
                                                            <i className="icon-arrow-angle-pointing-to-right arrow-hover">
                                                            </i>
                                                        </Link>
                                                    </li>
                                                    <li>
                                                        <Link href="/job-details">
                                                            Industries Served
                                                            <i className="icon-arrow-angle-pointing-to-right arrow-hover">
                                                            </i>
                                                        </Link>
                                                    </li>
                                                    <li>
                                                        <Link href="/contact">
                                                            Locations
                                                            <i className="icon-arrow-angle-pointing-to-right arrow-hover">
                                                            </i>
                                                        </Link>
                                                    </li>
                                                    <li>
                                                        <Link href="/case-single">
                                                            Case Studies
                                                            <i className="icon-arrow-angle-pointing-to-right arrow-hover">
                                                            </i>
                                                        </Link>
                                                    </li>
                                                </ul>
                                            </div>
                                        </div>

                                    </div>

                                </div>
                            </div>
                            
                            <div className="col-xl-4 col-lg-10 col-md-12 single-widget">
                                <div className="single-footer-widget single-footer-widget-upload-resume">
                                    <div className="title">
                                        <h3>Submit your<br/>CV for Customized Job<br/>Pairings!...</h3>
                                    </div>
                                    <div className="upload-resume-form">
                                        <form action="index.html" method="post">
                                            <div className="form-group">
                                                <input type="email" name="email" placeholder="Drop files here..."
                                                    required=""/>
                                                <button className="submit btn-one">
                                                    <span className="txt">Browse</span>
                                                </button>
                                            </div>
                                        </form>
                                    </div>
                                    <div className="upload-resume-btn">
                                        <div className="img-box">
                                            <img src="assets/images/footer/footer-v2-img1.jpg" alt="image"/>
                                        </div>
                                        <Link href="apply-now.html">
                                            Need to update your<br/>resume?
                                            <i className="icon-arrow-angle-pointing-to-right"></i>
                                        </Link>
                                    </div>
                                </div>
                            </div>

                        </div>
                    </div>
                </div>
                

                <div className="footer-bottom">
                    <div className="container">
                        <div className="bottom-inner">
                            <div className="footer-menu">
                                <ul>
                                    <li><Link href="#">Privacy Policy</Link></li>
                                    <li><Link href="#">Terms & Conditions</Link></li>
                                    <li><Link href="#">Legal</Link></li>
                                </ul>
                            </div>

                        </div>
                    </div>
                </div>
            </footer>

        </>
    )
}
