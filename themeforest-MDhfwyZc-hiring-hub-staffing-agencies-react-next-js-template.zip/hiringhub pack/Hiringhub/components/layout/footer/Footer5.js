import Link from "next/link"

export default function Footer5() {
    return (
        <>
        
            <footer className="footer-style5">
                <div className="footer-style5__main">
                    <div className="container">
                        <div className="row">
                            
                            <div className="col-xl-3 col-lg-6 col-md-6 single-widget">
                                <div className="single-footer-widget single-footer-widget-mobile-app">
                                    <div className="title">
                                        <h3>Mobile App</h3>
                                    </div>
                                    <div className="footer-widget-mobile-app">
                                        <div className="text">
                                            <p>Employers to post jobs & review<br/>candidate applications.</p>
                                        </div>
                                        <div className="store-app">
                                            <ul>
                                                <li>
                                                    <a
                                                        href="https://play.google.com/store/search?q=ynbeweging&c=apps&hl=nl">
                                                        <i className="icon-play-store"></i>
                                                    </a>
                                                </li>
                                                <li>
                                                    <Link href="https://apps.apple.com/us/app/apple-store/id375380948">
                                                        <i className="icon-apple"></i>
                                                    </Link>
                                                </li>
                                            </ul>
                                        </div>
                                        <div className="copyright-text">
                                            <p>
                                                <Link href="index-5.html">© {new Date().getFullYear()} Hiringhub</Link> Recruiters.
                                            </p>
                                        </div>
                                    </div>
                                </div>
                            </div>


                            <div className="col-xl-3 col-lg-6 col-md-6 single-widget">
                                <div className="single-footer-widget single-footer-widget-link-box">
                                    <div className="title">
                                        <h3>Employee</h3>
                                    </div>
                                    <div className="footer-widget-links">
                                        <ul>
                                            <li>
                                                <Link href="/job-seekers-overview">
                                                    Benefits
                                                    <i className="icon-arrow-angle-pointing-to-right arrow-hover"></i>
                                                </Link>
                                            </li>
                                            <li>
                                                <Link href="/solution06-outsourcing">
                                                    Resources
                                                    <i className="icon-arrow-angle-pointing-to-right arrow-hover"></i>
                                                </Link>
                                            </li>
                                            <li>
                                                <Link href="/job-openings">
                                                    Opportunities
                                                    <i className="icon-arrow-angle-pointing-to-right arrow-hover"></i>
                                                </Link>
                                            </li>
                                            <li>
                                                <Link href="/apply-now">
                                                    Portal
                                                    <i className="icon-arrow-angle-pointing-to-right arrow-hover"></i>
                                                </Link>
                                            </li>
                                            <li>
                                                <Link href="/testimonials">
                                                    Testimonials
                                                    <i className="icon-arrow-angle-pointing-to-right arrow-hover"></i>
                                                </Link>
                                            </li>
                                            <li>
                                                <Link href="/employers-overview">
                                                    Training
                                                    <i className="icon-arrow-angle-pointing-to-right arrow-hover"></i>
                                                </Link>
                                            </li>
                                            <li>
                                                <Link href="/faq">
                                                    Faq’s
                                                    <i className="icon-arrow-angle-pointing-to-right arrow-hover"></i>
                                                </Link>
                                            </li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                            
                            <div className="col-xl-3 col-lg-6 col-md-6 single-widget">
                                <div className="single-footer-widget single-footer-widget-link-box">
                                    <div className="title">
                                        <h3>Employer</h3>
                                    </div>
                                    <div className="footer-widget-links">
                                        <ul>
                                            <li>
                                                <Link href="/job">
                                                    Job Postings
                                                    <i className="icon-arrow-angle-pointing-to-right arrow-hover"></i>
                                                </Link>
                                            </li>
                                            <li>
                                                <Link href="/solutions-1">
                                                    Hiring Solutions
                                                    <i className="icon-arrow-angle-pointing-to-right arrow-hover"></i>
                                                </Link>
                                            </li>
                                            <li>
                                                <Link href="/solution06-outsourcing">
                                                    Resources
                                                    <i className="icon-arrow-angle-pointing-to-right arrow-hover"></i>
                                                </Link>
                                            </li>
                                            <li>
                                                <Link href="/testimonials">
                                                    Testimonials
                                                    <i className="icon-arrow-angle-pointing-to-right arrow-hover"></i>
                                                </Link>
                                            </li>
                                            <li>
                                                <Link href="/faq">
                                                    Faq’s
                                                    <i className="icon-arrow-angle-pointing-to-right arrow-hover"></i>
                                                </Link>
                                            </li>
                                            <li>
                                                <Link href="/team">
                                                    Support
                                                    <i className="icon-arrow-angle-pointing-to-right arrow-hover"></i>
                                                </Link>
                                            </li>
                                            <li>
                                                <Link href="/about">
                                                    Find Talents
                                                    <i className="icon-arrow-angle-pointing-to-right arrow-hover"></i>
                                                </Link>
                                            </li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                            
                            <div className="col-xl-3 col-lg-6 col-md-6 single-widget">
                                <div className="single-footer-widget single-footer-widget-gallery">
                                    <div className="title">
                                        <h3>Gallery</h3>
                                    </div>
                                    <div className="footer-widget-gallery">
                                        <ul className="clearfix">
                                            <li>
                                                <div className="img-box">
                                                    <img src="assets/images/footer/footer-v5-img1.jpg" alt="image"/>
                                                    <Link href="#">
                                                        <i className="icon-zoom-in"></i>
                                                    </Link>
                                                </div>
                                            </li>
                                            <li>
                                                <div className="img-box">
                                                    <img src="assets/images/footer/footer-v5-img2.jpg" alt="image"/>
                                                    <Link href="#">
                                                        <i className="icon-zoom-in"></i>
                                                    </Link>
                                                </div>
                                            </li>
                                            <li>
                                                <div className="img-box">
                                                    <img src="assets/images/footer/footer-v5-img3.jpg" alt="image"/>
                                                    <Link href="#">
                                                        <i className="icon-zoom-in"></i>
                                                    </Link>
                                                </div>
                                            </li>

                                            <li>
                                                <div className="img-box">
                                                    <img src="assets/images/footer/footer-v5-img4.jpg" alt="image"/>
                                                    <Link href="#">
                                                        <i className="icon-zoom-in"></i>
                                                    </Link>
                                                </div>
                                            </li>
                                            <li>
                                                <div className="img-box">
                                                    <img src="assets/images/footer/footer-v5-img5.jpg" alt="image"/>
                                                    <Link href="#">
                                                        <i className="icon-zoom-in"></i>
                                                    </Link>
                                                </div>
                                            </li>
                                            <li>
                                                <div className="img-box">
                                                    <img src="assets/images/footer/footer-v5-img6.jpg" alt="image"/>
                                                    <Link href="#">
                                                        <i className="icon-zoom-in"></i>
                                                    </Link>
                                                </div>
                                            </li>
                                        </ul>

                                        <div className="btn-box">
                                            <Link href="case-masonry.html">
                                                Explore More
                                                <i className="icon-arrow-angle-pointing-to-right"></i>
                                            </Link>
                                        </div>
                                    </div>
                                </div>
                            </div>


                        </div>
                    </div>
                </div>


                <div className="footer-style5__middle">
                    <div className="container">
                        <ul className="row">

                            <li className="col-xl-3 col-lg-6 col-md-6">
                                <div className="logo-box">
                                    <Link href="index-5.html">
                                        <img src="assets/images/resources/footer-v3-logo1.png" alt="image"/>
                                    </Link>
                                </div>
                            </li>

                            <li className="col-xl-3 col-lg-6 col-md-6">
                                <div className="single-box">
                                    <h6>Phone</h6>
                                    <p><Link href="tel:18885678907891">+1 888.56.7890 & 7891</Link></p>
                                </div>
                            </li>

                            <li className="col-xl-3 col-lg-6 col-md-6">
                                <div className="single-box">
                                    <h6>Email</h6>
                                    <p><Link href="mailto:support@hiringhub.com">support@hiringhub.com</Link></p>
                                </div>
                            </li>

                            <li className="col-xl-3 col-lg-6 col-md-6">
                                <div className="single-box">
                                    <h6>Location</h6>
                                    <p>54 Berrick 2nd St Boston, 02115.</p>
                                </div>
                            </li>

                        </ul>
                    </div>
                </div>
                
                <div className="footer-style5__bottom">
                    <div className="footer-style5__bottom-bg"
                        style={{ backgroundImage: "url(assets/images/backgrounds/footer-v5-bg1.jpg)" }}></div>
                    <div className="container">
                        <div className="sec-title withtext text-center">
                            <div className="sub-title">
                                <h4>Get call back</h4>
                            </div>
                            <h2>Schedule a Call with Expert</h2>
                            <div className="text">
                                <p>
                                    Long established fact that a reader will be distracted.
                                </p>
                            </div>
                        </div>

                        <div className="footer-style5__bottom-form">

                            <form id="request-form" name="request_form" className="default-form2" action="/">
                                <div className="row">
                                    <div className="col-xl-3">
                                        <div className="form-group">
                                            <div className="input-box">
                                                <input type="text" name="form_name" id="formName" placeholder="Name"
                                                    required=""/>
                                            </div>
                                        </div>
                                    </div>
                                    <div className="col-xl-3">
                                        <div className="form-group">
                                            <div className="input-box">
                                                <input type="text" name="form_phone" value="" id="formPhone"
                                                    placeholder="Ph Num"/>
                                            </div>
                                        </div>
                                    </div>


                                    <div className="col-xl-3">
                                        <div className="form-group">
                                            <div className="select-box clearfix">
                                                <select className="wide">
                                                    <option data-display="I am an">
                                                        I am an
                                                    </option>
                                                    <option value="6">Doctor</option>
                                                    <option value="2">Teacher</option>
                                                    <option value="4">Engineer</option>
                                                </select>
                                            </div>
                                        </div>
                                    </div>

                                    <div className="col-xl-3">
                                        <div className="form-group">
                                            <div className="button-box">
                                                <button className="btn-one" type="submit" data-loading-text="Please wait...">
                                                    <span className="txt">
                                                        Send Request
                                                    </span>
                                                </button>
                                            </div>
                                        </div>
                                    </div>

                                </div>
                            </form>


                        </div>

                        <div className="footer-style5__bottom-text">
                            <p>
                                Answers Await,<Link href="/faq">Explore our FAQ section<i
                                        className="icon-arrow-angle-pointing-to-right"></i></Link>
                            </p>
                        </div>

                    </div>
                </div>

            </footer>

        </>
    )
}
