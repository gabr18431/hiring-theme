import Link from "next/link"

export default function Footer3() {
    return (
        <>
        
            <footer className="footer-style3">
                <div className="footer-top__style3">
                    <div className="container">
                        <div className="row">

                            <div className="col-xl-6">
                                <div className="footer-top__style3-single">
                                    <div className="footer-top__style3-single-bg"
                                        style={{ backgroundImage: "url(assets/images/footer/footer-v3-img1.jpg)" }}>
                                    </div>
                                    <div className="footer-top__style3-single-inner">
                                        <div className="sec-title withtext">
                                            <div className="sub-title">
                                                <h4>Mobile App</h4>
                                            </div>
                                            <h2>Download Our App</h2>
                                            <div className="text">
                                                <p>Employers to post jobs and review candidate applications.</p>
                                            </div>
                                        </div>
                                        <div className="btn-box">
                                            <a className="btn-one" href="https://play.google.com/store/games?hl=en">
                                                <i className="icon-play-store"></i>
                                                <span className="txt">Goolge Play</span>
                                            </a>
                                            <a className="btn-one style2" href="https://www.apple.com/store">
                                                <i className="icon-apple"></i>
                                                <span className="txt">App Store</span>
                                            </a>
                                        </div>
                                    </div>

                                </div>
                            </div>

                            <div className="col-xl-6">
                                <div className="footer-top__style3-single">
                                    <div className="footer-top__style3-single-bg"
                                        style={{ backgroundImage: "url(assets/images/footer/footer-v3-img2.jpg)" }}>
                                    </div>
                                    <div className="footer-top__style3-single-inner">
                                        <div className="sec-title withtext">
                                            <div className="sub-title">
                                                <h4>Newsletter</h4>
                                            </div>
                                            <h2>Subscribe Our Newsletter</h2>
                                            <div className="text">
                                                <p>Subcribe to receive news & updates in your inbox.</p>
                                            </div>
                                        </div>
                                        <div className="footer-top__style3-single-inner-form">
                                            <form action="/" method="post">
                                                <div className="form-group">
                                                    <input type="email" name="email" placeholder="Enter your email..."
                                                        required=""/>
                                                    <button className="btn-one submit">
                                                        <span className="txt">Subscribe Us</span>
                                                    </button>
                                                </div>
                                            </form>
                                        </div>
                                    </div>

                                </div>
                            </div>

                        </div>
                    </div>
                </div>
                
                <div className="footer-main">
                    <div className="footer-main__shape">
                        <img src="assets/images/pattern/footer-v3-pattern1.png" alt="pattern"/>
                    </div>
                    <div className="container">
                        <div className="row">
                            
                            <div className="col-xl-3 col-lg-6 col-md-6">
                                <div className="single-footer-widget single-footer-widget--style3">
                                    <div className="footer-widget-info-box">
                                        <div className="logo-box">
                                            <Link href="#">
                                                <img src="assets/images/resources/footer-v3-logo1.png" alt="logo"/>
                                            </Link>
                                        </div>

                                        <div className="footer-widget-address-select-box">
                                            <div className="icon">
                                                <span className="icon-map"></span>
                                            </div>
                                            <div className="select-box clearfix">
                                                <select className="wide">
                                                    <option data-display="California, USA">California, USA</option>
                                                    <option value="1">Paris, Fra</option>
                                                    <option value="2">Berlin, Ger</option>
                                                    <option value="3">Rome, Ita</option>
                                                    <option value="3">Dhaka, ban</option>
                                                </select>
                                            </div>
                                        </div>

                                        <div className="footer-widget-language-select-box">
                                            <div className="language-switcher-style1">
                                                <div className="icon">
                                                    <span className="icon-planet"></span>
                                                </div>
                                                <div className="select-box clearfix">
                                                    <select className="wide">
                                                        <option data-display="Us - En">Us - En</option>
                                                        <option value="1">Fra</option>
                                                        <option value="2">Ger</option>
                                                        <option value="3">Ita</option>
                                                        <option value="3">ban</option>
                                                    </select>
                                                </div>
                                            </div>
                                        </div>

                                    </div>
                                </div>
                            </div>
                            
                            <div className="col-xl-3 col-lg-6 col-md-6 single-widget">
                                <div className="single-footer-widget single-footer-widget-link-box in-style-2">
                                    <div className="title">
                                        <h3>Employee</h3>
                                    </div>

                                    <div className="footer-widget-links in-style-2">
                                        <ul>
                                            <li>
                                                <Link href="/job-seekers-overview">
                                                    Benefits
                                                    <i className="icon-arrow-angle-pointing-to-right arrow-hover"></i>
                                                </Link>
                                            </li>
                                            <li>
                                                <Link href="/solution06-outsourcing">
                                                    Resources
                                                    <i className="icon-arrow-angle-pointing-to-right arrow-hover"></i>
                                                </Link>
                                            </li>
                                            <li>
                                                <Link href="/job-openings">
                                                    Opportunities
                                                    <i className="icon-arrow-angle-pointing-to-right arrow-hover"></i>
                                                </Link>
                                            </li>
                                            <li>
                                                <Link href="/apply-now">
                                                    Portal
                                                    <i className="icon-arrow-angle-pointing-to-right arrow-hover"></i>
                                                </Link>
                                            </li>
                                            <li>
                                                <Link href="/testimonials">
                                                    Testimonials
                                                    <i className="icon-arrow-angle-pointing-to-right arrow-hover"></i>
                                                </Link>
                                            </li>
                                            <li>
                                                <Link href="/employers-overview">
                                                    Training
                                                    <i className="icon-arrow-angle-pointing-to-right arrow-hover"></i>
                                                </Link>
                                            </li>
                                            <li>
                                                <Link href="/faq">
                                                    Faq’s
                                                    <i className="icon-arrow-angle-pointing-to-right arrow-hover"></i>
                                                </Link>
                                            </li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                            
                            <div className="col-xl-3 col-lg-6 col-md-6 single-widget">
                                <div className="single-footer-widget single-footer-widget-link-box in-style-2">
                                    <div className="title">
                                        <h3>Employer</h3>
                                    </div>

                                    <div className="footer-widget-links in-style-2">
                                        <ul>
                                            <li>
                                                <Link href="/job">
                                                    Job Postings
                                                    <i className="icon-arrow-angle-pointing-to-right arrow-hover"></i>
                                                </Link>
                                            </li>
                                            <li>
                                                <Link href="/solutions-2">
                                                    Hiring Solutions
                                                    <i className="icon-arrow-angle-pointing-to-right arrow-hover"></i>
                                                </Link>
                                            </li>
                                            <li>
                                                <Link href="/solution06-outsourcing">
                                                    Resources
                                                    <i className="icon-arrow-angle-pointing-to-right arrow-hover"></i>
                                                </Link>
                                            </li>
                                            <li>
                                                <Link href="/testimonials">
                                                    Testimonials
                                                    <i className="icon-arrow-angle-pointing-to-right arrow-hover"></i>
                                                </Link>
                                            </li>
                                            <li>
                                                <Link href="/faq">
                                                    Faq’s
                                                    <i className="icon-arrow-angle-pointing-to-right arrow-hover"></i>
                                                </Link>
                                            </li>
                                            <li>
                                                <Link href="/team-2">
                                                    Support
                                                    <i className="icon-arrow-angle-pointing-to-right arrow-hover"></i>
                                                </Link>
                                            </li>
                                            <li>
                                                <Link href="/about">
                                                    Find Talents
                                                    <i className="icon-arrow-angle-pointing-to-right arrow-hover"></i>
                                                </Link>
                                            </li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                            

                            <div className="col-xl-3 col-lg-6 col-md-6 single-widget">
                                <div className="single-footer-widget single-footer-widget-blog-post">
                                    <div className="title">
                                        <h3>Popular Post</h3>
                                    </div>
                                    <div className="blog-list">
                                        <ul>
                                            <li>
                                                <span>News & Tips</span>
                                                <h4><Link href="/blog-single">Utilizing Technology in the<br/>Hiring
                                                        Process.</Link></h4>
                                                <Link href="/blog-single">
                                                    <i className="icon-right-arrow-1"></i>
                                                </Link>
                                            </li>
                                            <li>
                                                <span>Job Seekers</span>
                                                <h4><Link href="/blog-single">Navigating Legalities in<br/>Staffing and
                                                        Hiring.</Link></h4>
                                                <Link href="/blog-single">
                                                    <i className="icon-right-arrow-1"></i>
                                                </Link>
                                            </li>
                                        </ul>
                                    </div>
                                </div>
                            </div>

                        </div>
                    </div>
                </div>
                

                <div className="footer-bottom footer-bottom-style3">
                    <div className="container">
                        <div className="bottom-inner">
                            <div className="copyright-text">
                                <p>
                                    Copyrights <Link href="index-3.html">© {new Date().getFullYear()} Hiringhub</Link> Recruiters, All Rights
                                    Reserved.
                                </p>
                            </div>
                            <div className="footer-menu">
                                <ul>
                                    <li><Link href="#">Privacy Policy</Link></li>
                                    <li><Link href="#">Terms &amp; Conditions</Link></li>
                                    <li><Link href="#">Legal</Link></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </footer>

        </>
    )
}
