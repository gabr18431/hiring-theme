import Link from "next/link"

export default function Footer6() {
    return (
        <>
        
        <footer className="footer-style1 instyle--1">
            
            <div className="footer-top">
                <div className="container">
                    <div className="footer-top__inner">
                        <div className="subscribe-box">
                            <div className="title-box">
                                <div className="icon">
                                    <span className="icon-notification"><span className="path1"></span><span
                                            className="path2"></span>
                                    </span>
                                </div>
                                <h3>Subscribe &<br/>Receive Updates</h3>
                            </div>
                            <div className="subscribe-box-form">
                                <form action="index.html" method="post">
                                    <div className="form-group">
                                        <input type="email" name="email" placeholder="Enter your email..." required=""/>
                                        <button className="submit btn-one">
                                            <span className="txt">Subscribe Us</span>
                                        </button>
                                    </div>
                                </form>
                            </div>
                        </div>
                        <div className="subscribe-box-social-links">
                            <ul>
                                <li>
                                    <Link href="https://www.facebook.com/">
                                        <span className="icon-facebook"></span>
                                    </Link>
                                </li>
                                <li>
                                    <Link href="https://x.com/i/flow/login">
                                        <span className="icon-twitter"></span>
                                    </Link>
                                </li>
                                <li>
                                    <Link href="https://www.instagram.com/accounts/login/?hl=en">
                                        <span className="icon-instagram-logo"></span>
                                    </Link>
                                </li>
                                <li>
                                    <Link href="https://www.youtube.com/">
                                        <span className="icon-youtube"></span>
                                    </Link>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
            
            <div className="footer-main">
                <div className="container">
                    <div className="row">
                        
                        <div className="col-xl-3 col-lg-6 col-md-6">
                            <div className="single-footer-widget">
                                <div className="footer-meeting-icon">
                                    <span className="icon-meet"><span className="path1"></span><span className="path2"></span><span
                                            className="path3"></span><span className="path4"></span><span
                                            className="path5"></span><span className="path6"></span><span className="path7"></span>
                                    </span>
                                </div>
                                <div className="title">
                                    <h3>Book a Meeting</h3>
                                </div>
                                <div className="footer-widget-meeting-info">
                                    <div className="text">
                                        <p>Discuss overseas hiring: 15-Min Strategy call with experts.</p>
                                    </div>
                                    <div className="line-box"></div>
                                    <div className="btn-box">
                                        <Link href="contact.html">
                                            Schedule Now
                                            <span className="icon-arrow-angle-pointing-to-right"></span>
                                        </Link>
                                    </div>
                                </div>
                            </div>
                        </div>
                        
                        <div className="col-xl-3 col-lg-6 col-md-6">
                            <div className="single-footer-widget">
                                <div className="title">
                                    <h3>Get in Touch</h3>
                                </div>
                                <div className="footer-widget-contact-info">
                                    <ul>
                                        <li>
                                            <div className="text">
                                                <h6>Location</h6>
                                                <p>54 Berrick 2nd St Boston, MCA<br/>02115, United States.</p>
                                            </div>
                                        </li>
                                        <li>
                                            <div className="text">
                                                <h6>Helpdesk</h6>
                                                <p>
                                                    <Link href="mailto:getsupport@gmail.com">getsupport@hiringhub.com</Link>
                                                </p>
                                                <h3><Link href="tel:1888567890">+1 888.56.7890</Link></h3>
                                            </div>
                                        </li>
                                    </ul>
                                    <div className="btn-box">
                                        <Link href="contact.html">
                                            Nearest Location
                                            <span className="icon-arrow-angle-pointing-to-right"></span>
                                        </Link>
                                    </div>
                                </div>
                            </div>
                        </div>
                        
                        <div className="col-xl-2 col-lg-6 col-md-6 single-widget">
                            <div className="single-footer-widget marbtm">
                                <div className="single-footer-widget single-footer-widget-link-box">
                                    <div className="title">
                                        <h3>Employee</h3>
                                    </div>
                                    <div className="footer-widget-links">
                                        <ul>
                                            <li>
                                                <Link href="job-seekers-overview.html">
                                                    Benefits
                                                    <i className="icon-arrow-angle-pointing-to-right arrow-hover"></i>
                                                </Link>
                                            </li>
                                            <li>
                                                <Link href="solution06-outsourcing.html">
                                                    Resources
                                                    <i className="icon-arrow-angle-pointing-to-right arrow-hover"></i>
                                                </Link>
                                            </li>
                                            <li>
                                                <Link href="job-openings.html">
                                                    Opportunities
                                                    <i className="icon-arrow-angle-pointing-to-right arrow-hover"></i>
                                                </Link>
                                            </li>
                                            <li>
                                                <Link href="apply-now.html">
                                                    Portal
                                                    <i className="icon-arrow-angle-pointing-to-right arrow-hover"></i>
                                                </Link>
                                            </li>
                                            <li>
                                                <Link href="testimonials.html">
                                                    Testimonials
                                                    <i className="icon-arrow-angle-pointing-to-right arrow-hover"></i>
                                                </Link>
                                            </li>
                                            <li>
                                                <Link href="employers-overview.html">
                                                    Training
                                                    <i className="icon-arrow-angle-pointing-to-right arrow-hover"></i>
                                                </Link>
                                            </li>
                                            <li>
                                                <Link href="faq.html">
                                                    Faq’s
                                                    <i className="icon-arrow-angle-pointing-to-right arrow-hover"></i>
                                                </Link>
                                            </li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                        </div>
                        
                        <div className="col-xl-2 col-lg-6 col-md-6 single-widget">
                            <div className="single-footer-widget marbtm">
                                <div className="single-footer-widget single-footer-widget-link-box">
                                    <div className="title">
                                        <h3>Employer</h3>
                                    </div>
                                    <div className="footer-widget-links">
                                        <ul>
                                            <li>
                                                <Link href="job.html">
                                                    Job Postings
                                                    <i className="icon-arrow-angle-pointing-to-right arrow-hover"></i>
                                                </Link>
                                            </li>
                                            <li>
                                                <Link href="solutions-1.html">
                                                    Hiring Solutions
                                                    <i className="icon-arrow-angle-pointing-to-right arrow-hover"></i>
                                                </Link>
                                            </li>
                                            <li>
                                                <Link href="solution06-outsourcing.html">
                                                    Resources
                                                    <i className="icon-arrow-angle-pointing-to-right arrow-hover"></i>
                                                </Link>
                                            </li>
                                            <li>
                                                <Link href="testimonials.html">
                                                    Testimonials
                                                    <i className="icon-arrow-angle-pointing-to-right arrow-hover"></i>
                                                </Link>
                                            </li>
                                            <li>
                                                <Link href="faq.html">
                                                    Faq’s
                                                    <i className="icon-arrow-angle-pointing-to-right arrow-hover"></i>
                                                </Link>
                                            </li>
                                            <li>
                                                <Link href="team.html">
                                                    Support
                                                    <i className="icon-arrow-angle-pointing-to-right arrow-hover"></i>
                                                </Link>
                                            </li>
                                            <li>
                                                <Link href="about.html">
                                                    Find Talents
                                                    <i className="icon-arrow-angle-pointing-to-right arrow-hover"></i>
                                                </Link>
                                            </li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                        </div>
                        
                        <div className="col-xl-2 col-lg-6 col-md-6 single-widget">
                            <div className="single-footer-widget marbtm">
                                <div className="single-footer-widget single-footer-widget-link-box">
                                    <div className="title">
                                        <h3>Essentials</h3>
                                    </div>
                                    <div className="footer-widget-links">
                                        <ul>
                                            <li>
                                                <Link href="about.html">
                                                    About Us
                                                    <i className="icon-arrow-angle-pointing-to-right arrow-hover"></i>
                                                </Link>
                                            </li>
                                            <li>
                                                <Link href="team.html">
                                                    Leaderships
                                                    <i className="icon-arrow-angle-pointing-to-right arrow-hover"></i>
                                                </Link>
                                            </li>
                                            <li>
                                                <Link href="solutions-1.html">
                                                    Services
                                                    <i className="icon-arrow-angle-pointing-to-right arrow-hover"></i>
                                                </Link>
                                            </li>
                                            <li>
                                                <Link href="job-details.html">
                                                    Industries Served
                                                    <i className="icon-arrow-angle-pointing-to-right arrow-hover"></i>
                                                </Link>
                                            </li>
                                            <li>
                                                <Link href="contact.html">
                                                    Locations
                                                    <i className="icon-arrow-angle-pointing-to-right arrow-hover"></i>
                                                </Link>
                                            </li>
                                            <li>
                                                <Link href="case-single.html">
                                                    Case Studies
                                                    <i className="icon-arrow-angle-pointing-to-right arrow-hover"></i>
                                                </Link>
                                            </li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                        </div>

                    </div>
                </div>
            </div>

            <div className="footer-bottom">
                <div className="container">
                    <div className="bottom-inner">
                        <div className="copyright-text">
                            <p>
                                Copyrights <Link href="index.html">© {new Date().getFullYear()} Hiringhub</Link> Recruiters, All Rights
                                Reserved.
                            </p>
                        </div>
                        <div className="footer-menu">
                            <ul>
                                <li><Link href="#">Privacy Policy</Link></li>
                                <li><Link href="#">Terms & Conditions</Link></li>
                                <li><Link href="#">Legal</Link></li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </footer>

        </>
    )
}
