import Link from "next/link"

export default function Footer4() {
    return (
        <>
        
            <footer className="footer-style4">
                <div className="container">
                    <div className="footer-main">

                        <div className="footer-style4__inner">
                            <ul>
                                <li></li>
                                <li></li>
                            </ul>
                        </div>
                        <div className="container">
                            <div className="row">


                                <div className="col-xl-3 col-lg-4 col-md-12">
                                    <div className="single-footer-widget-style3 mb50">
                                        <div className="footer-widget-info-box four">
                                            <div className="title">
                                                <h3>Providing your details<br/>ensures tailored info for your<br/>needs.</h3>
                                            </div>
                                            <div className="check-employer-box1 check-employer-box1--style2">
                                                <ul>
                                                    <li>
                                                        <input type="radio" id="employer-yes1" name="employer"
                                                            />
                                                        <label for="employer-yes1" data-amount="25">
                                                            <span></span>
                                                            i’m an Employer
                                                        </label>
                                                    </li>
                                                    <li>
                                                        <input type="radio" id="employer-no1" name="employer"/>
                                                        <label for="employer-no1" data-amount="50">
                                                            <span></span>
                                                            I’M AN EMPLOYEE
                                                        </label>
                                                    </li>
                                                </ul>
                                            </div>
                                            <div className="logo-box">
                                                <Link href="#">
                                                    <img src="assets/images/resources/footer-v3-logo1.png" alt="logo"/>
                                                </Link>
                                            </div>
                                        </div>
                                    </div>
                                </div>


                                <div className="col-xl-6 col-lg-8">
                                    <div className="row">

                                        <div className="col-xl-4 col-lg-4 col-md-4 single-widget">
                                            <div className="single-footer-widget single-footer-widget-link-box instyle3">
                                                <div className="title">
                                                    <h3>Company</h3>
                                                </div>
                                                <div className="footer-widget-links instyle3">
                                                    <ul>
                                                        <li>
                                                            <Link href="/about">
                                                                About Us
                                                                <i
                                                                    className="icon-arrow-angle-pointing-to-right arrow-hover"></i>
                                                            </Link>
                                                        </li>
                                                        <li>
                                                            <Link href="/team">
                                                                Leaderships
                                                                <i
                                                                    className="icon-arrow-angle-pointing-to-right arrow-hover"></i>
                                                            </Link>
                                                        </li>
                                                        <li>
                                                            <Link href="/solutions-1">
                                                                Services
                                                                <i
                                                                    className="icon-arrow-angle-pointing-to-right arrow-hover"></i>
                                                            </Link>
                                                        </li>
                                                        <li>
                                                            <Link href="/job-details">
                                                                Industries Served
                                                                <i
                                                                    className="icon-arrow-angle-pointing-to-right arrow-hover"></i>
                                                            </Link>
                                                        </li>
                                                        <li>
                                                            <Link href="/contact">
                                                                Locations
                                                                <i
                                                                    className="icon-arrow-angle-pointing-to-right arrow-hover"></i>
                                                            </Link>
                                                        </li>
                                                        <li>
                                                            <Link href="/case-single">
                                                                Case Studies
                                                                <i
                                                                    className="icon-arrow-angle-pointing-to-right arrow-hover"></i>
                                                            </Link>
                                                        </li>
                                                    </ul>
                                                </div>
                                            </div>
                                        </div>
                                        
                                        <div className="col-xl-4 col-lg-4 col-md-4 single-widget">
                                            <div className="single-footer-widget single-footer-widget-link-box instyle3">
                                                <div className="title">
                                                    <h3>Useful Links</h3>
                                                </div>
                                                <div className="footer-widget-links instyle3">
                                                    <ul>
                                                        <li>
                                                            <Link href="/job-seekers-overview">
                                                                Benefits
                                                                <i
                                                                    className="icon-arrow-angle-pointing-to-right arrow-hover"></i>
                                                            </Link>
                                                        </li>
                                                        <li>
                                                            <Link href="/solution06-outsourcing">
                                                                Resources
                                                                <i
                                                                    className="icon-arrow-angle-pointing-to-right arrow-hover"></i>
                                                            </Link>
                                                        </li>
                                                        <li>
                                                            <Link href="/job-openings">
                                                                Opportunities
                                                                <i
                                                                    className="icon-arrow-angle-pointing-to-right arrow-hover"></i>
                                                            </Link>
                                                        </li>
                                                        <li>
                                                            <Link href="/apply-now">
                                                                Portal
                                                                <i
                                                                    className="icon-arrow-angle-pointing-to-right arrow-hover"></i>
                                                            </Link>
                                                        </li>
                                                        <li>
                                                            <Link href="/testimonials">
                                                                Testimonials
                                                                <i
                                                                    className="icon-arrow-angle-pointing-to-right arrow-hover"></i>
                                                            </Link>
                                                        </li>
                                                        <li>
                                                            <Link href="/employers-overview">
                                                                Training
                                                                <i
                                                                    className="icon-arrow-angle-pointing-to-right arrow-hover"></i>
                                                            </Link>
                                                        </li>
                                                        <li>
                                                            <Link href="/faq">
                                                                Faq’s
                                                                <i
                                                                    className="icon-arrow-angle-pointing-to-right arrow-hover"></i>
                                                            </Link>
                                                        </li>
                                                    </ul>
                                                </div>
                                            </div>
                                        </div>
                                        
                                        <div className="col-xl-4 col-lg-4 col-md-4 single-widget">
                                            <div className="single-footer-widget single-footer-widget-link-box instyle3">
                                                <div className="title">
                                                    <h3>Service Area</h3>
                                                </div>
                                                <div className="footer-widget-links instyle3">
                                                    <ul>
                                                        <li>
                                                            <Link href="/solutions-1">
                                                                Accounting
                                                                <i
                                                                    className="icon-arrow-angle-pointing-to-right arrow-hover"></i>
                                                            </Link>
                                                        </li>
                                                        <li>
                                                            <Link href="/solutions-1">
                                                                Digital Marketing
                                                                <i
                                                                    className="icon-arrow-angle-pointing-to-right arrow-hover"></i>
                                                            </Link>
                                                        </li>
                                                        <li>
                                                            <Link href="/solutions-1">
                                                                Heathcare
                                                                <i
                                                                    className="icon-arrow-angle-pointing-to-right arrow-hover"></i>
                                                            </Link>
                                                        </li>
                                                        <li>
                                                            <Link href="/solutions-1">
                                                                IT / Software
                                                                <i
                                                                    className="icon-arrow-angle-pointing-to-right arrow-hover"></i>
                                                            </Link>
                                                        </li>
                                                        <li>
                                                            <Link href="/solutions-1">
                                                                Logistics
                                                                <i
                                                                    className="icon-arrow-angle-pointing-to-right arrow-hover"></i>
                                                            </Link>
                                                        </li>
                                                        <li>
                                                            <Link href="/solutions-1">
                                                                Front line Support
                                                                <i
                                                                    className="icon-arrow-angle-pointing-to-right arrow-hover"></i>
                                                            </Link>
                                                        </li>
                                                        <li>
                                                            <Link href="/solutions-1">
                                                                Manufacturing
                                                                <i
                                                                    className="icon-arrow-angle-pointing-to-right arrow-hover"></i>
                                                            </Link>
                                                        </li>
                                                    </ul>
                                                </div>
                                            </div>
                                        </div>

                                    </div>
                                </div>
                                
                                <div className="col-xl-3 col-lg-6 col-md-12 single-widget">
                                    <div className="single-footer-widget single-footer-widget-contact instyle3">
                                        <div className="title">
                                            <h3>Contact</h3>
                                        </div>
                                        <div className="footer-widget-contact-info2">

                                            <ul>
                                                <li>
                                                    <div className="text">
                                                        <p>Phone</p>
                                                        <Link href="tel:1888567890">+1 888.56.7890</Link>
                                                    </div>
                                                </li>
                                                <li>
                                                    <div className="text">
                                                        <p>Email</p>
                                                        <Link href="mailto:employersupport@hiringhub.com">employersupport@hiringhub.com
                                                        </Link>
                                                    </div>
                                                </li>
                                            </ul>

                                            <div className="social-links">
                                                <p>We’re Social </p>
                                                <ul>
                                                    <li>
                                                        <Link href="#">
                                                            <span className="https://www.facebook.com/"></span>
                                                        </Link>
                                                    </li>
                                                    <li>
                                                        <Link href="https://x.com/i/flow/login">
                                                            <span className="icon-twitter"></span>
                                                        </Link>
                                                    </li>
                                                    <li>
                                                        <Link href="https://www.instagram.com/accounts/login/?hl=en">
                                                            <span className="icon-instagram-logo"></span>
                                                        </Link>
                                                    </li>
                                                    <li>
                                                        <Link href="https://www.youtube.com/">
                                                            <span className="icon-youtube"></span>
                                                        </Link>
                                                    </li>
                                                </ul>
                                            </div>

                                        </div>
                                    </div>
                                </div>

                            </div>
                        </div>
                    </div>
                </div>
                
                <div className="footer-bottom footer-bottom3">
                    <div className="container">
                        <div className="bottom-inner">
                            <div className="footer-menu">
                                <ul>
                                    <li><Link href="#">Privacy Policy</Link></li>
                                    <li><Link href="#">Terms & Conditions</Link></li>
                                    <li><Link href="#">Legal</Link></li>
                                </ul>
                            </div>
                            <div className="copyright-text">
                                <p>
                                    Copyrights <Link href="index-4.html">© {new Date().getFullYear()} Hiringhub</Link> Recruiters, All Rights
                                    Reserved.
                                </p>
                            </div>
                        </div>
                    </div>
                </div>
            </footer>

        </>
    )
}
