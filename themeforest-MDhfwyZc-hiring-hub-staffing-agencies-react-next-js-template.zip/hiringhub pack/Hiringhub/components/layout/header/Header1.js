import Link from "next/link"
import Menu from "../Menu"
import MobileMenu from "../MobileMenu"



export default function Header1({ scroll, handleMobileMenu, handlePopup, handleSidebar }) {
    
    return (
        <>

        {/* main header */}

        <header className={`main-header main-header-style1 ${scroll ? "fixed-header" : ""}`}>

        <div className="logo-box-style1">
                <div className="shape">
                    <img src="assets/images/shapes/header-v1-shape1.png" alt=""/>
                </div>
                <Link href="/">
                    <img src="assets/images/resources/logo-1.png" alt=""/>
                </Link>
            </div>
            <div className="main-header-style1__box">
                
                <div className="main-header-style1__box-top">
                    <div className="main-header-style1__box-top__left">
                        <div className="language-switcher-style1">
                            <div className="icon">
                                <span className="icon-planet"></span>
                            </div>
                            <div className="select-box clearfix">
                                <select className="wide">
                                    <option data-display="Us - En">Us - En</option>
                                    <option value="1">Fra</option>
                                    <option value="2">Ger</option>
                                    <option value="3">Ita</option>
                                </select>
                            </div>
                        </div>
                        <div className="header-subscribe-box-one">
                            <div className="icon">
                                <span className="icon-rss"></span>
                            </div>
                            <div className="text">
                                <Link href="/contact">Subscribe Us</Link>
                            </div>
                        </div>
                    </div>

                    <div className="main-header-style1__box-top__right">
                        <div className="header-contact-info-style1">
                            <div className="text">
                                <p>Your Next Hire Starts with Us:</p>
                            </div>
                            <ul>
                                <li>
                                    <div className="icon">
                                        <span className="icon-mobile"></span>
                                    </div>
                                    <p><Link href="tel:18885678907891">(+41) 888.56.7890</Link></p>
                                </li>
                                <li>
                                    <div className="icon">
                                        <span className="icon-email"></span>
                                    </div>
                                    <p><Link href="mailto:support@hiringhub.com">info@hiringhub.com</Link></p>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
                
                <div className="main-header-style1__box-bottom">
                    <nav className="main-menu main-menu-style1">
                        <div className="main-menu__wrapper clearfix">
                            <div className="main-menu__wrapper-inner">
                                <div className="sticky-logo-box-style1">
                                    <Link href="index.html">
                                        <img src="assets/images/resources/sticky-logo-1.png" alt=""/>
                                    </Link>
                                </div>
                                <div className="main-menu-style1__left">
                                    <div className="main-menu-box">
                                        <Link href="#" className="mobile-nav__toggler" onClick={handleMobileMenu}>
                                            <i className="fa fa-bars"></i>
                                        </Link>

                                        <Menu />

                                    </div>
                                </div>

                                <div className="main-menu-style1__right">
                                    <div className="box-search-style1">
                                        <Link href="#" className="search-toggler" onClick={handleSidebar}>
                                            <p>Search</p>
                                            <span className="icon-search"></span>
                                        </Link>
                                    </div>
                                    <div className="hedaer-style1-request-call-box">
                                        <div className="icon">
                                            <span className="icon-call-back"></span>
                                        </div>
                                        <div className="text">
                                            <p>Request</p>
                                            <Link href="tel:18885678907891">Consult Call</Link>
                                        </div>
                                    </div>
                                    <div className="side-content-button">
                                        <a className="navSidebar-button" href="#" onClick={handlePopup}>
                                            <img src="assets/images/icon/toogle-icon.png" alt=""/>
                                        </a>
                                    </div>
                                </div>

                            </div>

                        </div>
                    </nav>
                </div>
            </div>
            
            <div className={`stricky-header stricky-header--style1 stricked-menu main-menu ${scroll ? "animated slideInDown" : ""}`}>
                <div className="sticky-header__content">
                    <div className="main-menu__wrapper clearfix">
                        <div className="main-menu__wrapper-inner">
                            <div className="sticky-logo-box-style1">
                                <a href="index.html">
                                    <img src="assets/images/resources/sticky-logo-1.png" alt="Awesome Logo"/>
                                </a>
                            </div>
                            
                            <div className="main-menu-box">
                                <Link href="#" className="mobile-nav__toggler" onClick={handleMobileMenu}>
                                    <i className="fa fa-bars"></i>
                                </Link>

                                <Menu />

                            </div>

                        </div>

                    </div>
                </div>
            </div>
            <MobileMenu handleMobileMenu={handleMobileMenu} />
        </header>

        </>
    )
}
