import Link from "next/link"
import Menu from "../Menu"
import MobileMenu from "../MobileMenu"



export default function Header2({ scroll, handleMobileMenu, handlePopup, handleSidebar }) {
    
    return (
        <>

        {/* main header */}

        <header className={`main-header main-header-style2 ${scroll ? "fixed-header" : ""}`}>
            <div className="container">
                <div className="main-header-style2__inner">
                    <div className="main-header-style2__left">
                        <div className="side-content-button marleft0">
                            <a className="navSidebar-button" href="#" onClick={handlePopup}>
                                <img src="assets/images/icon/toogle-icon.png" alt=""/>
                            </a>
                        </div>
                        <div className="logo-box-style2">
                            <Link href="/index-2">
                                <img src="assets/images/resources/logo-2.png" alt="Awesome Logo" title=""/>
                            </Link>
                        </div>
                        <nav className="main-menu main-menu-style1">
                            <div className="main-menu__wrapper clearfix">
                                <div className="main-menu__wrapper-inner">
                                    <div className="sticky-logo-box-style1">
                                        <Link href="/index-2">
                                            <img src="assets/images/resources/sticky-logo-1.png" alt="Awesome Logo"/>
                                        </Link>
                                    </div>
                                    <div className="main-menu-style1__left">
                                        <div className="main-menu-box">
                                            <Link href="#" className="mobile-nav__toggler" onClick={handleMobileMenu}>
                                                <i className="fa fa-bars"></i>
                                            </Link>

                                            <Menu />

                                        </div>
                                    </div>
                                </div>
                            </div>
                        </nav>
                    </div>
                    <div className="main-header-style2__right">
                        <div className="box-search-style1">
                            <Link href="#" className="search-toggler" onClick={handleSidebar}>
                                <p>Search</p>
                                <span className="icon-search"></span>
                            </Link>
                        </div>
                        <div className="hedaer-style1-request-call-box">
                            <div className="icon">
                                <span className="icon-call-back"></span>
                            </div>
                            <div className="text">
                                <p>Request</p>
                                <Link href="tel:18885678907891">Consult Call</Link>
                            </div>
                        </div>
                    </div>

                </div>
            </div>
            
            <div className={`stricky-header stricky-header--style1 stricked-menu main-menu ${scroll ? "animated slideInDown" : ""}`}>
                <div className="sticky-header__content">
                    <div className="main-menu__wrapper clearfix">
                        <div className="main-menu__wrapper-inner">
                            <div className="sticky-logo-box-style1">
                                <Link href="/index-2">
                                    <img src="assets/images/resources/sticky-logo-1.png" alt="Awesome Logo"/>
                                </Link>
                            </div>
                            
                            <div className="main-menu-box">
                                <Link href="#" className="mobile-nav__toggler" onClick={handleMobileMenu}>
                                    <i className="fa fa-bars"></i>
                                </Link>

                                <Menu />

                            </div>

                        </div>

                    </div>
                </div>
            </div>
            <MobileMenu handleMobileMenu={handleMobileMenu} />
        </header>

        </>
    )
}
