import Link from "next/link"
import Menu from "../Menu"
import MobileMenu from "../MobileMenu"



export default function Header3({ scroll, handleMobileMenu }) {
    
    return (
        <>

        {/* main header */}

        <header className={`main-header main-header-style3 ${scroll ? "fixed-header" : ""}`}>
            <div className="main-header-style3__top">
                <div className="container">
                    <div className="main-header-style3__inner">
                        
                        <div className="main-header-style3__top-left">
                            <ul>
                                <li>
                                    <div className="icon">
                                        <span className="icon-tie"></span>
                                    </div>
                                    98% Client Satisfaction,
                                    <Link href="blog-single.html">Find Top Talent
                                        <span className="icon-arrow-angle-pointing-to-right"></span>
                                    </Link>
                                </li>
                                <li>
                                    <div className="icon">
                                        <span className="icon-chat"></span>
                                    </div>
                                    <Link href="blog-single.html">
                                        Chat with Experts
                                        <span className="icon-arrow-angle-pointing-to-right"></span>
                                    </Link>
                                </li>
                            </ul>
                        </div>
                        
                        <div className="main-header-style3__top-right">
                            <ul>
                                <li>
                                    <div className="icon">
                                        <span className="icon-suitcase"></span>
                                    </div>
                                    <Link href="job-openings.html">
                                        Job Openings
                                        <span className="icon-arrow-angle-pointing-to-right"></span>
                                    </Link>
                                </li>
                                <li>
                                    <div className="icon">
                                        <span className="icon-form"></span>
                                    </div>
                                    <Link href="apply-now.html">
                                        Upload Resume
                                        <span className="icon-arrow-angle-pointing-to-right"></span>
                                    </Link>
                                </li>
                            </ul>
                        </div>

                    </div>
                </div>
            </div>

            <div className="main-header-style3__bottom">
                <div className="container">
                    <div className="main-header-style3__bottom-inner">
                        
                        <div className="main-header-style3__bottom-left">

                            <div className="logo-box-style3">
                                <Link href="index.html">
                                    <img src="assets/images/resources/logo-2.png" alt="Awesome Logo" title=""/>
                                </Link>
                            </div>
                            
                            <nav className="main-menu main-menu-style1">
                                <div className="main-menu__wrapper clearfix">
                                    <div className="main-menu__wrapper-inner">
                                        <div className="sticky-logo-box-style1">
                                            <Link href="index.html">
                                                <img src="assets/images/resources/sticky-logo-1.png" alt="Awesome Logo"
                                                    title=""/>
                                            </Link>
                                        </div>
                                        <div className="main-menu-style1__left">
                                            <div className="main-menu-box">
                                                <Link href="#" className="mobile-nav__toggler" onClick={handleMobileMenu}>
                                                    <i className="fa fa-bars"></i>
                                                </Link>

                                                <Menu />
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </nav>
                        </div>
                        
                        <div className="main-header-style3__bottom-right">
                            <div className="box-search-style1">
                                <Link href="#" className="search-toggler">
                                    <p>Search</p>
                                    <span className="icon-search"></span>
                                </Link>
                            </div>
                            <div className="join-us-box-style1">
                                <div className="icon">
                                    <span className="icon-user"></span>
                                </div>
                                <div className="select-box clearfix">
                                    <select className="wide">
                                        <option data-display="My Account">My Account</option>
                                        <option value="1">
                                            sign In
                                        </option>
                                        <option value="2">
                                            create account
                                        </option>
                                    </select>
                                </div>
                            </div>
                            <div className="hedaer-style1-request-call-box hedaer-style1-request-call-box--style2">
                                <div className="icon">
                                    <span className="icon-call-back"></span>
                                </div>
                                <div className="text">
                                    <p>Request</p>
                                    <Link href="tel:18885678907891">Consult Call</Link>
                                </div>
                            </div>
                        </div>

                    </div>
                </div>
            </div>
            
            
            <div className={`stricky-header stricky-header--style1 stricked-menu main-menu ${scroll ? "animated slideInDown" : ""}`}>
                <div className="sticky-header__content">
                    <div className="main-menu__wrapper clearfix">
                        <div className="main-menu__wrapper-inner">
                            <div className="sticky-logo-box-style1">
                                <Link href="/index-2">
                                    <img src="assets/images/resources/sticky-logo-1.png" alt="Awesome Logo"/>
                                </Link>
                            </div>
                            
                            <div className="main-menu-box">
                                <Link href="#" className="mobile-nav__toggler" onClick={handleMobileMenu}>
                                    <i className="fa fa-bars"></i>
                                </Link>

                                <Menu />

                            </div>

                        </div>

                    </div>
                </div>
            </div>
            <MobileMenu handleMobileMenu={handleMobileMenu} />
        </header>

        </>
    )
}
