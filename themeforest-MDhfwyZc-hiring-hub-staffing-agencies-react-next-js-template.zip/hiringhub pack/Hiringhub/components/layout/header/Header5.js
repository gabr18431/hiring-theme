import Link from "next/link"
import Menu from "../Menu"
import MobileMenu from "../MobileMenu"



export default function Header5({ scroll, handleMobileMenu, handleSidebar }) {
    
    return (
        <>

        {/* main header */}

        <header className={`main-header main-header-style5 ${scroll ? "fixed-header" : ""}`}>

            <div className="main-header-style5__top">
                <div className="container">
                    <div className="main-header-style5__top-inner">

                        <div className="main-header-style5__top-left">
                            <div className="header-contact-info-style2">
                                <div className="title-box">
                                    <h5><span className="icon-human-resources"></span> Immediate Hiring:</h5>
                                </div>
                                <div className="text-box">
                                    <p>
                                        Business Development Manager, San Fransisco, CA.
                                        <Link href="/contact">Explore More
                                            <span className="icon-arrow-angle-pointing-to-right"></span>
                                        </Link>
                                    </p>
                                </div>
                            </div>
                        </div>

                        <div className="main-header-style5__top-right">
                            <div className="box-search-style1 box-search-style1--style2">
                                <Link href="#" className="search-toggler" onClick={handleSidebar}>
                                    <p>Search</p>
                                    <span className="icon-search"></span>
                                </Link>
                            </div>

                            <div className="header-social-link-style1 header-social-link-style1--style2">
                                <ul className="clearfix">
                                    <li>
                                        <Link href="https://www.facebook.com/">
                                            <i className="icon-facebook"></i>
                                        </Link>
                                    </li>
                                    <li>
                                        <Link href="https://x.com/i/flow/login">
                                            <i className="icon-twitter"></i>
                                        </Link>
                                    </li>
                                    <li>
                                        <Link href="https://www.instagram.com/accounts/login/?hl=en">
                                            <i className="icon-instagram-logo"></i>
                                        </Link>
                                    </li>
                                    <li>
                                        <Link href="https://www.youtube.com/">
                                            <i className="icon-youtube"></i>
                                        </Link>
                                    </li>
                                </ul>
                            </div>

                            <div className="language-switcher-style1 language-switcher-style1--style2">
                                <div className="icon">
                                    <span className="icon-planet"></span>
                                </div>
                                <div className="select-box clearfix">
                                    <select className="wide">
                                        <option data-display="Us - En">Us - En</option>
                                        <option value="1">Fra</option>
                                        <option value="2">Ger</option>
                                        <option value="3">Ita</option>
                                    </select>
                                </div>
                            </div>

                        </div>

                    </div>
                </div>
            </div>


            <div className="main-header-style5__bottom">
                <div className="container">
                    <div className="main-header-style5__bottom-inner">
                        

                        <div className="main-header-style5__bottom-left">

                            <div className="logo-box-style5">
                                <Link href="index.html">
                                    <img src="assets/images/resources/logo-1.png" alt="Awesome Logo" title=""/>
                                </Link>
                            </div>
                            

                            <nav className="main-menu main-menu-style1">
                                <div className="main-menu__wrapper clearfix">
                                    <div className="main-menu__wrapper-inner">
                                        <div className="sticky-logo-box-style1">
                                            <Link href="index.html">
                                                <img src="assets/images/resources/sticky-logo-1.png" alt="Awesome Logo"
                                                    title=""/>
                                            </Link>
                                        </div>
                                        <div className="main-menu-style1__left">
                                            <div className="main-menu-box">
                                                <Link href="#" className="mobile-nav__toggler" onClick={handleMobileMenu}>
                                                    <i className="fa fa-bars"></i>
                                                </Link>

                                                <Menu />
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </nav>
                        </div>
                        
                        <div className="main-header-style5__bottom-right">

                            <div className="join-us-box-style1 join-us-box-style1--style2">
                                <div className="icon">
                                    <span className="icon-user"></span>
                                </div>
                                <div className="select-box clearfix">
                                    <select className="wide">
                                        <option data-display="My Account">My Account</option>
                                        <option value="1">
                                            sign In
                                        </option>
                                        <option value="2">
                                            create account
                                        </option>
                                    </select>
                                </div>
                            </div>

                            <div className="hedaer-style1-request-call-box hedaer-style1-request-call-box--style3">
                                <div className="icon">
                                    <span className="icon-call-back"></span>
                                </div>
                                <div className="text">
                                    <p>Request</p>
                                    <Link href="tel:18885678907891">Consult Call</Link>
                                </div>
                            </div>

                        </div>

                    </div>
                </div>
            </div>
            
            
            <div className={`stricky-header stricky-header--style1 stricked-menu main-menu ${scroll ? "animated slideInDown" : ""}`}>
                <div className="sticky-header__content">
                    <div className="main-menu__wrapper clearfix">
                        <div className="main-menu__wrapper-inner">
                            <div className="sticky-logo-box-style1">
                                <Link href="/index-2">
                                    <img src="assets/images/resources/sticky-logo-1.png" alt="Awesome Logo"/>
                                </Link>
                            </div>
                            
                            <div className="main-menu-box">
                                <Link href="#" className="mobile-nav__toggler" onClick={handleMobileMenu}>
                                    <i className="fa fa-bars"></i>
                                </Link>

                                <Menu />

                            </div>

                        </div>

                    </div>
                </div>
            </div>
            <MobileMenu handleMobileMenu={handleMobileMenu} />
        </header>

        </>
    )
}
