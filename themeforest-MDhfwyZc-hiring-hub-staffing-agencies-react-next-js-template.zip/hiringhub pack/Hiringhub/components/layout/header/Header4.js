import Link from "next/link"
import Menu from "../Menu"
import MobileMenu from "../MobileMenu"



export default function Header4({ scroll, handleMobileMenu }) {
    
    return (
        <>

        {/* main header */}

        <header className={`main-header main-header-style4 ${scroll ? "fixed-header" : ""}`}>
            
            <div className="main-header-style4__bottom">
                <div className="container">
                    <div className="main-header-style4__bottom-inner">
                        
                        <div className="main-header-style4__bottom-left">

                            <div className="logo-box-style4">
                                <Link href="/index-4">
                                    <img src="assets/images/resources/logo-1.png" alt="Awesome Logo" title=""/>
                                </Link>
                            </div>
                            
                            <nav className="main-menu main-menu-style1">
                                <div className="main-menu__wrapper clearfix">
                                    <div className="main-menu__wrapper-inner">
                                        <div className="sticky-logo-box-style1">
                                            <Link href="/index-4">
                                                <img src="assets/images/resources/sticky-logo-1.png" alt="Awesome Logo"
                                                    title=""/>
                                            </Link>
                                        </div>
                                        <div className="main-menu-style1__left">
                                            <div className="main-menu-box">
                                                <Link href="#" className="mobile-nav__toggler" onClick={handleMobileMenu}>
                                                    <i className="fa fa-bars"></i>
                                                </Link>

                                                <Menu />
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </nav>
                        </div>
                        
                        <div className="main-header-style4__bottom-right">
                            <div className="join-us-box-style1 join-us-box-style1--style2">
                                <div className="icon">
                                    <span className="icon-user"></span>
                                </div>
                                <div className="select-box clearfix">
                                    <select className="wide">
                                        <option data-display="My Account">My Account</option>
                                        <option value="1">
                                            sign In
                                        </option>
                                        <option value="2">
                                            create account
                                        </option>
                                    </select>
                                </div>
                            </div>
                            <div className="phone-number-box-style1">
                                <p>help desk <span className="icon-headphone"></span></p>
                                <Link href="tel:18885678907891">(+41) 888.56.7890</Link>
                            </div>
                        </div>

                    </div>
                </div>
            </div>
            
            
            <div className={`stricky-header stricky-header--style1 stricked-menu main-menu ${scroll ? "animated slideInDown" : ""}`}>
                <div className="sticky-header__content">
                    <div className="main-menu__wrapper clearfix">
                        <div className="main-menu__wrapper-inner">
                            <div className="sticky-logo-box-style1">
                                <Link href="/index-2">
                                    <img src="assets/images/resources/sticky-logo-1.png" alt="Awesome Logo"/>
                                </Link>
                            </div>
                            
                            <div className="main-menu-box">
                                <Link href="#" className="mobile-nav__toggler" onClick={handleMobileMenu}>
                                    <i className="fa fa-bars"></i>
                                </Link>

                                <Menu />

                            </div>

                        </div>

                    </div>
                </div>
            </div>
            <MobileMenu handleMobileMenu={handleMobileMenu} />
        </header>

        </>
    )
}
