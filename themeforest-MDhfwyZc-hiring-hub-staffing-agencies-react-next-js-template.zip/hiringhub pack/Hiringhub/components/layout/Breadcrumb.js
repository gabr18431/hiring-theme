import Link from "next/link"

export default function Breadcrumb({ breadcrumbTitle }) {
    return (
        <>

        <section className="breadcrumb-style1">
            <div className="breadcrumb-style1-bg" style={{ backgroundImage: "url(assets/images/breadcrumb/breadcrumb-1.jpg)" }}>
            </div>
            <div className="container">
                <div className="inner-content">
                    <div className="title text-center">
                        <h2>{breadcrumbTitle}</h2>
                    </div>
                    <div className="breadcrumb-menu">
                        <ul className="clearfix">
                            <li><Link href="/">Home</Link></li>
                            <li><span className="icon-arrow-angle-pointing-to-right"></span></li>
                            <li className="active">{breadcrumbTitle}</li>
                        </ul>
                    </div>
                </div>
            </div>
        </section>

        </>
    )
}
