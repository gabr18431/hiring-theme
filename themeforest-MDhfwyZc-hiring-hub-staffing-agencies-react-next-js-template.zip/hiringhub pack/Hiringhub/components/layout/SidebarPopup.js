import Link from "next/link"

export default function SidebarPopup({ isPopup, handlePopup }) {
    return (
        <>

            
            <div className={`xs-sidebar-group info-group info-sidebar ${isPopup ? "popup-visible" : ""}`}>
                <div className="xs-overlay xs-bg-black"></div>
                <div className="xs-sidebar-widget">
                    <div className="sidebar-widget-container">
                        <div className="widget-heading">
                            <Link href="#" className="close-side-widget"onClick={handlePopup}>X</Link>
                        </div>
                        <div className="sidebar-textwidget">
                            <div className="sidebar-info-contents">
                                <div className="content-inner">
                                    <div className="logo">
                                        <Link href="index.html">
                                            <img src="assets/images/resources/side-content__logo.png" alt="" />
                                        </Link>
                                    </div>
                                    <div className="content-box">
                                        <h3>Welcome to our Best HiringHub employee & employer Company</h3>
                                        <div className="inner-text">
                                            <p>
                                                We’re HiringHub employee & employer for you Since 1987, Providing the Best
                                                Services for Our Customers. Meet Our Experienced & Professional Team,
                                                Professional Customer Service.
                                            </p>
                                        </div>
                                    </div>
                                    <div className="sidebar-contact-info">
                                        <h3>Conatct Us</h3>
                                        <ul>
                                            <li>
                                                <div className="inner">
                                                    <div className="text">
                                                        <p>54B, Tailstoi Town 5238 MT,<br/> La city, IA 522364</p>
                                                    </div>
                                                </div>
                                            </li>
                                            <li>
                                                <div className="inner">
                                                    <div className="text">
                                                        <p><Link href="mailto:info@example.com">contact@hiringHub.com</Link></p>
                                                    </div>
                                                </div>
                                            </li>
                                            <li>
                                                <div className="inner">
                                                    <div className="text">
                                                        <p><Link href="tel:+8801682648101">+1800 456 7890</Link></p>
                                                    </div>
                                                </div>
                                            </li>
                                            <li>
                                                <div className="inner">
                                                    <div className="text">
                                                        <p>Working Hrs : 9.30am to 6.30pm</p>
                                                    </div>
                                                </div>
                                            </li>
                                        </ul>
                                    </div>

                                    <div className="side-content-newsletter-box">
                                        <h3>Newsletter Subscription</h3>
                                        <form action="/" method="post">
                                            <div className="form-group">
                                                <input type="email" name="email" placeholder="Enter Email Address" required=""/>
                                                <button className="btn-one" type="submit">
                                                    <span className="txt">
                                                        subscribe now
                                                        <i className="icon-right"></i>
                                                    </span>
                                                </button>
                                            </div>
                                        </form>
                                    </div>

                                    <div className="thm-social-link">
                                        <ul className="clearfix">
                                            <li>
                                                <Link href="#">
                                                    <i className="icon-facebook"></i>
                                                </Link>
                                            </li>
                                            <li>
                                                <Link href="#">
                                                    <i className="icon-twitter"></i>
                                                </Link>
                                            </li>
                                            <li>
                                                <Link href="#">
                                                    <i className="icon-instagram-logo"></i>
                                                </Link>
                                            </li>
                                            <li>
                                                <Link href="#">
                                                    <i className="icon-youtube"></i>
                                                </Link>
                                            </li>
                                        </ul>
                                    </div>

                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

        </>
    )
}
